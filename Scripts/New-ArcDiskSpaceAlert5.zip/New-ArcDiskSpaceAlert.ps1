#Requires -Version 5.1
<#
.SYNOPSIS
    SCHRITT 5 von 6 - Erstellt EINE E-Mail-Alert-Regel fuer mehrere Laufwerke
    aller Arc Windows Server. Server und Laufwerk erscheinen dynamisch im
    Mail-Betreff.
.DESCRIPTION
    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten (dieses Script)
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung

    AENDERUNG IN 4.1.0 - GRENZWERTPRUEFUNG
    -------------------------------------------------------------------------
    Dokumentierte Grenzen von Azure Monitor, die diese Regel betreffen:

      Dimensionen je Regel      max. 6, nur String oder numerisch
                                -> wir nutzen 2 Strings

      Regel-Eigenschaften       max. 64 KB fuer Query, Dimensionen,
                                Beschreibung und Action Groups zusammen
                                -> wird jetzt vor der Anlage geprueft,
                                   Warnung ab 48 KB

      Beschreibung              max. 4096 Zeichen
                                -> wird geprueft

      Stateful-Regel            max. 300 Alarme JE AUSWERTUNG
                                -> bei ~200 Servern x 3 Laufwerken sind
                                   600 Kombinationen moeglich. Azure kappt
                                   still bei 300.

      E-Mail-Versand            max. 100 Mails/Stunde JE ADRESSE und Region,
                                100 Benachrichtigungen/5 Min je Regel
                                -> bei einem Grossereignis greift das Rate
                                   Limit, ebenfalls ohne Fehlermeldung

    Die beiden letzten lassen sich nicht abfangen, nur kennen. Sie stehen
    deshalb in der Zusammenfassung.

    KORREKTUR IN 4.0.3 - TIMEGENERATED IN DER QUERY
    -------------------------------------------------------------------------
    Die Anlage scheiterte mit 'Number of evaluation periods must be 1 for
    queries that do not project the TimeGenerated column of type datetime'.

    Die Query gruppierte nur nach Computer, Drive und _ResourceId - ohne
    Zeitachse. Damit kann Azure nicht feststellen, ob die Bedingung in zwei
    aufeinanderfolgenden Perioden verletzt war oder nur einmal.

    Statt auf eine Periode zurueckzugehen (und damit die Fehlalarm-Daempfung
    aufzugeben) enthaelt die Query jetzt bin(TimeGenerated, ...). Die
    Bin-Groesse wird aus $WindowSize abgeleitet, damit beide nicht
    auseinanderlaufen koennen.

    KORREKTUR IN 4.0.2 - AUTO-MITIGATION ODER SUPPRESSION
    -------------------------------------------------------------------------
    Die Anlage scheiterte mit 'Auto mitigation must be disabled when action
    suppression is set'. Azure erlaubt genau EINES von beiden - beides
    zusammen waere widerspruechlich, weil Auto-Mitigation die Aufloesung
    melden und Suppression sie unterdruecken wuerde.

    Statt eine der beiden Zeilen still zu entfernen, gibt es jetzt
    $NotificationMode als bewusste Entscheidung. Default 'AutoResolve':
    Speicherplatz aendert sich langsam, und die Entwarnung nach dem
    Aufraeumen ist die nuetzlichere Information.

    KORREKTUR IN 4.0.1 - METRIC MEASURE COLUMN
    -------------------------------------------------------------------------
    Die Anlage scheiterte mit 'Metric Measure Column was not specified'.
    Die CLI-Grammatik fuehrt diesen Teil als optional:
        {avg,min,max,total,count} ["METRIC COLUMN" from] "QUERY_PLACEHOLDER"
    Mit nur EINER Dimension liess die API ihn durchgehen, mit ZWEI nicht
    mehr. Er wird jetzt immer gesetzt ($MetricColumn), und das Script
    prueft vor der Anlage, ob die Spalte in der Query ueberhaupt vorkommt.

    EINE REGEL FUER ALLE LAUFWERKE
    -------------------------------------------------------------------------
    Dimension-Splitting auf 'Computer' UND 'Drive' erzeugt je Kombination
    aus Server und Laufwerk eine eigene Alert-Instanz. Getrennte Regeln je
    Laufwerk sind deshalb nicht noetig - solange derselbe Schwellwert gilt.

    Braucht ihr je Laufwerk unterschiedliche Grenzen (z. B. C: 15 %, D: 5 %),
    fuehrt kein Weg an getrennten Regeln vorbei: eine Scheduled Query Rule
    kennt genau einen Schwellwert.

    WARUM TAGS NICHT DIREKT WIRKEN
    -------------------------------------------------------------------------
    Eine Log Search Alert Rule fragt Log Analytics ab. Dort gibt es KEINE
    Azure-Tags - weder Monitoring/OperatingSystem auf der Maschine noch
    Monitoring=no-disccapacitymonitoring auf der Disk-Ressource. Ein
    Cross-Query gegen Resource Graph ist in einer Alert-Regel nicht moeglich.

    Das Script loest beides deshalb ZUR ANLAGEZEIT auf und schreibt die
    Ausnahmen fest in die Query:

      Tag-Filter   Resource Graph liefert alle Maschinen, die NICHT beide
                   Tags tragen. Deren Kurznamen werden ausgeschlossen. Die
                   Liste ist klein, weil die Policy ohnehin nur getaggte
                   Maschinen mit der DCR verknuepft - es geht um Altbestand.

      Disk-Tags    Resource Graph liefert die getaggten Disk-Ressourcen mit
                   Servername (Praefix vor dem Unterstrich) und Groesse.
                   Log Analytics liefert Laufwerke mit berechneter
                   Gesamtgroesse. Beide werden ueber Server + Groesse
                   (Toleranz +/- 1 GB) zusammengefuehrt.

                   EINDEUTIGE Treffer werden ausgeschlossen. MEHRDEUTIGE -
                   zwei gleich grosse Laufwerke auf demselben Server -
                   werden gemeldet, aber NICHT ausgeschlossen. Eine
                   geratene Ausnahme unterdrueckt sonst einen echten Alarm,
                   und das faellt niemandem auf, weil ja nichts passiert.

    WICHTIG: Das ist eine MOMENTAUFNAHME. Neue Disk-Tags oder neue Server
    ohne Tags wirken sich erst nach einem erneuten Lauf dieses Scripts aus.

    ACTION GROUP UND EMPFAENGER
    -------------------------------------------------------------------------
    'az monitor action-group create' fuehrt ein PUT aus - die Ressource wird
    komplett durch das ersetzt, was im Aufruf steht. Alles im Portal manuell
    Ergaenzte (weitere Adressen, SMS, Webhooks, Teams) ist danach weg.
    $EmailRecipients ist damit die alleinige Quelle der Wahrheit.

    Das Script loescht die Action Group NICHT vor dem Anlegen. Zwischen
    Loeschen und Neuanlegen gaebe es sonst ein Zeitfenster, in dem ein
    feuernder Alarm ins Leere laeuft.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 18.08.2026
    Version     : 4.1.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\New-ArcDiskSpaceAlert.ps1
.EXAMPLE
    # Vorschau - zeigt Query, Condition, Ausnahmen und Betreff
    $WhatIfMode = $true; .\New-ArcDiskSpaceAlert.ps1
#>

$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

# --- Azure-Kontext ---
$SubscriptionId         = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local
$WorkspaceName          = "law-LDK-VirtualServer"
$WorkspaceResourceGroup = "rg-arcmgmt"
$AlertResourceGroup     = "rg-arcmgmt"
$Location               = "westeurope"

# --- Action Group / Empfaenger ---
# Array statt Hashtable: Anzeigenamen duerfen sich wiederholen, Schluessel
# einer Hashtable muessten eindeutig sein.
$ActionGroupName        = "ag-arc-diskspace"
$ActionGroupShortName   = "ArcDisk"                    # max. 12 Zeichen
$EmailRecipients        = @(
    @{ Name = "ITAlert";   Address = "statusmails@ortha-itsolutions.de" }
    # @{ Name = "Bereitsch"; Address = "bereitschaft@example.de" }
    # @{ Name = "Helpdesk";  Address = "helpdesk@example.de" }
)

# --- Alert-Regel ---
$RuleName               = "alert-arc-disk-below-15pct"
$RuleDisplayName        = "Arc Windows Server: Laufwerk unter 15 % frei"
$Severity               = 2                            # 0=schwerwiegend ... 4=info
$ThresholdPercent       = 15
$Drives                 = @("C:", "D:", "E:")
# Spalte der Query, die den Messwert traegt. Muss zum 'project' der Query
# passen - siehe Get-DiskQuery weiter unten.
$MetricColumn           = "FreePercent"
$EvaluationFrequency    = "PT15M"
$WindowSize             = "PT15M"
$NumberOfEvalPeriods    = 2
$MinFailingPeriods      = 2

# --- Benachrichtigungsmodus ---------------------------------------------
# Azure erlaubt genau EINES von beiden. Die API lehnt die Kombination ab:
#   "Auto mitigation must be disabled when action suppression is set"
#
#   'AutoResolve'  Der Alarm loest sich selbst auf, sobald die Bedingung
#                  nicht mehr erfuellt ist, und es geht eine Resolved-Mail
#                  raus. Empfohlen fuer Speicherplatz: die Werte aendern
#                  sich langsam, Wackeln um den Schwellwert ist selten -
#                  und nach dem Aufraeumen will man die Entwarnung sehen.
#                  Nur in diesem Modus liefert ${data.essentials.monitorCondition}
#                  im Betreff etwas anderes als 'Fired'.
#
#   'Suppress'     Nach dem Feuern bleibt es fuer $MuteActionsDuration still.
#                  Keine Entwarnung, dafuer kein Wiederholungsschwall bei
#                  Werten dicht am Schwellwert.
$NotificationMode       = "AutoResolve"      # 'AutoResolve' oder 'Suppress'
$MuteActionsDuration    = "PT6H"             # nur bei 'Suppress' wirksam

# --- Serverauswahl ueber Maschinen-Tags ---
# Wird zur Anlagezeit gegen Resource Graph aufgeloest. Maschinen, die NICHT
# alle Tags tragen, werden namentlich aus der Query ausgeschlossen.
# Identisch zu $PolicyTagFilter in New-ArcMonitoringPolicy.ps1 halten.
$MachineTagFilter       = [ordered]@{
    "Monitoring"      = "VirtualServer"
    "OperatingSystem" = "Windows Server"
}
$ApplyMachineTagFilter  = $true

# --- Laufwerks-Ausnahmen ueber Disk-Tags ---
# Tag auf der DISK-Ressource (Azure Local).
$DiskTagName            = "Monitoring"
$DiskTagValue           = "no-disccapacitymonitoring"
$ApplyDiskTagFilter     = $true
$SizeToleranceGB        = 1        # Toleranz beim Abgleich VHDX <-> Laufwerk

# --- Manuelle Ausnahmen (immer wirksam) ---
# Format: 'server|laufwerk', z. B. 'mxkkr8|D:'. Kurzname ohne Domaene.
$ExcludeDrives          = @()
# Ganze Server ausnehmen, unabhaengig vom Laufwerk.
$ExcludeServers         = @()
# Namensmuster (Regex), z. B. AVD-Hosts.
$ExcludeNamePatterns    = @('^avd')

# --- Betreff-Vorlage --------------------------------------------------------
# WICHTIG: einfache Anfuehrungszeichen! In doppelten wuerde PowerShell
# ${data...} als eigene Variable interpretieren und leer ersetzen.
#
# dimensions[0] = Computer, dimensions[1] = Drive - in der Reihenfolge, in
# der sie in der Condition stehen. Sollte der Betreff die Werte vertauscht
# zeigen, die beiden Indizes hier tauschen.
$EmailSubjectTemplate = '${data.alertContext.condition.allOf[0].dimensions[0].value}' `
                      + ' ${data.alertContext.condition.allOf[0].dimensions[1].value}' `
                      + ' - unter 15 % frei' `
                      + ' (${data.essentials.monitorCondition},' `
                      + ' ${data.alertContext.condition.allOf[0].metricValue} % frei)'

# --- Vorschaumodus ---
$WhatIfMode             = $false

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    <#
      Ruft Azure CLI auf und liefert sauberes JSON zurueck. Trennt stdout und
      stderr, damit Python-Warnungen der CLI-Extensions das JSON nicht
      zerstoeren. Fuer OBJEKTE und ARRAYS - fuer skalare Werte
      Invoke-AzText verwenden.
    #>
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort erhalten: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Ensure-Extension {
    param([Parameter(Mandatory)][string]$Name)
    $exts = Invoke-AzJson @("extension","list")
    if ($exts | Where-Object { $_.name -eq $Name }) { return $true }
    Write-Warn2 "Extension '$Name' fehlt - wird installiert."
    az extension add --name $Name --only-show-errors 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Installation von '$Name' fehlgeschlagen."; return $false }
    return $true
}

function ConvertTo-KqlTimespan {
    <#
      Wandelt eine ISO-8601-Dauer in einen KQL-Timespan:
        PT5M -> 5m, PT15M -> 15m, PT1H -> 1h, PT30S -> 30s, P1D -> 1d
      Wird gebraucht, damit die bin()-Groesse in der Query IMMER zur
      konfigurierten $WindowSize passt. Weichen beide voneinander ab,
      zaehlt Azure Perioden anders, als die Query sie bildet.
    #>
    param([Parameter(Mandatory)][string]$Iso)

    $m = [regex]::Match($Iso, '^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$')
    if (-not $m.Success) { return $null }

    if ($m.Groups[1].Success) { return "$($m.Groups[1].Value)d" }
    if ($m.Groups[2].Success) { return "$($m.Groups[2].Value)h" }
    if ($m.Groups[3].Success) { return "$($m.Groups[3].Value)m" }
    if ($m.Groups[4].Success) { return "$($m.Groups[4].Value)s" }
    return $null
}

function Get-KqlListe {
    <#
      Baut eine KQL-Liste aus Strings: 'a','b','c'
      Leere Eingabe liefert $null - der Aufrufer laesst die Zeile dann weg,
      denn 'in~ ()' waere ein Syntaxfehler.
    #>
    param([string[]]$Werte)
    $w = @($Werte | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
    if ($w.Count -eq 0) { return $null }
    return (($w | ForEach-Object { "'$_'" }) -join ", ")
}

function Set-AlertEmailSubject {
    <#
      Setzt actionProperties/Email.Subject per REST-PATCH nach, weil die CLI
      dafuer keinen Parameter anbietet. Der actions-Block wird beim PATCH
      komplett ersetzt - actionGroups muss deshalb mitgeschickt werden.
      Der Body geht ueber eine Temp-Datei, weil az.cmd Inline-JSON unter
      Windows falsch zerlegt.
    #>
    param(
        [Parameter(Mandatory)][string]$ActionGroupId,
        [Parameter(Mandatory)][string]$Subject
    )

    $ruleId = "/subscriptions/$SubscriptionId/resourceGroups/$AlertResourceGroup" `
            + "/providers/Microsoft.Insights/scheduledQueryRules/$RuleName"

    $payload = @{
        properties = @{
            actions = @{
                actionGroups     = @($ActionGroupId)
                actionProperties = @{ "Email.Subject" = $Subject }
            }
        }
    }

    $bodyFile = Join-Path $env:TEMP "sqr-patch-$([guid]::NewGuid()).json"
    $payload | ConvertTo-Json -Depth 10 | Set-Content -Path $bodyFile -Encoding UTF8

    try {
        return Invoke-AzJson @(
            "rest","--method","patch",
            "--url","https://management.azure.com$($ruleId)?api-version=2023-12-01",
            "--headers","Content-Type=application/json",
            "--body","@$bodyFile"
        )
    }
    finally { Remove-Item $bodyFile -ErrorAction SilentlyContinue }
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - 'az monitor scheduled-query' benoetigt mindestens 2.54.0."
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
    Write-Ok "Subscription gesetzt."
}

Write-Run "Pruefe benoetigte Extensions..."
$extOk = $true
foreach ($e in @("scheduled-query","resource-graph","log-analytics")) {
    if (-not (Ensure-Extension -Name $e)) { $extOk = $false }
}
if (-not $extOk) { exit 1 }
Write-Ok "Extensions verfuegbar."

Write-Run "Pruefe Workspace '$WorkspaceName'..."
$ws = Invoke-AzJson @("monitor","log-analytics","workspace","show",
                      "--resource-group",$WorkspaceResourceGroup,
                      "--name",$WorkspaceName,"-o","json")
if (-not $ws) { Write-Fail "Workspace nicht erreichbar: $script:LastAzError"; exit 1 }
Write-Ok "Workspace gefunden: $($ws.name) ($($ws.location))"
$WorkspaceResourceId = $ws.id

Write-Run "Pruefe vorhandene Alert-Regeln..."
$vorhandene = Invoke-AzJson @("monitor","scheduled-query","list",
                              "--resource-group",$AlertResourceGroup,"-o","json")
if ($vorhandene) {
    $andere = @($vorhandene | Where-Object { $_.name -ne $RuleName })
    if ($andere.Count -gt 0) {
        Write-Warn2 "$($andere.Count) weitere Regel(n) in '$AlertResourceGroup':"
        foreach ($a in $andere) { Write-Sub "$($a.name)" }
        Write-Sub "Pruefen, ob eine davon dasselbe ueberwacht - sonst doppelte Mails."
    }
    if ($vorhandene | Where-Object { $_.name -eq $RuleName }) {
        Write-Info2 "'$RuleName' existiert bereits und wird ueberschrieben."
    }
}
Write-Line

# =============================================================================
#  STUFE 1 - SERVER-AUSNAHMEN AUS MASCHINEN-TAGS
# =============================================================================
Write-Head "STUFE 1 - MASCHINEN-TAGS"

$tagAusnahmen = @()

if (-not $ApplyMachineTagFilter) {
    Write-Info2 "Uebersprungen (`$ApplyMachineTagFilter = `$false)."
}
else {
    $krit = ($MachineTagFilter.Keys | ForEach-Object { "$_=$($MachineTagFilter[$_])" }) -join " UND "
    Write-Run "Suche Maschinen OHNE $krit..."

    # Nur einfache Anfuehrungszeichen - doppelte ueberleben az.cmd nicht.
    $bed = ($MachineTagFilter.Keys | ForEach-Object {
                "tostring(tags['$_']) != '$($MachineTagFilter[$_])'" }) -join " or "

    $q = "resources " `
       + "| where type =~ 'microsoft.hybridcompute/machines' " `
       + "| where $bed " `
       + "| project name, " `
       +   "Monitoring = tostring(tags['Monitoring']), " `
       +   "OS = tostring(tags['OperatingSystem'])"

    $res = Invoke-AzJson @("graph","query","-q",$q,"--first","1000","-o","json")
    if (-not $res) {
        Write-Fail "Abfrage fehlgeschlagen: $script:LastAzError"
        exit 1
    }

    $tagAusnahmen = @($res.data | ForEach-Object { $_.name.ToLower() })
    Write-Ok "$($tagAusnahmen.Count) Maschine(n) erfuellen die Tag-Bedingung nicht."
    Write-Sub "Sie werden namentlich aus der Alert-Query ausgeschlossen."

    # Nur die relevanten anzeigen: solche, die ueberhaupt ein Monitoring-Tag
    # tragen. Voellig untaggte Maschinen liefern ohnehin keine Daten.
    $relevant = @($res.data | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Monitoring) })
    if ($relevant.Count -gt 0) {
        Write-Host ""
        Write-Info2 "Davon mit gesetztem Monitoring-Tag (potenzieller Altbestand):"
        foreach ($r in ($relevant | Sort-Object name)) {
            Write-Sub ("{0,-24} Monitoring={1}, OS={2}" -f $r.name, $r.Monitoring,
                       $(if ($r.OS) { $r.OS } else { "(leer)" }))
        }
    }
}
Write-Line

# =============================================================================
#  STUFE 2 - LAUFWERKS-AUSNAHMEN AUS DISK-TAGS
# =============================================================================
Write-Head "STUFE 2 - DISK-TAGS"

$diskAusnahmen = @()
$mehrdeutig    = @()

if (-not $ApplyDiskTagFilter) {
    Write-Info2 "Uebersprungen (`$ApplyDiskTagFilter = `$false)."
}
else {
    Write-Run "Lade Disks mit '$DiskTagName=$DiskTagValue'..."

    $q = "resources " `
       + "| where tags['$DiskTagName'] =~ '$DiskTagValue' " `
       + "| extend g = coalesce(toreal(properties.diskSizeGB), " `
       +   "toreal(properties.diskSizeBytes) / 1073741824.0, " `
       +   "toreal(properties.diskSizeMB) / 1024.0) " `
       + "| project Disk = name, " `
       +   "Server = tolower(tostring(split(name, '_')[0])), " `
       +   "GroesseGB = g"

    $res = Invoke-AzJson @("graph","query","-q",$q,"--first","1000","-o","json")
    $tagDisks = if ($res -and $res.data) { @($res.data) } else { @() }

    if ($tagDisks.Count -eq 0) {
        Write-Info2 "Keine getaggten Disks gefunden."
    }
    else {
        Write-Ok "$($tagDisks.Count) getaggte Disk-Ressource(n):"
        foreach ($d in ($tagDisks | Sort-Object Server, Disk)) {
            Write-Sub ("{0,-34} Server={1,-16} {2,7:N1} GB" -f $d.Disk, $d.Server, $d.GroesseGB)
        }

        # --- Laufwerke mit Gesamtgroesse aus Log Analytics ---
        Write-Host ""
        Write-Run "Ermittle Laufwerksgroessen aus dem Workspace..."

        $kql = "InsightsMetrics" `
             + "| where TimeGenerated > ago(2h)" `
             + "| where Origin == 'vm.azm.ms'" `
             + "| where Namespace == 'LogicalDisk'" `
             + "| where Name in ('FreeSpacePercentage','FreeSpaceMB')" `
             + "| extend Drive = tostring(todynamic(Tags)['vm.azm.ms/mountId'])" `
             + "| summarize P = avgif(Val, Name == 'FreeSpacePercentage')," `
             +   " M = avgif(Val, Name == 'FreeSpaceMB') by Computer, Drive" `
             + "| where isnotnull(P) and isnotnull(M) and P > 0" `
             + "| project Server = tolower(tostring(split(Computer, '.')[0]))," `
             +   " Drive, GesamtGB = round((M / 1024.0) / (P / 100.0), 1)"
        $kql = $kql -replace "\| where", " | where" -replace "\| extend", " | extend" `
                    -replace "\| summarize", " | summarize" -replace "\| project", " | project"

        $rows = Invoke-AzJson @("monitor","log-analytics","query",
                                "--workspace",$ws.customerId,
                                "--analytics-query",$kql,"-o","json")

        if (-not $rows) {
            Write-Warn2 "Laufwerksgroessen nicht abrufbar - Disk-Tag-Filter entfaellt."
            Write-Sub "Ursache: $script:LastAzError"
            Write-Sub "Ausnahmen ggf. manuell in `$ExcludeDrives eintragen."
        }
        else {
            $rows = @($rows)
            Write-Ok "$($rows.Count) Laufwerk(e) aus dem Workspace."
            Write-Host ""

            foreach ($d in ($tagDisks | Sort-Object Server, Disk)) {
                $treffer = @($rows | Where-Object {
                    $_.Server -eq $d.Server -and
                    [math]::Abs([double]$_.GesamtGB - [double]$d.GroesseGB) -le $SizeToleranceGB
                })

                if ($treffer.Count -eq 1) {
                    $schluessel = "$($d.Server)|$($treffer[0].Drive)"
                    $diskAusnahmen += $schluessel
                    Write-Host ("    {0,-34} -> {1,-12} eindeutig" -f $d.Disk, $schluessel) -ForegroundColor Green
                }
                elseif ($treffer.Count -gt 1) {
                    $kandidaten = ($treffer | ForEach-Object { $_.Drive }) -join ", "
                    $mehrdeutig += [PSCustomObject]@{ Disk = $d.Disk; Server = $d.Server; Kandidaten = $kandidaten }
                    Write-Host ("    {0,-34} -> {1,-12} MEHRDEUTIG ({2})" -f `
                                $d.Disk, "?", $kandidaten) -ForegroundColor Yellow
                }
                else {
                    Write-Host ("    {0,-34} -> {1,-12} kein Treffer" -f $d.Disk, "-") -ForegroundColor DarkGray
                }
            }

            if ($mehrdeutig.Count -gt 0) {
                Write-Host ""
                Write-Warn2 "$($mehrdeutig.Count) Disk(s) nicht eindeutig zuordenbar - NICHT ausgeschlossen."
                Write-Sub "Zwei gleich grosse Laufwerke auf demselben Server. Eine geratene"
                Write-Sub "Ausnahme wuerde einen echten Alarm unterdruecken, ohne dass es"
                Write-Sub "auffaellt. Bitte manuell entscheiden und in `$ExcludeDrives eintragen:"
                foreach ($m in $mehrdeutig) {
                    Write-Sub "  $($m.Server)|<Laufwerk>   Kandidaten: $($m.Kandidaten)"
                }
            }
        }
    }
}
Write-Line

# =============================================================================
#  STUFE 3 - QUERY BAUEN
# =============================================================================
Write-Head "STUFE 3 - ALERT-QUERY"

$alleServerAusnahmen = @($ExcludeServers + $tagAusnahmen | ForEach-Object { $_.ToLower() })
$alleDriveAusnahmen  = @($ExcludeDrives + $diskAusnahmen | ForEach-Object { $_.ToLower() })

# Nur einfache Anfuehrungszeichen im KQL - doppelte ueberleben az.cmd nicht.
$p = New-Object System.Collections.Generic.List[string]
$p.Add("InsightsMetrics")
$p.Add("where Origin == 'vm.azm.ms'")
$p.Add("where Namespace == 'LogicalDisk' and Name == 'FreeSpacePercentage'")
$p.Add("where _ResourceId has '/microsoft.hybridcompute/machines/'")

# KQL kennt KEIN '!matches regex' - die Negation laeuft ueber not().
foreach ($pat in $ExcludeNamePatterns) {
    $p.Add("where not(Computer matches regex '(?i)$pat')")
}

$p.Add("extend Drive = tostring(todynamic(Tags)['vm.azm.ms/mountId'])")
$lst = Get-KqlListe -Werte $Drives
if (-not $lst) {
    Write-Fail "`$Drives ist leer - die Regel haette keinen Bezug."
    exit 1
}
$p.Add("where Drive in ($lst)")

# Kurzname als Dimension - der FQDN macht den Mail-Betreff unleserlich.
$p.Add("extend Kurz = tolower(tostring(split(Computer, '.')[0]))")

$lst = Get-KqlListe -Werte $alleServerAusnahmen
if ($lst) { $p.Add("where Kurz !in~ ($lst)") }

$lst = Get-KqlListe -Werte $alleDriveAusnahmen
if ($lst) { $p.Add("where strcat(Kurz, '|', Drive) !in~ ($lst)") }

# TimeGenerated ist PFLICHT, sobald mehr als eine Auswertungsperiode
# konfiguriert ist. Die API lehnt sonst ab mit:
#   "Number of evaluation periods must be 1 for queries that do not
#    project the 'TimeGenerated' column of type 'datetime'"
# Ohne Zeitachse kann Azure nicht unterscheiden, ob die Bedingung in zwei
# aufeinanderfolgenden Perioden verletzt war oder nur einmal.
$bin = ConvertTo-KqlTimespan -Iso $WindowSize
if (-not $bin) {
    Write-Fail "`$WindowSize = '$WindowSize' ist keine gueltige ISO-8601-Dauer."
    Write-Sub "Erwartet z. B. PT5M, PT15M, PT1H."
    exit 1
}

$p.Add("summarize FreePercent = avg(Val) by bin(TimeGenerated, $bin), Computer = Kurz, Drive, _ResourceId")
$p.Add("project TimeGenerated, Computer, Drive, FreePercent, resourceId = _ResourceId")

$query = ($p -join " | ")

# Gegenpruefung: die Metric Measure Column muss in der Query vorkommen.
# Sonst schlaegt die Anlage mit 'Metric Measure Column was not specified'
# oder spaeter die Auswertung stillschweigend fehl.
if ($query -notmatch [regex]::Escape($MetricColumn)) {
    Write-Fail "Spalte '$MetricColumn' kommt in der Query nicht vor."
    Write-Sub "`$MetricColumn muss zum project der Query passen."
    exit 1
}

if ($NumberOfEvalPeriods -gt 1 -and $query -notmatch "TimeGenerated") {
    Write-Fail "Bei mehr als einer Auswertungsperiode muss die Query TimeGenerated liefern."
    Write-Sub "Entweder bin(TimeGenerated, ...) in die Query aufnehmen"
    Write-Sub "oder `$NumberOfEvalPeriods auf 1 setzen."
    exit 1
}

# Dimension-Splitting auf Computer UND Drive: je Kombination eine eigene
# Alert-Instanz. Die Reihenfolge hier bestimmt die dimensions[]-Indizes
# im Mail-Betreff.
#
# WICHTIG: Der Teil "'FreePercent' from" ist die METRIC MEASURE COLUMN -
# die Spalte der Query, die den zu vergleichenden Wert traegt. Laut
# CLI-Grammatik optional:
#     {avg,min,max,total,count} ["METRIC COLUMN" from] "QUERY_PLACEHOLDER" ...
# Bei ZWEI Dimensionen lehnt die API die Regel ohne diese Angabe aber mit
# 'Metric Measure Column was not specified' ab. Sie wird deshalb immer
# gesetzt. $MetricColumn muss zu der Spalte im project der Query passen.
$condition = "min '$MetricColumn' from 'Placeholder_1' < $ThresholdPercent " `
           + "resource id resourceId " `
           + "where Computer includes * and Drive includes * " `
           + "at least $MinFailingPeriods violations out of $NumberOfEvalPeriods aggregated points"

$description = "Feuert, wenn auf einem Arc Windows Server der freie Speicher eines " `
             + "ueberwachten Laufwerks ($($Drives -join ', ')) unter " `
             + "$ThresholdPercent % sinkt."

# --- Dokumentierte Grenzwerte pruefen ---------------------------------
# Quelle: Azure Monitor service limits, Abschnitt Alerts.
$eigenschaftenGroesse = ($query.Length + $condition.Length + $description.Length +
                         $RuleDisplayName.Length + $EmailSubjectTemplate.Length)

if ($description.Length -gt 4096) {
    Write-Fail "Beschreibung hat $($description.Length) Zeichen - erlaubt sind 4096."
    exit 1
}

if ($eigenschaftenGroesse -gt 65536) {
    Write-Fail "Regel-Eigenschaften ca. $([math]::Round($eigenschaftenGroesse/1024,1)) KB - Grenze 64 KB."
    Write-Sub "Meist verursacht durch zu viele Ausnahmen in der Query."
    Write-Sub "Abhilfe: Ausnahmen zusammenfassen oder Server verschieben."
    exit 1
}
elseif ($eigenschaftenGroesse -gt 49152) {
    Write-Warn2 "Regel-Eigenschaften ca. $([math]::Round($eigenschaftenGroesse/1024,1)) KB - Grenze 64 KB."
    Write-Sub "Bei weiter wachsender Ausnahmeliste wird das eng."
}

Write-Sub "Regel        : $RuleName"
Write-Sub "Anzeigename  : $RuleDisplayName"
Write-Sub "Laufwerke    : $($Drives -join ', ')"
Write-Sub "Schwellwert  : < $ThresholdPercent % frei (Spalte: $MetricColumn)"
Write-Sub "Modus        : $NotificationMode"
Write-Sub "Zeitfenster  : $WindowSize (bin: $bin)"
Write-Sub "Server-Ausnahmen : $($alleServerAusnahmen.Count)"
Write-Sub "Laufwerks-Ausnahmen : $($alleDriveAusnahmen.Count)"
if ($alleDriveAusnahmen.Count -gt 0) {
    foreach ($a in ($alleDriveAusnahmen | Sort-Object)) { Write-Sub "  $a" }
}
Write-Line

# =============================================================================
#  STUFE 4 - ACTION GROUP
# =============================================================================
Write-Head "STUFE 4 - ACTION GROUP"

if ($EmailRecipients.Count -eq 0) {
    Write-Fail "Keine Empfaenger in `$EmailRecipients."
    exit 1
}

Write-Sub "Empfaenger:"
foreach ($e in $EmailRecipients) { Write-Sub "  $($e.Name)  <$($e.Address)>" }
Write-Host ""
Write-Warn2 "'az monitor action-group create' ersetzt die Ressource vollstaendig."
Write-Sub "Im Portal ergaenzte Empfaenger, SMS oder Webhooks gehen dabei verloren."

if ($WhatIfMode) {
    Write-Line
    Write-Head "WHATIF"
    Write-Info2 "Es wird nichts angelegt."
    Write-Host ""
    Write-Sub "Query:"
    Write-Host "    $query" -ForegroundColor DarkGray
    Write-Host ""
    Write-Sub "Condition:"
    Write-Host "    $condition" -ForegroundColor DarkGray
    Write-Host ""
    Write-Sub "Betreff:"
    Write-Host "    $EmailSubjectTemplate" -ForegroundColor DarkGray
    Write-Line
    exit 0
}

# --action email <Name> <Adresse> je Empfaenger
$agArgs = @("monitor","action-group","create",
            "--resource-group",$AlertResourceGroup,
            "--name",$ActionGroupName,
            "--short-name",$ActionGroupShortName)
foreach ($e in $EmailRecipients) {
    $agArgs += @("--action","email",$e.Name,$e.Address)
}
$agArgs += @("-o","json")

Write-Run "Lege Action Group an bzw. aktualisiere sie..."
$ag = Invoke-AzJson $agArgs
if (-not $ag) {
    Write-Fail "Action Group fehlgeschlagen."
    Write-Sub "Ursache: $script:LastAzError"
    exit 1
}
$ActionGroupId = $ag.id
Write-Ok "Action Group bereit: $($ag.name)"
Write-Sub "Empfaenger aktiv: $(@($ag.emailReceivers).Count)"
Write-Line

# =============================================================================
#  STUFE 5 - ALERT-REGEL
# =============================================================================
Write-Head "STUFE 5 - ALERT-REGEL"

Write-Run "Lege Alert-Regel an..."

# Genau einen der beiden Parameter setzen - die API lehnt beide ab.
$modusArgs = switch ($NotificationMode) {
    "AutoResolve" { @("--auto-mitigate","true") }
    "Suppress"    { @("--auto-mitigate","false","--mute-actions-duration",$MuteActionsDuration) }
    default       { $null }
}
if ($null -eq $modusArgs) {
    Write-Fail "`$NotificationMode = '$NotificationMode' ist unbekannt."
    Write-Sub "Erlaubt: 'AutoResolve' oder 'Suppress'."
    exit 1
}

$ruleArgs = @(
    "monitor","scheduled-query","create",
    "--name", $RuleName,
    "--resource-group", $AlertResourceGroup,
    "--scopes", $WorkspaceResourceId,
    "--location", $Location,
    "--description", $description,
    "--severity", "$Severity",
    "--evaluation-frequency", $EvaluationFrequency,
    "--window-size", $WindowSize,
    "--action-groups", $ActionGroupId,
    "--condition", $condition,
    "--condition-query", "Placeholder_1=$query",
    "--target-resource-type", "Microsoft.HybridCompute/machines",
    "--custom-properties", "Laufwerke=$($Drives -join ',')", "Schwellwert=$ThresholdPercent",
    "-o", "json"
) + $modusArgs

$rule = Invoke-AzJson $ruleArgs

if (-not $rule) {
    Write-Fail "Anlage der Alert-Regel fehlgeschlagen."
    Write-Sub "Ursache: $script:LastAzError"
    exit 1
}
Write-Ok "Alert-Regel erstellt."

if ($RuleDisplayName -ne $RuleName) {
    Write-Run "Setze Anzeigenamen..."
    $upd = Invoke-AzJson @("resource","update","--ids",$rule.id,
                           "--set","properties.displayName=$RuleDisplayName",
                           "--api-version","2023-12-01","-o","json")
    if ($upd) { Write-Ok "Anzeigename gesetzt." }
    else      { Write-Warn2 "Anzeigename nicht gesetzt: $script:LastAzError" }
}

Write-Run "Setze dynamischen E-Mail-Betreff..."
$patched = Set-AlertEmailSubject -ActionGroupId $ActionGroupId -Subject $EmailSubjectTemplate
if ($patched) {
    Write-Ok "Betreff gesetzt."
    Write-Sub $EmailSubjectTemplate
}
else {
    Write-Warn2 "Betreff nicht gesetzt: $script:LastAzError"
    Write-Sub "Die Regel funktioniert trotzdem - nur mit Standard-Betreff."
}
Write-Line

# =============================================================================
#  ZUSAMMENFASSUNG
# =============================================================================
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "Regel               : $RuleName"
Write-Sub "Workspace           : $WorkspaceName"
Write-Sub "Laufwerke           : $($Drives -join ', ')"
Write-Sub "Schwellwert         : < $ThresholdPercent % frei"
Write-Sub "Auswertung          : alle $EvaluationFrequency ueber $WindowSize"
Write-Sub "Ausloesung          : $MinFailingPeriods von $NumberOfEvalPeriods Perioden"
Write-Sub "Benachrichtigung    : $NotificationMode$(if ($NotificationMode -eq 'Suppress') { " ($MuteActionsDuration)" })"
Write-Sub "Splitting           : je Server UND Laufwerk eine eigene Alert-Instanz"
Write-Sub "Empfaenger          : $(@($EmailRecipients).Count)"
Write-Sub "Server-Ausnahmen    : $($alleServerAusnahmen.Count)"
Write-Sub "Laufwerks-Ausnahmen : $($alleDriveAusnahmen.Count)"
Write-Host ""
Write-Info2 "Beispiel-Betreff im Alarmfall:"
Write-Sub "mxkkr8 D: - unter 15 % frei (Fired, 0.92 % frei)"
Write-Host ""
Write-Info2 "Dokumentierte Grenzwerte im Blick behalten:"
Write-Sub "Stateful-Regel: max. 300 Alarme JE AUSWERTUNG. Bei $(@($Drives).Count) Laufwerken"
Write-Sub "  und wachsendem Serverbestand kann ein Grossereignis das erreichen -"
Write-Sub "  Azure kappt dann still."
Write-Sub "E-Mail: max. 100 Mails pro Stunde JE ADRESSE und Region, und 100"
Write-Sub "  Benachrichtigungen alle 5 Minuten je Alert-Regel. Bei vielen"
Write-Sub "  gleichzeitig betroffenen Laufwerken greift das Rate Limit -"
Write-Sub "  ebenfalls ohne Fehlermeldung."
Write-Sub "Regel-Eigenschaften: aktuell ca. $([math]::Round($eigenschaftenGroesse/1024,1)) KB von 64 KB."
Write-Host ""
Write-Warn2 "Momentaufnahme:"
Write-Sub "Tag-Ausnahmen wurden JETZT aufgeloest und fest in die Query geschrieben."
Write-Sub "Neue Disk-Tags oder neue Server ohne Maschinen-Tags wirken erst nach"
Write-Sub "einem erneuten Lauf dieses Scripts."
Write-Host ""
Write-Info2 "Kontrolle:"
Write-Sub "az monitor scheduled-query show -g $AlertResourceGroup -n $RuleName --query actions"
Write-Line
