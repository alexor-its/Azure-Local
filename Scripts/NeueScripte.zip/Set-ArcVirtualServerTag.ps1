#Requires -Version 5.1
<#
.SYNOPSIS
    SCHRITT 0 von 6 - Setzt das Tag Monitoring=VirtualServer auf allen
    Arc-Maschinen, deren Resource Group auf 'VMs' endet.
.DESCRIPTION
    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen (dieses Script)
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung

    AENDERUNG IN 2.0.0 - RESOURCE GROUP STATT DCR-ABLEITUNG
    -------------------------------------------------------------------------
    Bis 1.x wurde das Tag aus den Associations der Change-Tracking-DCR
    abgeleitet. Dieses Vorgehen ist zirkulaer und deshalb nicht belastbar:

        Tag  ->  steuert die Policy
                 ->  setzt die DCR-Zuordnung
                     ->  war die Quelle fuer den Tag

    Eine Maschine ohne CT-DCR konnte damit nie in den Kreis gelangen - sie
    bekam kein Tag, deshalb griff die Policy nicht, deshalb blieb sie ohne
    DCR. Genau dieser Fall trat bei apldeponie1 und v-gatewaykkr4 auf.

    Kriterium ist jetzt die Resource Group: Endet ihr Name auf 'VMs', gilt
    die Maschine als Virtual Server. Die Zuordnung steht damit beim
    Onboarding fest und haengt an keinem Monitoring-Zustand.

    SICHERHEITSNETZE
    -------------------------------------------------------------------------
    Die Resource Group ist massgeblich - das Script ueberstimmt sie nicht.
    Es meldet aber, wenn eine Maschine im Zielbereich nach Namensmuster
    oder Hardware KEIN Virtual Server zu sein scheint. Diese Faelle werden
    einzeln aufgelistet, damit die Entscheidung bewusst faellt.

    Ebenso werden Maschinen genannt, die das Tag tragen, obwohl ihre
    Resource Group nicht mehr passt (Verwaiste). Entfernt werden sie nur
    auf ausdrueckliche Anweisung ueber $RemoveOrphans.

    WICHTIG ZU 'az resource tag'
    -------------------------------------------------------------------------
    Ohne den Schalter --is-incremental ERSETZT der Befehl alle vorhandenen
    Tags. Auf mskkr2 waeren damit 'Role: Domain Controller' und die
    Update-Tags weg. Das Script verwendet den Schalter deshalb immer.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 20.08.2026
    Version     : 2.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Set-ArcVirtualServerTag.ps1
.EXAMPLE
    # Erst ansehen, was passieren wuerde
    $WhatIfMode = $true; .\Set-ArcVirtualServerTag.ps1
#>

# Python-Warnungen aus CLI-Extensions unterdruecken (sonst stderr-Rauschen,
# das PowerShell als NativeCommandError wertet)
$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

$SubscriptionId   = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local

# --- Kriterium ---
# Resource Groups, deren Name auf diese Zeichenfolge endet, gelten als
# Virtual-Server-Bereich. Der Vergleich ist NICHT case-sensitiv
# (rg-azlocalkkr1-VMs und rg-test-vms treffen beide zu).
$RgSuffix         = "VMs"

# --- Tag ---
$TagName          = "Monitoring"
$TagValue         = "VirtualServer"

# --- Sicherheitsnetze (melden, nicht ueberstimmen) ---
$WarnNamePatterns = @('^avd')     # Namen, die untypisch fuer Virtual Server sind
$WarnPhysical     = $true         # Hardware-Erkennung als Plausibilitaetspruefung
$VirtualModelPatterns  = @('Virtual Machine', 'VMware Virtual', 'HVM domU', 'KVM', 'QEMU')
$VirtualVendorPatterns = @('Microsoft Corporation', 'VMware', 'QEMU', 'Xen', 'Nutanix', 'Parallels')

# --- Verwaiste Tags ---
# Maschinen mit dem Tag, deren Resource Group nicht mehr passt.
$RemoveOrphans    = $false        # $true = Tag dort entfernen

# --- Sonstiges ---
$WhatIfMode       = $false

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    <#
      Ruft Azure CLI auf und liefert sauberes JSON zurueck. Trennt stdout und
      stderr, damit Python-Warnungen der CLI-Extensions das JSON nicht
      zerstoeren. Rueckgabe: PSObject bei Erfolg, $null bei Fehler.
      Fehlertext steht danach in $script:LastAzError.
    #>
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort erhalten: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Ensure-Extension {
    param([Parameter(Mandatory)][string]$Name)
    $exts = Invoke-AzJson @("extension","list")
    if ($exts | Where-Object { $_.name -eq $Name }) { return $true }
    Write-Warn2 "Extension '$Name' fehlt - wird installiert."
    az extension add --name $Name --only-show-errors 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Installation von '$Name' fehlgeschlagen."; return $false }
    return $true
}

function Test-IsVirtual {
    <#
      Erst das Modell pruefen, dann den Hersteller: ein physischer
      Hyper-V-Host meldet ebenfalls 'Microsoft Corporation', aber ein echtes
      Servermodell. Ohne jede Angabe wird nichts behauptet -> $null.
    #>
    param([string]$Model, [string]$Manufacturer)

    if ([string]::IsNullOrWhiteSpace($Model) -and [string]::IsNullOrWhiteSpace($Manufacturer)) {
        return $null
    }
    foreach ($p in $VirtualModelPatterns) { if ($Model -like "*$p*") { return $true } }
    if (-not [string]::IsNullOrWhiteSpace($Model)) { return $false }
    foreach ($p in $VirtualVendorPatterns) { if ($Manufacturer -like "*$p*") { return $true } }
    return $false
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - bitte 'az upgrade' ausfuehren."
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
    Write-Ok "Subscription gesetzt."
}

Write-Run "Pruefe Extension 'resource-graph'..."
if (-not (Ensure-Extension -Name "resource-graph")) { exit 1 }
Write-Ok "Extension verfuegbar."
Write-Line

# =============================================================================
#  STUFE 1 - INVENTAR
# =============================================================================
Write-Head "STUFE 1 - INVENTAR"

Write-Run "Lade Arc-Maschinen aus Resource Graph..."

# Nur einfache Anfuehrungszeichen - doppelte ueberleben az.cmd unter Windows nicht.
$argQuery = "resources " `
  + "| where type =~ 'microsoft.hybridcompute/machines' " `
  + "| project id, name, resourceGroup, " `
  +   "status = tostring(properties.status), " `
  +   "model = tostring(properties.detectedProperties.model), " `
  +   "manufacturer = tostring(properties.detectedProperties.manufacturer), " `
  +   "TagWert = tostring(tags['$TagName'])"

$argRes = Invoke-AzJson @("graph","query","-q",$argQuery,"--first","1000","-o","json")
if (-not $argRes -or -not $argRes.data) {
    Write-Fail "Arc-Inventar nicht abrufbar: $script:LastAzError"
    exit 1
}
$machines = @($argRes.data)
Write-Ok "$($machines.Count) Arc-Maschine(n) gefunden."
if ($machines.Count -ge 1000) {
    Write-Warn2 "Limit von 1000 erreicht - Ergebnis moeglicherweise unvollstaendig."
}
Write-Line

# =============================================================================
#  STUFE 2 - KLASSIFIZIERUNG
# =============================================================================
Write-Head "STUFE 2 - KLASSIFIZIERUNG"
Write-Sub "Kriterium: Resource Group endet auf '$RgSuffix' (nicht case-sensitiv)"

$zuSetzen   = @()   # im Zielbereich, Tag fehlt oder weicht ab
$bereitsOk  = @()   # im Zielbereich, Tag stimmt
$verwaist   = @()   # ausserhalb, traegt aber das Tag
$auffaellig = @()   # im Zielbereich, sieht aber nicht nach Virtual Server aus

foreach ($m in $machines) {

    $imZiel = $m.resourceGroup.ToLower().EndsWith($RgSuffix.ToLower())

    if ($imZiel) {
        # --- Plausibilitaetspruefung, ueberstimmt das RG-Kriterium NICHT ---
        $grund = $null
        foreach ($p in $WarnNamePatterns) {
            if ($m.name -match $p) { $grund = "Name passt auf '$p'"; break }
        }
        if (-not $grund -and $WarnPhysical) {
            $virt = Test-IsVirtual -Model $m.model -Manufacturer $m.manufacturer
            if ($virt -eq $false) { $grund = "Hardware: $($m.model)" }
        }
        if ($grund) {
            $auffaellig += [PSCustomObject]@{
                Server = $m.name; RG = $m.resourceGroup; Grund = $grund
            }
        }

        if ($m.TagWert -eq $TagValue) { $bereitsOk += $m }
        else                          { $zuSetzen  += $m }
    }
    elseif ($m.TagWert -eq $TagValue) {
        $verwaist += $m
    }
}

Write-Host ""
Write-Ok "Im Zielbereich, Tag bereits korrekt : $($bereitsOk.Count)"
if ($zuSetzen.Count -gt 0) { Write-Info2 "Im Zielbereich, Tag wird gesetzt    : $($zuSetzen.Count)" }
else                        { Write-Ok    "Im Zielbereich, Tag wird gesetzt    : 0" }
if ($verwaist.Count -gt 0)  { Write-Warn2 "Ausserhalb, tragen aber das Tag     : $($verwaist.Count)" }

# --- Resource Groups im Zielbereich auflisten ---
$rgs = @($machines | Where-Object { $_.resourceGroup.ToLower().EndsWith($RgSuffix.ToLower()) } |
         Group-Object resourceGroup | Sort-Object Name)
if ($rgs.Count -gt 0) {
    Write-Host ""
    Write-Info2 "Betroffene Resource Groups:"
    foreach ($g in $rgs) { Write-Sub ("{0,-40} {1,4} Maschine(n)" -f $g.Name, $g.Count) }
}
Write-Line

# =============================================================================
#  STUFE 3 - AUFFAELLIGKEITEN
# =============================================================================
if ($auffaellig.Count -gt 0) {
    Write-Head "STUFE 3 - BITTE PRUEFEN"
    Write-Warn2 "$($auffaellig.Count) Maschine(n) im Zielbereich sehen nicht nach Virtual Server aus."
    Write-Sub "Die Resource Group ist massgeblich - sie werden trotzdem getaggt."
    Write-Sub "Falls das nicht gewollt ist: Maschine verschieben oder `$RgSuffix schaerfen."
    Write-Host ""
    foreach ($a in ($auffaellig | Sort-Object Server)) {
        Write-Host ("    {0,-24} {1,-34} {2}" -f $a.Server, $a.RG, $a.Grund) -ForegroundColor Yellow
    }
    Write-Line
}

if ($verwaist.Count -gt 0) {
    Write-Head "VERWAISTE TAGS"
    Write-Sub "Diese Maschinen tragen '$TagName=$TagValue', liegen aber nicht"
    Write-Sub "in einer Resource Group auf '$RgSuffix'."
    Write-Host ""
    foreach ($v in ($verwaist | Sort-Object name)) {
        Write-Host ("    {0,-24} {1}" -f $v.name, $v.resourceGroup) -ForegroundColor Yellow
    }
    Write-Host ""
    if ($RemoveOrphans) { Write-Warn2 "Das Tag wird dort entfernt (`$RemoveOrphans = `$true)." }
    else                { Write-Info2 "Bleiben unveraendert. Zum Entfernen `$RemoveOrphans = `$true setzen." }
    Write-Line
}

# =============================================================================
#  STUFE 4 - ANWENDEN
# =============================================================================
Write-Head "STUFE 4 - ANWENDEN"

if ($zuSetzen.Count -eq 0 -and -not ($RemoveOrphans -and $verwaist.Count -gt 0)) {
    Write-Ok "Nichts zu tun - alle Tags sind bereits korrekt."
    Write-Line
    Write-Info2 "Naechster Schritt: .\New-ArcVmInsightsDcr.ps1"
    Write-Line
    exit 0
}

if ($WhatIfMode) {
    Write-Info2 "WhatIf-Modus - es wird nichts geaendert."
    Write-Host ""
    foreach ($m in ($zuSetzen | Sort-Object name)) {
        $bisher = if ([string]::IsNullOrWhiteSpace($m.TagWert)) { "(kein Tag)" } else { $m.TagWert }
        Write-Host ("    {0,-24} {1,-34} {2} -> {3}" -f `
                    $m.name, $m.resourceGroup, $bisher, $TagValue) -ForegroundColor Cyan
    }
    if ($RemoveOrphans) {
        foreach ($v in ($verwaist | Sort-Object name)) {
            Write-Host ("    {0,-24} {1,-34} Tag wuerde entfernt" -f `
                        $v.name, $v.resourceGroup) -ForegroundColor Yellow
        }
    }
    Write-Line
    exit 0
}

$ok = 0; $err = 0

if ($zuSetzen.Count -gt 0) {
    Write-Run "Setze Tag auf $($zuSetzen.Count) Maschine(n)..."
    Write-Host ""

    foreach ($m in ($zuSetzen | Sort-Object name)) {
        # --is-incremental ist Pflicht: ohne den Schalter ersetzt der Befehl
        # ALLE vorhandenen Tags der Ressource.
        $null = Invoke-AzJson @("resource","tag","--ids",$m.id,
                                "--tags","$TagName=$TagValue",
                                "--is-incremental","-o","json")
        if ($null -eq $script:LastAzError) {
            Write-Host ("    {0,-24} {1,-34} gesetzt" -f $m.name, $m.resourceGroup) -ForegroundColor Green
            $ok++
        }
        else {
            Write-Host ("    {0,-24} {1,-34} FEHLER" -f $m.name, $m.resourceGroup) -ForegroundColor Red
            Write-Sub "  $script:LastAzError"
            $err++
        }
    }
}

if ($RemoveOrphans -and $verwaist.Count -gt 0) {
    Write-Host ""
    Write-Run "Entferne Tag von $($verwaist.Count) verwaisten Maschine(n)..."
    Write-Host ""

    foreach ($v in ($verwaist | Sort-Object name)) {
        # Leerer Wert entfernt das Tag; --is-incremental haelt die uebrigen.
        $null = Invoke-AzJson @("resource","tag","--ids",$v.id,
                                "--tags","$TagName=",
                                "--is-incremental","-o","json")
        if ($null -eq $script:LastAzError) {
            Write-Host ("    {0,-24} {1,-34} entfernt" -f $v.name, $v.resourceGroup) -ForegroundColor Green
            $ok++
        }
        else {
            Write-Host ("    {0,-24} {1,-34} FEHLER" -f $v.name, $v.resourceGroup) -ForegroundColor Red
            Write-Sub "  $script:LastAzError"
            $err++
        }
    }
}
Write-Line

# =============================================================================
#  ZUSAMMENFASSUNG
# =============================================================================
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "Kriterium         : Resource Group endet auf '$RgSuffix'"
Write-Sub "Tag               : $TagName = $TagValue"
Write-Sub "Arc-Maschinen     : $($machines.Count)"
Write-Sub "Bereits korrekt   : $($bereitsOk.Count)"
Write-Sub "Geaendert         : $ok"
if ($err -gt 0)          { Write-Fail  "Fehlgeschlagen    : $err" }
if ($auffaellig.Count)   { Write-Warn2 "Zur Pruefung      : $($auffaellig.Count)" }
if ($verwaist.Count -and -not $RemoveOrphans) {
    Write-Warn2 "Verwaiste Tags    : $($verwaist.Count) (unveraendert)"
}

Write-Host ""
Write-Info2 "Ergebnis pruefen:"
Write-Sub "az graph query -q `"resources | where type =~ 'microsoft.hybridcompute/machines' | summarize Anzahl = count() by Tag = tostring(tags['$TagName'])`" --query data -o table"
Write-Host ""
Write-Info2 "Naechster Schritt: .\New-ArcVmInsightsDcr.ps1"
Write-Sub "Danach .\New-ArcMonitoringPolicy.ps1 - die Policy haengt an diesem Tag."
Write-Line
