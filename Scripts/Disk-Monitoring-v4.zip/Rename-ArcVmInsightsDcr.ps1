#Requires -Version 5.1
<#
.SYNOPSIS
    Benennt die gemeinsame VM-Insights-DCR um, indem sie unter neuem Namen
    angelegt, alle Zuordnungen umgehaengt und die alte DCR entfernt wird.
.DESCRIPTION
    Ergaenzung zur Script-Reihe:
      1. New-ArcVmInsightsDcr.ps1         - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1     - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1      - Policy + RBAC + Remediation
      4. New-ArcDiskSpaceAlert.ps1        - E-Mail-Alert einrichten
      +  Rename-ArcVmInsightsDcr.ps1      - DCR umbenennen (dieses Script)

    WARUM EIN EIGENES SCRIPT
    -------------------------------------------------------------------------
    Ressourcennamen sind in Azure unveraenderlich. Eine DCR laesst sich nicht
    umbenennen - nur neu anlegen und die alte entfernen. Dabei haengen zwei
    Dinge daran, die in der falschen Reihenfolge Datenverlust erzeugen:

      Zuordnungen  Ein PUT auf denselben Association-Namen mit neuer
                   dataCollectionRuleId ersetzt das Ziel in EINEM Schritt.
                   Loeschen und neu anlegen wuerde je Server eine Luecke im
                   Datenfluss erzeugen - deshalb wird ueberschrieben.

      Policy       Ihr Parameter dcrResourceId zeigt auf die alte DCR. Ohne
                   Anpassung legt die naechste Remediation die Zuordnungen
                   wieder auf die alte - dann geloeschte - DCR zurueck.

    ABLAUF
    -------------------------------------------------------------------------
      1. Alte DCR lesen und Definition uebernehmen (nicht neu bauen)
      2. Neue DCR unter neuem Namen anlegen
      3. Zuordnungen der alten DCR ermitteln
      4. Je Maschine die Association auf die neue DCR umschreiben
      5. Ergebnis pruefen: neue DCR muss mindestens so viele Zuordnungen haben
      6. Policy-Zuweisung auf die neue DCR-ID umstellen
      7. Alte DCR loeschen - nur wenn Schritt 5 sauber war

    Die Schritte 6 und 7 sind einzeln abschaltbar. Schritt 7 laeuft ausserdem
    nur, wenn die Pruefung in Schritt 5 bestanden wurde.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 20.08.2026
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Rename-ArcVmInsightsDcr.ps1
.EXAMPLE
    # Erst ansehen, was passieren wuerde
    $WhatIfMode = $true; .\Rename-ArcVmInsightsDcr.ps1
#>

# Python-Warnungen aus CLI-Extensions unterdruecken (sonst stderr-Rauschen,
# das PowerShell als NativeCommandError wertet)
$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

$SubscriptionId     = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local
$DcrResourceGroup   = "rg-arcmgmt"

# --- Umbenennung ---
$AlterDcrName       = "dcr-vminsights-virtualserver"
$NeuerDcrName       = "law-LDK-VirtualServer-vminsights-dcr"

# --- Policy, die auf die DCR verweist (aus Script 3) ---
$PolicyAssignName   = "arc-vs-vminsights-dcr"
$PolicyAnpassen     = $true
$PolicyScope        = "/subscriptions/33207861-9482-4afb-9786-eba3a0265bef"
$AssociationName    = "dcra-vminsights-virtualserver"   # Parameter der Policy

# --- Aufraeumen ---
$AlteDcrLoeschen    = $true    # nur nach bestandener Pruefung

# --- Sonstiges ---
$ApiVersion         = "2023-03-11"
$WhatIfMode         = $false

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    <#
      Ruft Azure CLI auf und liefert sauberes JSON zurueck. Trennt stdout und
      stderr, damit Python-Warnungen der CLI-Extensions das JSON nicht
      zerstoeren. Rueckgabe: PSObject bei Erfolg, $null bei Fehler.
      Fehlertext steht danach in $script:LastAzError.
    #>
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort erhalten: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Invoke-AzRestBody {
    <#
      az-rest-Aufruf mit JSON-Body. Der Body geht ueber eine Temp-Datei, weil
      az.cmd Inline-JSON unter Windows falsch zerlegt.
    #>
    param(
        [Parameter(Mandatory)][string]$Method,
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)]$Body
    )
    $file = Join-Path $env:TEMP "azrest-$([guid]::NewGuid()).json"
    $Body | ConvertTo-Json -Depth 30 | Set-Content -Path $file -Encoding UTF8
    try {
        return Invoke-AzJson @(
            "rest","--method",$Method,"--url",$Url,
            "--headers","Content-Type=application/json",
            "--body","@$file"
        )
    }
    finally { Remove-Item $file -ErrorAction SilentlyContinue }
}

function Get-MachineName {
    <#
      Schneidet den Maschinennamen aus einer Association-Ressourcen-ID.
    #>
    param([Parameter(Mandatory)][string]$AssocId)
    $idx = $AssocId.ToLower().IndexOf("/providers/microsoft.insights/datacollectionruleassociations/")
    if ($idx -lt 1) { return $null }
    return ($AssocId.Substring(0, $idx) -split '/')[-1]
}

function Get-MachineId {
    param([Parameter(Mandatory)][string]$AssocId)
    $idx = $AssocId.ToLower().IndexOf("/providers/microsoft.insights/datacollectionruleassociations/")
    if ($idx -lt 1) { return $null }
    return $AssocId.Substring(0, $idx)
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - bitte 'az upgrade' ausfuehren."
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
    Write-Ok "Subscription gesetzt."
}
Write-Line

# =============================================================================
#  STUFE 1 - ALTE DCR LESEN
# =============================================================================
Write-Head "STUFE 1 - ALTE DCR"

$AlteId  = "/subscriptions/$SubscriptionId/resourceGroups/$DcrResourceGroup" `
         + "/providers/Microsoft.Insights/dataCollectionRules/$AlterDcrName"
$AlteUrl = "https://management.azure.com$($AlteId)?api-version=$ApiVersion"

Write-Run "Lese '$AlterDcrName'..."
$alt = Invoke-AzJson @("rest","--method","get","--url",$AlteUrl)
if (-not $alt) {
    Write-Fail "Alte DCR nicht gefunden: $script:LastAzError"
    Write-Sub "Falls sie bereits umbenannt wurde, ist nichts zu tun."
    exit 1
}
Write-Ok "Gefunden: $($alt.name) ($($alt.location))"

$ziele = @()
if ($alt.properties.destinations.logAnalytics) {
    foreach ($d in $alt.properties.destinations.logAnalytics) {
        $ziele += ($d.workspaceResourceId -split '/')[-1]
    }
}
Write-Sub "Ziel        : $($ziele -join ', ')"
Write-Sub "immutableId : $($alt.properties.immutableId)"
Write-Line

# =============================================================================
#  STUFE 2 - ZUORDNUNGEN DER ALTEN DCR
# =============================================================================
Write-Head "STUFE 2 - BESTEHENDE ZUORDNUNGEN"

Write-Run "Lade Zuordnungen..."
$assocUrl = "https://management.azure.com$($AlteId)/associations?api-version=$ApiVersion"
$assocRes = Invoke-AzJson @("rest","--method","get","--url",$assocUrl)
$assocs   = if ($assocRes -and $assocRes.value) { @($assocRes.value) } else { @() }

if ($assocs.Count -eq 0) {
    Write-Warn2 "Keine Zuordnungen an der alten DCR."
    Write-Sub "Die Umbenennung laeuft trotzdem, es ist nur nichts umzuhaengen."
}
else {
    Write-Ok "$($assocs.Count) Zuordnung(en) gefunden."
}
Write-Line

# =============================================================================
#  STUFE 3 - NEUE DCR ANLEGEN
# =============================================================================
Write-Head "STUFE 3 - NEUE DCR"

$NeueId  = "/subscriptions/$SubscriptionId/resourceGroups/$DcrResourceGroup" `
         + "/providers/Microsoft.Insights/dataCollectionRules/$NeuerDcrName"
$NeueUrl = "https://management.azure.com$($NeueId)?api-version=$ApiVersion"

Write-Sub "Alt : $AlterDcrName"
Write-Sub "Neu : $NeuerDcrName"

# Definition der alten DCR uebernehmen statt neu zu bauen. Damit ist
# ausgeschlossen, dass sich beim Umbenennen ungewollt der Inhalt aendert.
$neuBody = @{
    location   = $alt.location
    properties = @{
        description  = "Gemeinsame VM-Insights-DCR fuer alle Arc Virtual Server."
        dataSources  = $alt.properties.dataSources
        destinations = $alt.properties.destinations
        dataFlows    = $alt.properties.dataFlows
    }
}
if ($alt.kind) { $neuBody["kind"] = $alt.kind }

if ($WhatIfMode) {
    Write-Line
    Write-Info2 "WhatIf-Modus - es wird nichts geaendert."
    Write-Sub "Neue DCR wuerde angelegt mit:"
    Write-Host ($neuBody | ConvertTo-Json -Depth 30)
    Write-Sub "$($assocs.Count) Zuordnung(en) wuerden umgehaengt."
    if ($PolicyAnpassen)  { Write-Sub "Policy '$PolicyAssignName' wuerde umgestellt." }
    if ($AlteDcrLoeschen) { Write-Sub "Alte DCR '$AlterDcrName' wuerde geloescht." }
    Write-Line
    exit 0
}

Write-Run "Lege neue DCR an..."
$neu = Invoke-AzRestBody -Method "put" -Url $NeueUrl -Body $neuBody
if (-not $neu) {
    Write-Fail "Neue DCR konnte nicht angelegt werden."
    Write-Sub "Ursache: $script:LastAzError"
    Write-Sub "Es wurde nichts veraendert - die alte DCR laeuft weiter."
    exit 1
}
Write-Ok "Angelegt: $($neu.name)"
Write-Sub "immutableId : $($neu.properties.immutableId)"
Write-Line

# =============================================================================
#  STUFE 4 - ZUORDNUNGEN UMHAENGEN
# =============================================================================
Write-Head "STUFE 4 - ZUORDNUNGEN UMHAENGEN"

$ok = 0; $err = 0

foreach ($a in $assocs) {

    $server = Get-MachineName -AssocId $a.id
    $mid    = Get-MachineId   -AssocId $a.id
    if (-not $server -or -not $mid) {
        Write-Warn2 "Unerwartete Association-ID: $($a.id)"
        $err++
        continue
    }

    # Denselben Association-Namen wiederverwenden. Das PUT ersetzt das Ziel
    # in einem Schritt - kein Loeschen, keine Luecke im Datenfluss.
    $url = "https://management.azure.com$mid/providers/Microsoft.Insights" `
         + "/dataCollectionRuleAssociations/$($a.name)?api-version=$ApiVersion"

    $body = @{
        properties = @{
            dataCollectionRuleId = $NeueId
            description          = "VM Insights -> $($ziele -join ', ')"
        }
    }

    $res = Invoke-AzRestBody -Method "put" -Url $url -Body $body
    if ($res) {
        Write-Host ("    {0,-26} {1}" -f $server, "umgehaengt") -ForegroundColor Green
        $ok++
    }
    else {
        Write-Host ("    {0,-26} {1}" -f $server, "FEHLER") -ForegroundColor Red
        Write-Sub "  $script:LastAzError"
        $err++
    }
}

Write-Host ""
Write-Ok "Umgehaengt : $ok"
if ($err -gt 0) { Write-Fail "Fehlgeschlagen: $err" }
Write-Line

# =============================================================================
#  STUFE 5 - PRUEFUNG
# =============================================================================
Write-Head "STUFE 5 - PRUEFUNG"

Write-Run "Zaehle Zuordnungen an der neuen DCR..."
$neuAssocUrl = "https://management.azure.com$($NeueId)/associations?api-version=$ApiVersion"
$neuAssocRes = Invoke-AzJson @("rest","--method","get","--url",$neuAssocUrl)
$neuAssocs   = if ($neuAssocRes -and $neuAssocRes.value) { @($neuAssocRes.value) } else { @() }

Write-Sub "Alte DCR hatte : $($assocs.Count)"
Write-Sub "Neue DCR hat   : $($neuAssocs.Count)"

$pruefungOk = ($err -eq 0) -and ($neuAssocs.Count -ge $assocs.Count)

if ($pruefungOk) { Write-Ok "Pruefung bestanden." }
else {
    Write-Fail "Pruefung NICHT bestanden."
    Write-Sub "Die alte DCR wird deshalb nicht geloescht."
    Write-Sub "Beide DCRs existieren jetzt parallel - bitte manuell klaeren."
}
Write-Line

# =============================================================================
#  STUFE 6 - POLICY UMSTELLEN
# =============================================================================
Write-Head "STUFE 6 - POLICY"

if (-not $PolicyAnpassen) {
    Write-Warn2 "Uebersprungen (`$PolicyAnpassen = `$false)."
    Write-Sub "ACHTUNG: Zeigt die Policy noch auf die alte DCR, legt die"
    Write-Sub "naechste Remediation die Zuordnungen dorthin zurueck."
}
else {
    Write-Run "Lese Policy-Zuweisung '$PolicyAssignName'..."
    $pa = Invoke-AzJson @("policy","assignment","show",
                          "--name",$PolicyAssignName,
                          "--scope",$PolicyScope,"-o","json")
    if (-not $pa) {
        Write-Warn2 "Zuweisung nicht gefunden: $script:LastAzError"
        Write-Sub "Falls die Policy anders heisst, `$PolicyAssignName anpassen."
    }
    else {
        $altZiel = $pa.parameters.dcrResourceId.value
        Write-Sub "Bisher : $altZiel"
        Write-Sub "Neu    : $NeueId"

        if ($altZiel -eq $NeueId) {
            Write-Ok "Zeigt bereits auf die neue DCR."
        }
        else {
            $parFile = Join-Path $env:TEMP "polparam-$([guid]::NewGuid()).json"
            @{
                effect          = @{ value = $pa.parameters.effect.value }
                dcrResourceId   = @{ value = $NeueId }
                associationName = @{ value = $AssociationName }
            } | ConvertTo-Json -Depth 10 | Set-Content -Path $parFile -Encoding UTF8

            Write-Run "Stelle Zuweisung um..."
            $upd = Invoke-AzJson @("policy","assignment","update",
                                   "--name",$PolicyAssignName,
                                   "--scope",$PolicyScope,
                                   "--params","@$parFile","-o","json")
            Remove-Item $parFile -ErrorAction SilentlyContinue

            if ($upd) { Write-Ok "Policy zeigt jetzt auf '$NeuerDcrName'." }
            else {
                Write-Fail "Policy konnte nicht umgestellt werden."
                Write-Sub "Ursache: $script:LastAzError"
                Write-Sub "Bitte manuell anpassen, sonst faellt die Zuordnung zurueck."
                $pruefungOk = $false
            }
        }
    }
}
Write-Line

# =============================================================================
#  STUFE 7 - ALTE DCR LOESCHEN
# =============================================================================
Write-Head "STUFE 7 - AUFRAEUMEN"

if (-not $AlteDcrLoeschen) {
    Write-Info2 "Uebersprungen (`$AlteDcrLoeschen = `$false)."
    Write-Sub "Alte DCR bleibt bestehen: $AlterDcrName"
    Write-Sub "Sie sammelt nichts mehr, kostet aber auch nichts."
}
elseif (-not $pruefungOk) {
    Write-Warn2 "Nicht geloescht - vorherige Pruefung nicht bestanden."
    Write-Sub "Manuell loeschen erst nach Klaerung:"
    Write-Sub "az rest --method delete --url `"https://management.azure.com$($AlteId)?api-version=$ApiVersion`""
}
else {
    Write-Run "Loesche '$AlterDcrName'..."
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    az rest --method delete --url $AlteUrl 2>$null
    $delCode = $LASTEXITCODE
    $ErrorActionPreference = $prevEap

    if ($delCode -eq 0) { Write-Ok "Alte DCR geloescht." }
    else {
        Write-Warn2 "Loeschen fehlgeschlagen (Exit $delCode)."
        Write-Sub "Bitte im Portal pruefen - die neue DCR ist bereits aktiv."
    }
}
Write-Line

# =============================================================================
#  ZUSAMMENFASSUNG
# =============================================================================
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "Alte DCR      : $AlterDcrName"
Write-Sub "Neue DCR      : $NeuerDcrName"
Write-Sub "Umgehaengt    : $ok von $($assocs.Count)"
Write-Sub "Policy        : $(if ($PolicyAnpassen) { $PolicyAssignName } else { 'nicht angepasst' })"
Write-Host ""
Write-Warn2 "Konfiguration in den anderen Scripts nachziehen:"
Write-Sub "New-ArcVmInsightsDcr.ps1  -> `$DcrName = '$NeuerDcrName'"
Write-Sub "New-ArcMonitoringPolicy.ps1 -> `$DcrName = '$NeuerDcrName'"
Write-Sub "ArcDiskSpace.workbook     -> Name im Kopftext"
Write-Host ""
Write-Info2 "Datenfluss nach 15 Minuten pruefen:"
Write-Sub ".\Test-ArcMonitoringPrereq.ps1"
Write-Line
