﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Laedt das Azure Local LENS Workbook in der aktuellen Version herunter und
    aktualisiert das bestehende Workbook in Azure (oder legt es neu an).
.DESCRIPTION
    Das Script laedt die jeweils aktuelle Release-Version des Azure Local LENS
    Workbooks (Lifecycle, Events & Notification Status) aus dem offiziellen
    GitHub-Repository (Azure/AzureLocal-LENS-Workbook) herunter.

    Anschliessend wird das Workbook ueber einen deterministischen
    Ressourcennamen (GUID aus MD5 von Anzeigename + Ressourcengruppe)
    direkt adressiert:
    - Existiert die Ressource, wird sie per PUT (az rest) aktualisiert.
      Ist die deployte LENS-Version (Tag 'WorkbookVersion') bereits aktuell,
      wird das Deployment uebersprungen (ausser $ForceUpdate = $true).
    - Existiert sie nicht (z. B. beim ersten Lauf), wird das Workbook neu
      in der Region $WorkbookLocation erstellt. Folgelaeufe aktualisieren
      dieselbe Ressource, da die GUID deterministisch ist.

    Die deployte Version ist ohne Portal abfragbar ueber die Tags:
      az resource show --ids <ResourceId> --query tags

    Es wird ausschliesslich Azure CLI (az) verwendet, keine Az-PowerShell-Module.

    Subscription-Verhalten: Ist $SubscriptionId im Konfigurationsblock leer,
    wird automatisch die aktuell aktive Subscription des Logins verwendet
    (az account show). Nur wenn dort eine ID eingetragen ist, wird diese
    per 'az account set' gezielt gesetzt.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 08.09.2026
    Version     : 1.1.1
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Update-LensWorkbook.ps1
#>

# =========================================================================
# [ KONFIGURATION / PARAMETER ]
# =========================================================================
$ScriptName          = "Update-LensWorkbook.ps1"
$ScriptVersion       = "1.1.1"

$PowerShellMode      = "Compat"   # "Compat" = 5.1 + 7.x | "Seven" = nur PS 7.x
$ForceUpdate         = $false     # true = Deployment auch bei identischer LENS-Version erzwingen

$SubscriptionId      = ""                                       # Leer = aktuell aktive Subscription (az account show)
                                                                # Optional: Subscription-ID eintragen, um gezielt zu ueberschreiben
$ResourceGroup       = "rg-monitoring"                          # Ressourcengruppe des Workbooks
$WorkbookDisplayName = "Azure Local LENS Workbook"              # Anzeigename des Workbooks in Azure
$WorkbookLocation    = "westeurope"                             # Region (nur bei Neuanlage relevant)

$GitHubRepo          = "Azure/AzureLocal-LENS-Workbook"
$DownloadUrl         = "https://github.com/$GitHubRepo/releases/latest/download/AzureLocal-LENS-Workbook.json"
$ReleaseApiUrl       = "https://api.github.com/repos/$GitHubRepo/releases/latest"
$ApiVersion          = "2023-06-01"                             # API-Version Microsoft.Insights/workbooks

# =========================================================================
# [ GRUNDEINSTELLUNGEN ]
# =========================================================================
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Symbole zur Laufzeit erzeugen (Quellcode bleibt ASCII)
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

# =========================================================================
# [ HILFSFUNKTIONEN ]
# =========================================================================
function Write-Log {
    param(
        [string]$Symbol,
        [string]$Text,
        [string]$Color = "Cyan",
        [int]$Indent = 0
    )
    $TimeStamp = Get-Date -Format "HH:mm:ss"
    $Pad = " " * $Indent
    Write-Host ("[{0}] {1}{2}  {3}" -f $TimeStamp, $Pad, $Symbol, $Text) -ForegroundColor $Color
}

function Write-Section {
    param([string]$Title)
    Write-Host ("=" * 60) -ForegroundColor White
    Write-Host ("[ {0} ]" -f $Title) -ForegroundColor White
}

function Assert-AzSuccess {
    param([string]$Message)
    if ($LASTEXITCODE -ne 0) {
        Write-Log -Symbol $SymErr -Text ("{0} (ExitCode: {1})" -f $Message, $LASTEXITCODE) -Color Red
        Write-Host ("=" * 60) -ForegroundColor White
        exit 1
    }
}

function Invoke-AzQuiet {
    # Fuehrt az mit Argument-Array aus und unterdrueckt stderr-Ausgaben.
    param([string[]]$AzArgs)
    $Output = & az @AzArgs 2>$null
    return $Output
}

function Invoke-AzChecked {
    # Fuehrt az mit Argument-Array aus. Bei Fehler (ExitCode <> 0) wird die
    # komplette az-Ausgabe (inkl. stderr) angezeigt und das Script beendet.
    param(
        [string[]]$AzArgs,
        [string]$ErrorMessage
    )
    $AllOutput = & az @AzArgs 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Log -Symbol $SymErr -Text ("{0} (ExitCode: {1})" -f $ErrorMessage, $LASTEXITCODE) -Color Red
        foreach ($Line in $AllOutput) {
            $LineText = ("" + $Line).Trim()
            if ($LineText.Length -gt 0) {
                Write-Log -Symbol $SymErr -Text $LineText -Color Red -Indent 4
            }
        }
        Write-Host ("=" * 60) -ForegroundColor White
        exit 1
    }
    # Nur Nicht-Fehler-Ausgabe (stdout) zurueckgeben
    $StdOutLines = @($AllOutput | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] })
    return $StdOutLines
}

function ConvertTo-JsonStringLiteral {
    # Escaped einen String fuer die Verwendung als JSON-Stringwert.
    # Bewusst minimal (nur \, ", Steuerzeichen) - Unicode bleibt roh erhalten.
    # Hintergrund: ConvertTo-Json kodiert Sonder-/Unicode-Zeichen als \uXXXX
    # und blaeht grosse Workbook-Templates ueber das ARM-Limit von 4 MB auf.
    param([string]$Text)
    if ($null -eq $Text) { return "" }
    $Escaped = $Text.Replace("\", "\\")
    $Escaped = $Escaped.Replace('"', '\"')
    $Escaped = $Escaped.Replace("`r", "\r")
    $Escaped = $Escaped.Replace("`n", "\n")
    $Escaped = $Escaped.Replace("`t", "\t")
    $Evaluator = [System.Text.RegularExpressions.MatchEvaluator] {
        param($MatchItem)
        return ("\u{0:X4}" -f [int][char]$MatchItem.Value)
    }
    $Escaped = [System.Text.RegularExpressions.Regex]::Replace($Escaped, "[\x00-\x08\x0B\x0C\x0E-\x1F]", $Evaluator)
    return $Escaped
}

function Compress-JsonText {
    # Minifiziert JSON-Text: entfernt Whitespace AUSSERHALB von JSON-Strings.
    # Strings (inkl. escapeter Zeichen) bleiben unangetastet.
    # Hintergrund: Das GitHub-Release-JSON ist pretty-printed; der Workbook-
    # Dienst begrenzt die Inhaltslaenge ("The workbook length is too large").
    # Das Azure Portal minifiziert beim Speichern ebenfalls.
    param([string]$JsonText)
    $Pattern = '("(?:[^"\\]|\\.)*")|\s+'
    $Evaluator = [System.Text.RegularExpressions.MatchEvaluator] {
        param($MatchItem)
        if ($MatchItem.Groups[1].Success) { return $MatchItem.Groups[1].Value }
        return ""
    }
    return [System.Text.RegularExpressions.Regex]::Replace($JsonText, $Pattern, $Evaluator)
}

function Get-DeterministicGuid {
    # Leitet eine stabile GUID aus einem Text ab (MD5, erste 16 Bytes).
    # Derselbe Anzeigename + Ressourcengruppe ergibt immer dieselbe
    # Ressourcen-ID - ein erneuter Lauf aktualisiert das Workbook per PUT,
    # statt ein Duplikat anzulegen. (Pattern aus New-ArcDiskSpaceWorkbook.ps1)
    param([string]$Text)
    $Md5 = [System.Security.Cryptography.MD5]::Create()
    $HashBytes = $Md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Text))
    return ([guid]::new($HashBytes)).ToString()
}

# =========================================================================
# [ TITEL-BANNER ]
# =========================================================================
Write-Host ("=" * 60) -ForegroundColor White
Write-Host ("{0}  -  Version {1}" -f $ScriptName, $ScriptVersion) -ForegroundColor White
Write-Host "Alexander Ortha IT Solutions - https://ortha-itsolutions.de/" -ForegroundColor White

# =========================================================================
# [ PRE-CHECK ]
# =========================================================================
Write-Section -Title "PRE-CHECK"

# --- PowerShell-Version pruefen ---
$PsMajor = $PSVersionTable.PSVersion.Major
$PsMinor = $PSVersionTable.PSVersion.Minor
Write-Log -Symbol $SymInfo -Text ("PowerShell-Version: {0}" -f $PSVersionTable.PSVersion.ToString())

if ($PowerShellMode -eq "Seven" -and $PsMajor -lt 7) {
    Write-Log -Symbol $SymErr -Text "Script ist im Modus 'Seven' konfiguriert und benoetigt PowerShell 7.x." -Color Red
    exit 1
}
if ($PsMajor -gt 7 -or ($PsMajor -eq 7 -and $PsMinor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Log -Symbol $SymInfo -Text "PowerShell 7.3+ erkannt: PSNativeCommandUseErrorActionPreference = false"
}

# --- TLS 1.2 fuer Windows PowerShell 5.1 sicherstellen ---
if ($PsMajor -lt 6) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    Write-Log -Symbol $SymInfo -Text "TLS 1.2 fuer Downloads aktiviert (PowerShell 5.1)"
}

# --- Azure CLI vorhanden? ---
Write-Log -Symbol $SymRun -Text "Pruefe Azure CLI..."
$AzVersionRaw = Invoke-AzQuiet -AzArgs @("version", "--output", "json")
if ($LASTEXITCODE -ne 0 -or -not $AzVersionRaw) {
    Write-Log -Symbol $SymErr -Text "Azure CLI (az) wurde nicht gefunden. Bitte installieren: https://aka.ms/installazurecli" -Color Red
    exit 1
}
$AzVersionJson = ($AzVersionRaw | Out-String | ConvertFrom-Json)
$AzCliVersion  = $AzVersionJson."azure-cli"
Write-Log -Symbol $SymOk -Text ("Azure CLI gefunden: {0}" -f $AzCliVersion) -Color Green

# --- Azure CLI aktuell? (Hinweis) ---
Write-Log -Symbol $SymInfo -Text "Hinweis: Aktualitaet der Azure CLI kann mit 'az upgrade' geprueft/aktualisiert werden." -Indent 4

# --- Azure Login vorhanden? ---
Write-Log -Symbol $SymRun -Text "Pruefe Azure Login..."
$AccountRaw = Invoke-AzQuiet -AzArgs @("account", "show", "--output", "json")
if ($LASTEXITCODE -ne 0 -or -not $AccountRaw) {
    Write-Log -Symbol $SymWarn -Text "Kein aktiver Login gefunden. Starte 'az login'..." -Color Yellow
    az login --output none
    Assert-AzSuccess -Message "Azure Login fehlgeschlagen."
    $AccountRaw = Invoke-AzQuiet -AzArgs @("account", "show", "--output", "json")
    Assert-AzSuccess -Message "Kontoinformationen konnten nach dem Login nicht gelesen werden."
}
$AccountJson = ($AccountRaw | Out-String | ConvertFrom-Json)
Write-Log -Symbol $SymOk -Text ("Login vorhanden: {0}" -f $AccountJson.user.name) -Color Green

# --- Subscription ermitteln / setzen ---
if (("" + $SubscriptionId).Trim().Length -eq 0) {
    # Keine Subscription im Script angegeben -> aktuell aktive Subscription verwenden
    $SubscriptionId = $AccountJson.id
    Write-Log -Symbol $SymInfo -Text ("Keine Subscription im Script angegeben. Verwende aktive Subscription:")
    Write-Log -Symbol $SymInfo -Text ("Name: {0}" -f $AccountJson.name) -Indent 4
    Write-Log -Symbol $SymInfo -Text ("ID  : {0}" -f $SubscriptionId) -Indent 4
}
else {
    Write-Log -Symbol $SymRun -Text ("Setze Subscription (aus Script-Konfiguration): {0}" -f $SubscriptionId)
    az account set --subscription $SubscriptionId --output none
    Assert-AzSuccess -Message ("Subscription '{0}' konnte nicht gesetzt werden." -f $SubscriptionId)
}
Write-Log -Symbol $SymOk -Text "Subscription aktiv." -Color Green

# --- Ressourcengruppe pruefen ---
Write-Log -Symbol $SymRun -Text ("Pruefe Ressourcengruppe: {0}" -f $ResourceGroup)
$RgExists = Invoke-AzQuiet -AzArgs @("group", "exists", "--name", $ResourceGroup, "--output", "tsv")
Assert-AzSuccess -Message "Ressourcengruppen-Pruefung fehlgeschlagen."
if (("" + $RgExists).Trim().ToLower() -ne "true") {
    Write-Log -Symbol $SymErr -Text ("Ressourcengruppe '{0}' existiert nicht in der Subscription." -f $ResourceGroup) -Color Red
    exit 1
}
Write-Log -Symbol $SymOk -Text "Ressourcengruppe gefunden." -Color Green

# =========================================================================
# [ DOWNLOAD - AKTUELLE LENS VERSION ]
# =========================================================================
Write-Section -Title "DOWNLOAD - AKTUELLE LENS VERSION"

# --- Release-Version ermitteln (optional, nur informativ) ---
$ReleaseTag = "unbekannt"
try {
    $ReleaseInfo = Invoke-RestMethod -Uri $ReleaseApiUrl -Headers @{ "User-Agent" = "LENS-Update-Script" } -UseBasicParsing
    if ($ReleaseInfo -and $ReleaseInfo.tag_name) {
        $ReleaseTag = $ReleaseInfo.tag_name
    }
    Write-Log -Symbol $SymInfo -Text ("Aktuelles GitHub-Release: {0}" -f $ReleaseTag)
}
catch {
    Write-Log -Symbol $SymWarn -Text "Release-Version konnte nicht ermittelt werden (GitHub API). Download wird trotzdem versucht." -Color Yellow
}

# --- Workbook-JSON herunterladen ---
Write-Log -Symbol $SymRun -Text ("Lade Workbook-Template: {0}" -f $DownloadUrl)
$TempDownloadFile = Join-Path -Path $env:TEMP -ChildPath ("lens-workbook-download-{0}.json" -f ([guid]::NewGuid().ToString()))
$WorkbookJsonRaw = $null
try {
    # -OutFile statt .Content: garantiert korrekte UTF-8-Dekodierung
    # (bei application/octet-stream dekodiert .Content in PS 5.1 sonst falsch)
    Invoke-WebRequest -Uri $DownloadUrl -OutFile $TempDownloadFile -UseBasicParsing
    $WorkbookJsonRaw = [System.IO.File]::ReadAllText($TempDownloadFile, [System.Text.Encoding]::UTF8)
}
catch {
    Write-Log -Symbol $SymErr -Text ("Download fehlgeschlagen: {0}" -f $_.Exception.Message) -Color Red
    exit 1
}

if (-not $WorkbookJsonRaw -or ("" + $WorkbookJsonRaw).Trim().Length -eq 0) {
    Write-Log -Symbol $SymErr -Text "Download lieferte keinen Inhalt." -Color Red
    exit 1
}

# --- JSON validieren ---
try {
    $null = $WorkbookJsonRaw | ConvertFrom-Json
    Write-Log -Symbol $SymOk -Text ("Workbook-Template erfolgreich geladen und validiert ({0} Zeichen)." -f $WorkbookJsonRaw.Length) -Color Green
}
catch {
    Write-Log -Symbol $SymErr -Text "Heruntergeladener Inhalt ist kein gueltiges JSON." -Color Red
    exit 1
}

# --- JSON minifizieren ---
Write-Log -Symbol $SymRun -Text "Minifiziere Workbook-JSON (Portal-Verhalten beim Speichern)..."
$SizeBefore = $WorkbookJsonRaw.Length
$WorkbookJsonRaw = Compress-JsonText -JsonText $WorkbookJsonRaw
$SizeAfter = $WorkbookJsonRaw.Length
$SavedPercent = 0
if ($SizeBefore -gt 0) {
    $SavedPercent = [math]::Round((($SizeBefore - $SizeAfter) / $SizeBefore) * 100, 1)
}
Write-Log -Symbol $SymOk -Text ("Minifiziert: {0} -> {1} Zeichen ({2} % gespart)." -f $SizeBefore, $SizeAfter, $SavedPercent) -Color Green

# --- Minifiziertes JSON erneut validieren (Sicherheitsnetz) ---
try {
    $null = $WorkbookJsonRaw | ConvertFrom-Json
    Write-Log -Symbol $SymOk -Text "Minifiziertes JSON erfolgreich validiert." -Color Green
}
catch {
    Write-Log -Symbol $SymErr -Text "Minifiziertes JSON ist ungueltig. Abbruch (bitte Issue melden)." -Color Red
    exit 1
}

# =========================================================================
# [ WORKBOOK PRUEFEN ]
# =========================================================================
Write-Section -Title "WORKBOOK PRUEFEN"

# Deterministische GUID aus Anzeigename + Ressourcengruppe: der Name der
# Workbook-Ressource ist damit stabil, ein direkter GET ersetzt die Suche.
$WorkbookName = Get-DeterministicGuid -Text ("{0}|{1}" -f $WorkbookDisplayName, $ResourceGroup)
$ResourceUrl  = "https://management.azure.com/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Insights/workbooks/$WorkbookName"

# api-version direkt in die URL (wie im Vergleichsscript): '?' ist fuer cmd.exe
# unkritisch - nur '&' ist ein Befehlstrenner. Da die direkte Ressourcen-URL
# nur EINEN Query-Parameter braucht, ist die Inline-Form die kompatibelste
# Variante ueber alle az-CLI-Versionen (--url-parameters wurde auf manchen
# Installationen ignoriert -> MissingApiVersionParameter).
$ResourceUrlApi = $ResourceUrl + "?api-version=" + $ApiVersion

Write-Log -Symbol $SymInfo -Text ("Anzeigename          : {0}" -f $WorkbookDisplayName)
Write-Log -Symbol $SymInfo -Text ("Ressourcenname (GUID): {0}" -f $WorkbookName) -Indent 4

Write-Log -Symbol $SymRun -Text "Pruefe, ob das Workbook bereits existiert..."
$GetArgs = @(
    "rest",
    "--method", "get",
    "--url", $ResourceUrlApi,
    "--output", "json"
)
# Bewusst KEIN Invoke-AzChecked: 404 (nicht vorhanden) ist hier ein gueltiges
# Ergebnis. Andere Fehler (Auth, Bad Request, ...) fuehren aber zum Abbruch,
# damit sie nicht faelschlich als 'nicht vorhanden' gewertet werden.
$GetOutput = & az @GetArgs 2>&1
$GetExitCode = $LASTEXITCODE

$TargetLocation  = $WorkbookLocation
$IsUpdate        = $false
$DeployedVersion = "unbekannt"
$ExistingRaw     = $null

if ($GetExitCode -eq 0) {
    $ExistingRaw = @($GetOutput | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] })
}
else {
    $GetErrorText = ($GetOutput | Out-String)
    if ($GetErrorText -notmatch "ResourceNotFound|WorkbookNotFound|Not Found|\(404\)") {
        Write-Log -Symbol $SymErr -Text "Existenz-Pruefung des Workbooks fehlgeschlagen (kein 404):" -Color Red
        foreach ($Line in $GetOutput) {
            $LineText = ("" + $Line).Trim()
            if ($LineText.Length -gt 0) {
                Write-Log -Symbol $SymErr -Text $LineText -Color Red -Indent 4
            }
        }
        Write-Host ("=" * 60) -ForegroundColor White
        exit 1
    }
}

if ($GetExitCode -eq 0 -and $ExistingRaw) {
    $ExistingWorkbook = ($ExistingRaw | Out-String | ConvertFrom-Json)
    $TargetLocation   = $ExistingWorkbook.location
    $IsUpdate         = $true
    if ($ExistingWorkbook.tags -and $ExistingWorkbook.tags.WorkbookVersion) {
        $DeployedVersion = $ExistingWorkbook.tags.WorkbookVersion
    }
    Write-Log -Symbol $SymOk -Text "Bestehendes Workbook gefunden." -Color Green
    Write-Log -Symbol $SymInfo -Text ("Deployte Version: {0}" -f $DeployedVersion) -Indent 4
    Write-Log -Symbol $SymInfo -Text ("Neue Version    : {0}" -f $ReleaseTag) -Indent 4
    Write-Log -Symbol $SymInfo -Text ("Region          : {0}" -f $TargetLocation) -Indent 4

    if ($DeployedVersion -eq $ReleaseTag -and $ReleaseTag -ne "unbekannt" -and -not $ForceUpdate) {
        Write-Log -Symbol $SymOk -Text ("Workbook ist bereits auf Version {0} - kein Update noetig." -f $ReleaseTag) -Color Green
        Write-Log -Symbol $SymInfo -Text "Erneutes Deployment erzwingen: ForceUpdate = true im Konfigurationsblock." -Indent 4
        Write-Host ("=" * 60) -ForegroundColor White
        Remove-Item -Path $TempDownloadFile -Force -ErrorAction SilentlyContinue
        exit 0
    }
    if ($DeployedVersion -eq $ReleaseTag -and $ForceUpdate) {
        Write-Log -Symbol $SymWarn -Text "Gleiche Version - Inhalt wird wegen ForceUpdate trotzdem ueberschrieben." -Color Yellow
    }
}
else {
    Write-Log -Symbol $SymInfo -Text "Kein bestehendes Workbook gefunden. Erstelle Workbook neu (erwartet beim ersten Lauf)."
    Write-Log -Symbol $SymInfo -Text ("Region: {0}" -f $TargetLocation) -Indent 4
}

# =========================================================================
# [ WORKBOOK AKTUALISIEREN / ERSTELLEN ]
# =========================================================================
Write-Section -Title "WORKBOOK AKTUALISIEREN / ERSTELLEN"

# --- Request-Body aufbauen (manuell, mit minimalem JSON-Escaping) ---
# Abweichung zum Vergleichsscript (New-ArcDiskSpaceWorkbook.ps1): dort reicht
# ConvertTo-Json, weil das Workbook nur wenige KB gross ist. Das LENS-Template
# (~1 MB, viele Emojis) wuerde durch die \uXXXX-Kodierung von ConvertTo-Json
# die Limits sprengen - daher manueller Body mit minimalem Escaping.
$Description = ("Azure Local LENS Workbook - aktualisiert am {0} (Release: {1})" -f (Get-Date -Format "yyyy-MM-dd HH:mm"), $ReleaseTag)
$DeployedAt  = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
$DeployedBy  = $AccountJson.user.name

$BodyJson = '{"location":"' + (ConvertTo-JsonStringLiteral -Text $TargetLocation) + '",' +
            '"kind":"shared",' +
            '"tags":{' +
            '"WorkbookVersion":"' + (ConvertTo-JsonStringLiteral -Text $ReleaseTag) + '",' +
            '"DeployedAt":"' + (ConvertTo-JsonStringLiteral -Text $DeployedAt) + '",' +
            '"DeployedBy":"' + (ConvertTo-JsonStringLiteral -Text $DeployedBy) + '",' +
            '"Source":"' + (ConvertTo-JsonStringLiteral -Text $ScriptName) + '"' +
            '},' +
            '"properties":{' +
            '"displayName":"' + (ConvertTo-JsonStringLiteral -Text $WorkbookDisplayName) + '",' +
            '"serializedData":"' + (ConvertTo-JsonStringLiteral -Text $WorkbookJsonRaw) + '",' +
            '"category":"workbook",' +
            '"sourceId":"azure monitor",' +
            '"version":"Notebook/1.0",' +
            '"description":"' + (ConvertTo-JsonStringLiteral -Text $Description) + '"' +
            '}}'

$BodySizeBytes = [System.Text.Encoding]::UTF8.GetByteCount($BodyJson)
$BodySizeMb = [math]::Round($BodySizeBytes / 1MB, 2)
Write-Log -Symbol $SymInfo -Text ("Request-Body-Groesse: {0} MB (ARM-Limit: 4 MB)" -f $BodySizeMb)
if ($BodySizeBytes -gt 4MB) {
    Write-Log -Symbol $SymErr -Text "Request-Body ueberschreitet das ARM-Limit von 4 MB. Abbruch." -Color Red
    exit 1
}
if ($BodySizeBytes -gt 3.5MB) {
    Write-Log -Symbol $SymWarn -Text "Request-Body nahe am ARM-Limit von 4 MB." -Color Yellow
}

# Body in temporaere Datei schreiben (UTF-8 ohne BOM, damit az rest sauber parst)
$TempBodyFile = Join-Path -Path $env:TEMP -ChildPath ("lens-workbook-body-{0}.json" -f ([guid]::NewGuid().ToString()))
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($TempBodyFile, $BodyJson, $Utf8NoBom)

$PutUrl = $ResourceUrlApi

if ($IsUpdate) {
    Write-Log -Symbol $SymRun -Text ("Aktualisiere Workbook '{0}' auf Version {1}..." -f $WorkbookDisplayName, $ReleaseTag)
}
else {
    Write-Log -Symbol $SymRun -Text ("Erstelle Workbook '{0}' (Version {1})..." -f $WorkbookDisplayName, $ReleaseTag)
}

$PutArgs = @(
    "rest",
    "--method", "put",
    "--url", $PutUrl,
    "--headers", "Content-Type=application/json",
    "--body", ("@" + $TempBodyFile),
    "--output", "none"
)
$null = Invoke-AzChecked -AzArgs $PutArgs -ErrorMessage "PUT-Request auf Microsoft.Insights/workbooks fehlgeschlagen."

# --- Temporaere Dateien aufraeumen ---
Remove-Item -Path $TempBodyFile -Force -ErrorAction SilentlyContinue
Remove-Item -Path $TempDownloadFile -Force -ErrorAction SilentlyContinue

if ($IsUpdate) {
    Write-Log -Symbol $SymOk -Text "Workbook wurde erfolgreich aktualisiert." -Color Green
}
else {
    Write-Log -Symbol $SymOk -Text "Workbook wurde erfolgreich erstellt." -Color Green
}

# =========================================================================
# [ ZUSAMMENFASSUNG ]
# =========================================================================
Write-Section -Title "ZUSAMMENFASSUNG"
$ResourceIdPath = "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Insights/workbooks/$WorkbookName"
Write-Log -Symbol $SymInfo -Text ("Workbook       : {0}" -f $WorkbookDisplayName)
Write-Log -Symbol $SymInfo -Text ("Ressourcenname : {0}" -f $WorkbookName) -Indent 4
Write-Log -Symbol $SymInfo -Text ("Ressourcengruppe: {0}" -f $ResourceGroup) -Indent 4
Write-Log -Symbol $SymInfo -Text ("Region         : {0}" -f $TargetLocation) -Indent 4
Write-Log -Symbol $SymInfo -Text ("LENS Release   : {0}" -f $ReleaseTag) -Indent 4
Write-Log -Symbol $SymInfo -Text "Deployte Version abfragen (ohne Portal):"
Write-Log -Symbol $SymInfo -Text ("az resource show --ids {0} --query tags" -f $ResourceIdPath) -Indent 4
Write-Log -Symbol $SymInfo -Text "Direktlink:"
Write-Log -Symbol $SymInfo -Text ("https://portal.azure.com/#@/resource{0}" -f $ResourceIdPath) -Indent 4
Write-Log -Symbol $SymOk -Text "Vorgang abgeschlossen. Workbook im Azure Portal unter Monitor -> Workbooks pruefen." -Color Green
Write-Host ("=" * 60) -ForegroundColor White
