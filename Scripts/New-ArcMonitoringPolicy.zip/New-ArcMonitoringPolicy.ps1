#Requires -Version 5.1
<#
.SYNOPSIS
    SCHRITT 3 von 6 - Legt eine tag-basierte Azure Policy an, die jede
    Arc-Maschine mit dem Tag Monitoring=VirtualServer automatisch mit der
    gemeinsamen VM-Insights-DCR verknuepft. Inklusive Rollenzuweisung und
    Remediation Task.
.DESCRIPTION
    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung

    AENDERUNG IN 1.2.0 - BENENNUNG NACH BETRIEBSSYSTEM
    -------------------------------------------------------------------------
    Definition und Zuweisung heissen jetzt 'arc-winserver-vminsights-dcr'
    bzw. 'arc-winsrv-vminsights-dcr'. Grund: kommt spaeter eine
    Linux-Variante dazu, muessen beide unterscheidbar nebeneinander stehen
    koennen. Sie wuerden dieselbe DCR verwenden, aber unterschiedliche
    OperatingSystem-Tags filtern.

    Policy-Objekte sind ueber ihren Namen identifiziert - ein geaenderter
    Name legt ein ZWEITES Objekt an, er benennt nichts um. Stufe 0 prueft
    deshalb auf Reste unter frueheren Namen und gibt die Loeschbefehle aus,
    entfernt aber nichts von selbst.

    AENDERUNG IN 1.1.0 - MEHRERE TAGS ALS KRITERIUM
    -------------------------------------------------------------------------
    Die Auswahl erfolgt nicht mehr ueber ein einzelnes Tag, sondern ueber
    die Hashtable $PolicyTagFilter. Alle Eintraege werden UND-verknuepft.
    Aktuell:
        Monitoring      = VirtualServer
        OperatingSystem = Windows Server

    Jeder zusaetzliche Tag VERENGT die Auswahl - eine Maschine ohne diesen
    Tag faellt aus der Policy heraus und bekommt keine DCR-Zuordnung.
    Stufe 1 zeigt deshalb vor der Anlage nicht nur die Treffer, sondern
    auch die Maschinen, die die Bedingungen nur TEILWEISE erfuellen.

    WARUM EINE EIGENE POLICY-DEFINITION
    -------------------------------------------------------------------------
    Die Built-in-Initiativen fuer Arc
      Windows: 9575b8b7-78ab-4281-b53b-d3c1ace2260b
      Linux  : 118f04da-0375-44d1-84e3-0fd9e1849403
    greifen auf ALLE Microsoft.HybridCompute/machines im Zuweisungs-Scope.
    Ein Tag-Filter ist dort nicht vorgesehen, und notScopes akzeptiert nur
    Subscriptions, Resource Groups oder einzelne Ressourcen-IDs - kein
    Namensmuster und keine Tag-Bedingung.

    Ohne Filter bekaemen AVD-Session-Hosts und physische Server ebenfalls die
    VirtualServer-DCR und damit doppelte Ingestion-Kosten. Deshalb legt dieses
    Script eine eigene deployIfNotExists-Definition an, deren if-Block auf
    tags['Monitoring'] == 'VirtualServer' prueft.

    Das Tag stammt aus Set-ArcVirtualServerTag.ps1 - dort wird es aus den
    Associations der Change-Tracking-DCR abgeleitet, nicht aus Namensmustern
    geraten.

    WAS DAS SCRIPT TUT
    -------------------------------------------------------------------------
      1. Pre-Check (CLI, Login, Extensions)
      2. Tag-Bestand pruefen - wie viele Maschinen tragen das Tag?
      3. Ziel-DCR aufloesen
      4. Rollen-IDs zur Laufzeit aufloesen (keine hartkodierten GUIDs)
      5. Policy-Definition anlegen oder aktualisieren
      6. Policy-Zuweisung mit System-assigned Identity
         (Arc unterstuetzt KEINE User-assigned Identity fuer Policy)
      7. Rollenzuweisungen fuer die Identity
      8. Remediation Task fuer den Bestand starten

    HINWEIS ZUR AMA-EXTENSION
    -------------------------------------------------------------------------
    Diese Policy setzt NUR die DCR-Association. Sie installiert den Azure
    Monitor Agent nicht. Das ist bewusst so: der Agent laeuft bereits auf
    nahezu allen Maschinen. Fuer die verbleibenden Faelle bleibt die
    Built-in-Initiative der bessere Weg - sie behandelt Windows und Linux
    getrennt und kennt die jeweils richtige Extension.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 18.08.2026
    Version     : 1.2.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\New-ArcMonitoringPolicy.ps1
.EXAMPLE
    # Nur ansehen, nichts anlegen
    $WhatIfMode = $true; .\New-ArcMonitoringPolicy.ps1
#>

# Python-Warnungen aus CLI-Extensions unterdruecken (sonst stderr-Rauschen,
# das PowerShell als NativeCommandError wertet)
$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

$SubscriptionId      = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local

# --- Tags als Auswahlkriterium ---
# ALLE Eintraege muessen zutreffen (UND-Verknuepfung im if-Block der Policy).
# Ein weiteres Kriterium ist eine zusaetzliche Zeile - der Rest des Scripts
# baut die Bedingungen daraus auf.
#
# ACHTUNG: Jeder zusaetzliche Tag VERENGT die Auswahl. Eine Maschine ohne
# den Tag faellt heraus und bekommt keine DCR-Zuordnung. Stufe 1 zeigt
# deshalb vor der Anlage, wie viele Maschinen alle Bedingungen erfuellen
# und wie viele knapp daran scheitern.
$PolicyTagFilter = [ordered]@{
    "Monitoring"      = "VirtualServer"
    "OperatingSystem" = "Windows Server"
}

# --- Ziel-DCR (muss aus Script 1 existieren) ---
$DcrName             = "law-LDK-VirtualServer-vminsights-dcr"
$DcrResourceGroup    = "rg-arcmgmt"

# --- Policy ---
# Namen enthalten das Betriebssystem, damit eine spaetere Linux-Variante
# unterscheidbar danebenstehen kann. Beide Policies wuerden dann dieselbe
# DCR verwenden, aber unterschiedliche OperatingSystem-Tags filtern.
#
# ACHTUNG: Policy-Definitionen und -Zuweisungen sind ueber ihren NAMEN
# identifiziert. Ein geaenderter Name legt eine ZWEITE Definition bzw.
# Zuweisung an - er benennt nichts um. Wurde bereits unter altem Namen
# deployt, muss die alte Zuweisung samt Rollenzuweisung und Definition
# entfernt werden (siehe Hinweis am Ende des Scripts).
$PolicyDefName       = "arc-winserver-vminsights-dcr"
$PolicyDefDisplay    = "Arc Windows Server mit VM-Insights-DCR verknuepfen"
$PolicyAssignName    = "arc-winsrv-vminsights-dcr"
$PolicyAssignDisplay = "Arc Windows Server - VM Insights DCR"

# Namen einer frueheren Fassung. Das Script prueft, ob darunter noch etwas
# existiert, und weist darauf hin - es loescht nichts von selbst.
$AltePolicyDefNames    = @("arc-virtualserver-vminsights-dcr")
$AltePolicyAssignNames = @("arc-vs-vminsights-dcr")
$AssociationName     = "dcra-vminsights-virtualserver"   # identisch zu Script 1
$AssignmentLocation  = "westeurope"                      # Region der Managed Identity
$PolicyEffect        = "deployIfNotExists"               # oder 'auditIfNotExists'
$EnforcementMode     = "Default"                         # 'DoNotEnforce' = Testlauf

# --- Rollen fuer die Policy-Identity ---
#     Werden zur Laufzeit in GUIDs aufgeloest - keine hartkodierten IDs.
$RequiredRoles       = @(
    "Monitoring Contributor",
    "Log Analytics Contributor",
    "Azure Connected Machine Resource Administrator"
)

# --- Remediation ---
$StartRemediation    = $true
$RemediationName     = "remediate-arc-vs-vminsights-$(Get-Date -f 'yyyyMMdd-HHmm')"

# --- Sonstiges ---
$IdentityWaitSeconds = 45      # Wartezeit fuer die Verteilung der Identity
$WhatIfMode          = $false

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    <#
      Ruft Azure CLI auf und liefert sauberes JSON zurueck. Trennt stdout und
      stderr, damit Python-Warnungen der CLI-Extensions das JSON nicht
      zerstoeren. Rueckgabe: PSObject bei Erfolg, $null bei Fehler.
      Fehlertext steht danach in $script:LastAzError.
    #>
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort erhalten: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Ensure-Extension {
    param([Parameter(Mandatory)][string]$Name)
    $exts = Invoke-AzJson @("extension","list")
    if ($exts | Where-Object { $_.name -eq $Name }) { return $true }
    Write-Warn2 "Extension '$Name' fehlt - wird installiert."
    az extension add --name $Name --only-show-errors 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Installation von '$Name' fehlgeschlagen."; return $false }
    return $true
}

function Write-JsonFile {
    <#
      Schreibt ein Objekt als JSON in eine Temp-Datei und gibt den Pfad zurueck.
      Notwendig, weil az.cmd Inline-JSON unter Windows falsch zerlegt.
    #>
    param([Parameter(Mandatory)]$Obj, [int]$Depth = 30)
    $f = Join-Path $env:TEMP "azpol-$([guid]::NewGuid()).json"
    $Obj | ConvertTo-Json -Depth $Depth | Set-Content -Path $f -Encoding UTF8
    return $f
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Fail "Version < 2.54.0 - '--mi-system-assigned' bei az policy assignment fehlt."
        Write-Sub "Bitte 'az upgrade' ausfuehren."
        exit 1
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
    Write-Ok "Subscription gesetzt."
}

Write-Run "Pruefe Extension 'resource-graph'..."
if (-not (Ensure-Extension -Name "resource-graph")) { exit 1 }
Write-Ok "Extension verfuegbar."
Write-Line

# =============================================================================
#  STUFE 0 - ALTBESTAND
# =============================================================================
Write-Head "STUFE 0 - ALTBESTAND"

# Policy-Definitionen und -Zuweisungen sind ueber ihren NAMEN identifiziert.
# Wurde frueher unter einem anderen Namen deployt, laeuft die alte Zuweisung
# weiter und remediiert gegen dieselbe DCR - zwei Policies, dasselbe Ziel.
# Das Script meldet das, entfernt aber nichts von selbst.
$altGefunden = @()

foreach ($n in $AltePolicyAssignNames) {
    if ($n -eq $PolicyAssignName) { continue }
    $a = Invoke-AzJson @("policy","assignment","show","--name",$n,
                         "--scope","/subscriptions/$SubscriptionId","-o","json")
    if ($a) { $altGefunden += [PSCustomObject]@{ Art = "Zuweisung"; Name = $n; Id = $a.id } }
}
foreach ($n in $AltePolicyDefNames) {
    if ($n -eq $PolicyDefName) { continue }
    $d = Invoke-AzJson @("policy","definition","show","--name",$n,
                         "--subscription",$SubscriptionId,"-o","json")
    if ($d) { $altGefunden += [PSCustomObject]@{ Art = "Definition"; Name = $n; Id = $d.id } }
}

if ($altGefunden.Count -eq 0) {
    Write-Ok "Keine Reste unter frueheren Namen gefunden."
}
else {
    Write-Warn2 "$($altGefunden.Count) Objekt(e) unter frueheren Namen vorhanden:"
    foreach ($a in $altGefunden) { Write-Sub "$($a.Art): $($a.Name)" }
    Write-Host ""
    Write-Sub "Diese laufen parallel weiter und remediieren gegen dieselbe DCR."
    Write-Sub "Nach erfolgreichem Lauf dieses Scripts entfernen - Reihenfolge beachten,"
    Write-Sub "die Rollenzuweisung haengt an der Identity der ALTEN Zuweisung:"
    Write-Host ""
    foreach ($a in ($altGefunden | Where-Object Art -eq "Zuweisung")) {
        Write-Sub "  az policy assignment delete --name $($a.Name) --scope /subscriptions/$SubscriptionId"
    }
    foreach ($a in ($altGefunden | Where-Object Art -eq "Definition")) {
        Write-Sub "  az policy definition delete --name $($a.Name) --subscription $SubscriptionId"
    }
    Write-Sub "  (verwaiste Rollenzuweisungen danach unter IAM pruefen)"
}
Write-Line

# =============================================================================
#  STUFE 1 - TAG-BESTAND
# =============================================================================
Write-Head "STUFE 1 - TAG-BESTAND"

$kriterien = ($PolicyTagFilter.Keys | ForEach-Object { "$_=$($PolicyTagFilter[$_])" }) -join " UND "
Write-Run "Zaehle Maschinen mit $kriterien..."

# Je Tag eine extend-Spalte, benannt wie der Tag. Nur einfache
# Anfuehrungszeichen - doppelte ueberleben az.cmd unter Windows nicht.
$extends = ($PolicyTagFilter.Keys | ForEach-Object { "$_ = tostring(tags['$_'])" }) -join ", "
$byCols  = ($PolicyTagFilter.Keys) -join ", "

$argQuery = "resources " `
  + "| where type =~ 'microsoft.hybridcompute/machines' " `
  + "| extend $extends " `
  + "| summarize Anzahl = count() by $byCols " `
  + "| order by Anzahl desc"

$argRes = Invoke-AzJson @("graph","query","-q",$argQuery,"--first","200","-o","json")
if (-not $argRes -or -not $argRes.data) {
    Write-Fail "Tag-Abfrage fehlgeschlagen: $script:LastAzError"
    exit 1
}

$getagged = 0
$fastTreffer = 0

Write-Host ""
Write-Host ("    {0,-38} {1,6}   {2}" -f "Tag-Kombination", "Anzahl", "Bewertung") -ForegroundColor White
Write-Host ("    " + ("-" * 68)) -ForegroundColor White

foreach ($r in @($argRes.data)) {

    # Wie viele der geforderten Tags stimmen bei dieser Kombination?
    $treffer = 0
    $teile   = @()
    foreach ($k in $PolicyTagFilter.Keys) {
        $ist = [string]$r.$k
        if ($ist -eq $PolicyTagFilter[$k]) { $treffer++ }
        $teile += if ([string]::IsNullOrWhiteSpace($ist)) { "$k=(leer)" } else { "$k=$ist" }
    }

    $alle = ($treffer -eq $PolicyTagFilter.Count)
    if ($alle) {
        $getagged += $r.Anzahl
        $bewertung = "erfasst"
        $farbe = "Green"
    }
    elseif ($treffer -gt 0) {
        $fastTreffer += $r.Anzahl
        $bewertung = "$treffer von $($PolicyTagFilter.Count) - faellt heraus"
        $farbe = "Yellow"
    }
    else {
        $bewertung = "ausserhalb"
        $farbe = "DarkGray"
    }

    Write-Host ("    {0,-38} {1,6}   {2}" -f (($teile -join ", ")), $r.Anzahl, $bewertung) -ForegroundColor $farbe
}

Write-Host ""
if ($getagged -eq 0) {
    Write-Fail "Keine Maschine erfuellt alle Bedingungen."
    Write-Sub "Die Policy waere wirkungslos. Bitte die Tags pruefen und setzen."
    exit 1
}

Write-Ok "$getagged Maschine(n) werden von der Policy erfasst."

if ($fastTreffer -gt 0) {
    Write-Warn2 "$fastTreffer Maschine(n) erfuellen die Bedingungen nur TEILWEISE."
    Write-Sub "Sie fallen aus der Policy heraus und bekommen keine DCR-Zuordnung."
    Write-Sub "Falls das nicht gewollt ist: fehlende Tags nachsetzen oder das"
    Write-Sub "betreffende Kriterium aus `$PolicyTagFilter entfernen."
}
Write-Line

# =============================================================================
#  STUFE 2 - ZIEL-DCR
# =============================================================================
Write-Head "STUFE 2 - ZIEL-DCR"

$DcrResourceId = "/subscriptions/$SubscriptionId/resourceGroups/$DcrResourceGroup" `
               + "/providers/Microsoft.Insights/dataCollectionRules/$DcrName"

Write-Run "Pruefe DCR '$DcrName'..."
$dcr = Invoke-AzJson @("rest","--method","get",
        "--url","https://management.azure.com$($DcrResourceId)?api-version=2023-03-11")
if (-not $dcr) {
    Write-Fail "DCR nicht gefunden: $script:LastAzError"
    Write-Sub "Bitte zuerst .\New-ArcVmInsightsDcr.ps1 ausfuehren."
    exit 1
}
Write-Ok "DCR gefunden: $($dcr.name) ($($dcr.location))"
Write-Line

# =============================================================================
#  STUFE 3 - ROLLEN AUFLOESEN
# =============================================================================
Write-Head "STUFE 3 - ROLLEN"

$roleIds = @()
foreach ($rn in $RequiredRoles) {
    Write-Run "Loese Rolle '$rn' auf..."
    $rd = Invoke-AzJson @("role","definition","list","--name",$rn,"--query","[0].name","-o","json")
    if (-not $rd) {
        Write-Fail "Rolle '$rn' nicht gefunden: $script:LastAzError"
        exit 1
    }
    $roleIds += "/providers/Microsoft.Authorization/roleDefinitions/$rd"
    Write-Ok "$rn -> $rd"
}
Write-Line

# =============================================================================
#  STUFE 4 - POLICY-DEFINITION
# =============================================================================
Write-Head "STUFE 4 - POLICY-DEFINITION"

# if-Bedingungen: Ressourcentyp plus je Tag eine Gleichheitspruefung.
# allOf = UND-Verknuepfung, alle muessen zutreffen.
$ifBedingungen = @( @{ field = "type"; equals = "Microsoft.HybridCompute/machines" } )
foreach ($k in $PolicyTagFilter.Keys) {
    $ifBedingungen += @{ field = "tags['$k']"; equals = $PolicyTagFilter[$k] }
}

$policyRule = @{
    if = @{
        allOf = $ifBedingungen
    }
    then = @{
        effect  = "[parameters('effect')]"
        details = @{
            type              = "Microsoft.Insights/dataCollectionRuleAssociations"
            name              = "[parameters('associationName')]"
            roleDefinitionIds = $roleIds
            existenceCondition = @{
                field  = "Microsoft.Insights/dataCollectionRuleAssociations/dataCollectionRuleId"
                equals = "[parameters('dcrResourceId')]"
            }
            deployment = @{
                properties = @{
                    mode = "incremental"
                    parameters = @{
                        machineName     = @{ value = "[field('name')]" }
                        dcrResourceId   = @{ value = "[parameters('dcrResourceId')]" }
                        associationName = @{ value = "[parameters('associationName')]" }
                    }
                    template = @{
                        '$schema'      = "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#"
                        contentVersion = "1.0.0.0"
                        parameters     = @{
                            machineName     = @{ type = "string" }
                            dcrResourceId   = @{ type = "string" }
                            associationName = @{ type = "string" }
                        }
                        resources = @(
                            @{
                                type       = "Microsoft.HybridCompute/machines/providers/dataCollectionRuleAssociations"
                                name       = "[concat(parameters('machineName'), '/Microsoft.Insights/', parameters('associationName'))]"
                                apiVersion = "2022-06-01"
                                properties = @{
                                    dataCollectionRuleId = "[parameters('dcrResourceId')]"
                                    description          = "Verknuepft durch Azure Policy."
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

$policyParams = @{
    effect = @{
        type          = "String"
        allowedValues = @("deployIfNotExists","auditIfNotExists","disabled")
        defaultValue  = "deployIfNotExists"
        metadata      = @{ displayName = "Effect"; description = "Wirkung der Policy." }
    }
    dcrResourceId = @{
        type     = "String"
        metadata = @{
            displayName  = "DCR Resource ID"
            description  = "Ressourcen-ID der zu verknuepfenden Data Collection Rule."
            strongType   = "Microsoft.Insights/dataCollectionRules"
            assignPermissions = $true
        }
    }
    associationName = @{
        type         = "String"
        defaultValue = "dcra-vminsights-virtualserver"
        metadata     = @{ displayName = "Association Name"; description = "Name der DCR-Association." }
    }
}

Write-Sub "Definition : $PolicyDefName"
Write-Sub "Bedingung  : type = Microsoft.HybridCompute/machines"
foreach ($k in $PolicyTagFilter.Keys) {
    Write-Sub "             UND tags['$k'] = '$($PolicyTagFilter[$k])'"
}
Write-Sub "Effekt     : $PolicyEffect"
Write-Sub "Rollen     : $($RequiredRoles -join ', ')"

if ($WhatIfMode) {
    Write-Line
    Write-Info2 "WhatIf-Modus - Policy-Regel:"
    Write-Host (@{ policyRule = $policyRule; parameters = $policyParams } | ConvertTo-Json -Depth 30)
    Write-Line
    exit 0
}

$ruleFile  = Write-JsonFile -Obj $policyRule
$paramFile = Write-JsonFile -Obj $policyParams

Write-Run "Lege Policy-Definition an bzw. aktualisiere sie..."
$def = Invoke-AzJson @(
    "policy","definition","create",
    "--name",$PolicyDefName,
    "--display-name",$PolicyDefDisplay,
    "--description","Verknuepft Arc-Maschinen mit $kriterien mit der gemeinsamen VM-Insights-DCR.",
    "--mode","Indexed",
    "--rules","@$ruleFile",
    "--params","@$paramFile",
    "--subscription",$SubscriptionId,"-o","json"
)
Remove-Item $ruleFile, $paramFile -ErrorAction SilentlyContinue

if (-not $def) {
    Write-Fail "Policy-Definition fehlgeschlagen."
    Write-Sub "Ursache: $script:LastAzError"
    exit 1
}
Write-Ok "Policy-Definition bereit: $($def.name)"
Write-Line

# =============================================================================
#  STUFE 5 - ZUWEISUNG
# =============================================================================
Write-Head "STUFE 5 - ZUWEISUNG"

$scope = "/subscriptions/$SubscriptionId"

$assignParams = @{
    effect          = @{ value = $PolicyEffect }
    dcrResourceId   = @{ value = $DcrResourceId }
    associationName = @{ value = $AssociationName }
}
$assignParamFile = Write-JsonFile -Obj $assignParams

Write-Run "Erstelle Policy-Zuweisung..."
Write-Sub "Scope    : $scope"
Write-Sub "Identity : System-assigned (Arc unterstuetzt keine User-assigned)"
Write-Sub "Region   : $AssignmentLocation"
Write-Sub "Enforce  : $EnforcementMode"

$assign = Invoke-AzJson @(
    "policy","assignment","create",
    "--name",$PolicyAssignName,
    "--display-name",$PolicyAssignDisplay,
    "--policy",$def.id,
    "--scope",$scope,
    "--params","@$assignParamFile",
    "--mi-system-assigned",
    "--location",$AssignmentLocation,
    "--enforcement-mode",$EnforcementMode,"-o","json"
)
Remove-Item $assignParamFile -ErrorAction SilentlyContinue

if (-not $assign) {
    Write-Fail "Zuweisung fehlgeschlagen."
    Write-Sub "Ursache: $script:LastAzError"
    exit 1
}

$principalId = $assign.identity.principalId
Write-Ok "Zuweisung erstellt: $($assign.name)"
Write-Sub "PrincipalId: $principalId"
Write-Line

# =============================================================================
#  STUFE 6 - ROLLENZUWEISUNGEN
# =============================================================================
Write-Head "STUFE 6 - ROLLENZUWEISUNGEN"

Write-Run "Warte $IdentityWaitSeconds s auf die Verteilung der Identity..."
Write-Sub "Ohne Wartezeit schlaegt die Rollenzuweisung mit 'PrincipalNotFound' fehl."
Start-Sleep -Seconds $IdentityWaitSeconds

foreach ($rn in $RequiredRoles) {
    Write-Run "Weise '$rn' zu..."
    $ra = Invoke-AzJson @(
        "role","assignment","create",
        "--assignee-object-id",$principalId,
        "--assignee-principal-type","ServicePrincipal",
        "--role",$rn,
        "--scope",$scope,"-o","json"
    )
    if ($ra) { Write-Ok "$rn zugewiesen." }
    elseif ($script:LastAzError -match "already exists|RoleAssignmentExists") {
        Write-Info2 "$rn bereits vorhanden."
    }
    else {
        Write-Warn2 "$rn fehlgeschlagen: $script:LastAzError"
        Write-Sub "Ohne diese Rolle kann die Remediation die Association nicht anlegen."
    }
}
Write-Line

# =============================================================================
#  STUFE 7 - REMEDIATION
# =============================================================================
Write-Head "STUFE 7 - REMEDIATION"

if (-not $StartRemediation) {
    Write-Info2 "Uebersprungen (`$StartRemediation = `$false)."
    Write-Sub "Ohne Remediation wirkt die Policy nur auf NEUE bzw. geaenderte Maschinen."
}
elseif ($PolicyEffect -ne "deployIfNotExists") {
    Write-Warn2 "Effekt ist '$PolicyEffect' - Remediation nur bei deployIfNotExists moeglich."
}
else {
    Write-Run "Warte auf die erste Compliance-Auswertung..."
    Write-Sub "Die Policy-Engine braucht dafuer typischerweise einige Minuten."
    Start-Sleep -Seconds 30

    Write-Run "Starte Remediation Task..."
    $rem = Invoke-AzJson @(
        "policy","remediation","create",
        "--name",$RemediationName,
        "--policy-assignment",$assign.id,
        "--resource-discovery-mode","ReEvaluateCompliance","-o","json"
    )
    if ($rem) {
        Write-Ok "Remediation gestartet: $($rem.name)"
        Write-Sub "Status: $($rem.provisioningState)"
    }
    else {
        Write-Warn2 "Remediation nicht gestartet: $script:LastAzError"
        Write-Sub "Haeufigste Ursache: die Compliance-Auswertung ist noch nicht gelaufen."
        Write-Sub "In 15 bis 30 Minuten erneut versuchen mit:"
        Write-Sub "  az policy remediation create --name $RemediationName ``"
        Write-Sub "      --policy-assignment $($assign.id) ``"
        Write-Sub "      --resource-discovery-mode ReEvaluateCompliance"
    }
}
Write-Line

# =============================================================================
#  ZUSAMMENFASSUNG
# =============================================================================
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "Definition   : $PolicyDefName"
Write-Sub "Zuweisung    : $PolicyAssignName"
Write-Sub "Scope        : $scope"
Write-Sub "Auswahl      : $kriterien ($getagged Maschinen)"
Write-Sub "Ziel-DCR     : $DcrName"
Write-Sub "Association  : $AssociationName"
Write-Sub "Effekt       : $PolicyEffect"
Write-Host ""
Write-Info2 "Compliance pruefen:"
Write-Sub "az policy state summarize --policy-assignment $PolicyAssignName"
Write-Info2 "Remediation-Status:"
Write-Sub "az policy remediation show --name $RemediationName --policy-assignment $PolicyAssignName"
Write-Host ""
Write-Warn2 "Wichtig fuer neue Server:"
Write-Sub "Die Policy greift nur bei gesetztem Tag. Neue Virtual Server brauchen"
Write-Sub "$kriterien - entweder ueber Set-ArcVirtualServerTag.ps1 oder"
Write-Sub "ueber eine zusaetzliche Tagging-Policy im Onboarding-Prozess."
Write-Line
