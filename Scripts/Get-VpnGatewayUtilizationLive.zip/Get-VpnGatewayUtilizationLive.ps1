#Requires -Version 5.1
<#
.SYNOPSIS
    Zeigt die aktuelle Auslastung eines Azure VPN Gateways der letzten Minuten.
.DESCRIPTION
    Liest ueber Azure CLI die Azure-Monitor-Metriken eines Virtual Network Gateways vom
    Typ "Vpn" aus und stellt die Werte eines kurzen, gleitenden Zeitfensters (Standard:
    5 Minuten) den Limits der konfigurierten SKU/Generation gegenueber.

    Im Unterschied zur Langzeitauswertung beruecksichtigt dieses Script die Latenz der
    Plattform-Metriken: Azure liefert Messwerte mit einigen Minuten Verzoegerung. Das
    Script fragt daher ein groesseres Fenster ab, wertet aber nur die gewuenschten
    letzten Minuten aus und weist das Alter des juengsten Datenpunkts aus.

    Die Granularitaet wird automatisch ermittelt: Es wird zunaechst PT1M versucht und
    bei fehlender Unterstuetzung auf PT5M zurueckgefallen.

    Mit $WatchMode = $true laeuft das Script als fortlaufende Live-Anzeige.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 20.08.2026
    Version     : 1.1.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Get-VpnGatewayUtilizationLive.ps1
#>

# =========================================================================
#  PARAMETER - hier anpassen
# =========================================================================
$SubscriptionId       = ""                       # leer = aktuelle Subscription
$ResourceGroupName    = "rg-AVDmgmt"             # Resource Group des Gateways
$GatewayName          = "LDK_S2S_VPN_AVD"        # Name des Virtual Network Gateways

# --- Zeitfenster ---------------------------------------------------------
$LookbackMinutes      = 5                        # auszuwertendes Fenster in Minuten
$LatencyBufferMinutes = 10                       # zusaetzlicher Puffer gegen Metrik-Latenz
$PreferredInterval    = "PT1M"                   # gewuenschte Granularitaet
$FallbackInterval     = "PT5M"                   # Rueckfall, falls nicht unterstuetzt

# --- Live-Anzeige --------------------------------------------------------
$WatchMode            = $false                   # $true = fortlaufende Aktualisierung
$WatchIntervalSeconds = 60                       # Pause zwischen den Durchlaeufen
$WatchCount           = 0                        # 0 = endlos (Abbruch mit STRG+C)
$ClearOnRefresh       = $true                    # Konsole vor jedem Durchlauf leeren

# --- Bewertung -----------------------------------------------------------
$WarnThresholdPct     = 70                       # ab hier Warnung
$IdleThresholdPct     = 20                       # darunter Hinweis auf Ueberdimensionierung
$ShowTunnelDetail     = $true                    # Aufschluesselung je Tunnel anzeigen

$MinAzCliVersion      = "2.60.0"

# =========================================================================
#  SKU-LIMITS (Stand 06/2026, Microsoft Learn "About gateway SKUs")
# =========================================================================
$SkuLimits = @{
    "Generation1" = @{
        "Basic"    = @{ Mbps = 100;   S2S = 10;  P2S = 0;     PPS = 0      }
        "VpnGw1"   = @{ Mbps = 650;   S2S = 30;  P2S = 250;   PPS = 62000  }
        "VpnGw2"   = @{ Mbps = 1000;  S2S = 30;  P2S = 500;   PPS = 100000 }
        "VpnGw3"   = @{ Mbps = 1250;  S2S = 30;  P2S = 1000;  PPS = 120000 }
        "VpnGw1AZ" = @{ Mbps = 650;   S2S = 30;  P2S = 250;   PPS = 62000  }
        "VpnGw2AZ" = @{ Mbps = 1000;  S2S = 30;  P2S = 500;   PPS = 110000 }
        "VpnGw3AZ" = @{ Mbps = 1250;  S2S = 30;  P2S = 1000;  PPS = 120000 }
    }
    "Generation2" = @{
        "VpnGw2"   = @{ Mbps = 1250;  S2S = 30;  P2S = 500;   PPS = 120000 }
        "VpnGw3"   = @{ Mbps = 2500;  S2S = 30;  P2S = 1000;  PPS = 140000 }
        "VpnGw4"   = @{ Mbps = 5000;  S2S = 100; P2S = 5000;  PPS = 220000 }
        "VpnGw5"   = @{ Mbps = 10000; S2S = 100; P2S = 10000; PPS = 220000 }
        "VpnGw2AZ" = @{ Mbps = 1250;  S2S = 30;  P2S = 500;   PPS = 120000 }
        "VpnGw3AZ" = @{ Mbps = 2500;  S2S = 30;  P2S = 1000;  PPS = 140000 }
        "VpnGw4AZ" = @{ Mbps = 5000;  S2S = 100; P2S = 5000;  PPS = 220000 }
        "VpnGw5AZ" = @{ Mbps = 10000; S2S = 100; P2S = 10000; PPS = 220000 }
    }
}

# =========================================================================
#  HILFSFUNKTIONEN
# =========================================================================
function Write-Line    { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section { param([string]$T) Write-Host "" ; Write-Line ; Write-Host "[ $T ]" -ForegroundColor White ; Write-Line }
function Write-Ok      { param([string]$M) Write-Host "OK   $M" -ForegroundColor Green }
function Write-Err     { param([string]$M) Write-Host "FEHL $M" -ForegroundColor Red }
function Write-Warn    { param([string]$M) Write-Host "WARN $M" -ForegroundColor Yellow }
function Write-Info    { param([string]$M) Write-Host "INFO $M" -ForegroundColor Cyan }
function Write-Sub     { param([string]$M,[string]$C = "Gray") Write-Host ("    " + $M) -ForegroundColor $C }
function Write-Log     { param([string]$M) Write-Host ("[" + (Get-Date -Format "HH:mm:ss") + "] $M") -ForegroundColor Cyan }

function Compare-Version {
    param([string]$Current, [string]$Required)
    try { return ([version]$Current) -ge ([version]$Required) } catch { return $true }
}

function ConvertTo-Mbps { param([double]$BytesPerSecond) return [math]::Round(($BytesPerSecond * 8) / 1000000, 2) }

function Get-MetricWindow {
    <#
        Liefert die Messwerte einer Metrik innerhalb eines Zeitfensters:
        @{
            HasData    = $true/$false
            Latest     = <double>     # juengster Datenpunkt
            LatestTime = <datetime>   # Zeitstempel dazu
            Max        = <double>     # Maximum im Fenster
            Avg        = <double>     # Mittelwert im Fenster
            Series     = @{ "<Label>" = @{ Latest; Max; Avg } }
        }
        Es werden nur Datenpunkte ab $WindowStart beruecksichtigt.
    #>
    param(
        [string]$ResourceId,
        [string]$MetricName,
        [string]$StartTime,
        [string]$EndTime,
        [string]$Interval,
        [datetime]$WindowStart,
        [string]$Aggregation = "Average",
        [string]$SplitBy = $null
    )

    $cmd = @(
        "monitor", "metrics", "list",
        "--resource", $ResourceId,
        "--metric", $MetricName,
        "--aggregation", $Aggregation,
        "--interval", $Interval,
        "--start-time", $StartTime,
        "--end-time", $EndTime,
        "--output", "json"
    )
    if ($SplitBy) { $cmd += @("--filter", "$SplitBy eq '*'") }

    $raw = & az @cmd 2>$null
    if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($raw)) { return $null }

    try { $json = $raw | ConvertFrom-Json } catch { return $null }
    if (-not $json.value -or $json.value.Count -eq 0) { return $null }

    $aggKey = $Aggregation.ToLower()
    $result = @{ HasData = $false; Latest = 0.0; LatestTime = $null; Max = 0.0; Avg = 0.0; Series = @{} }
    $allVals = New-Object System.Collections.ArrayList

    foreach ($ts in $json.value[0].timeseries) {
        $label = "gesamt"
        if ($ts.metadatavalues -and $ts.metadatavalues.Count -gt 0) {
            $label = $ts.metadatavalues[0].value
        }

        $sVals      = New-Object System.Collections.ArrayList
        $sLatest    = 0.0
        $sLatestTs  = $null

        foreach ($p in $ts.data) {
            $v = $null
            switch ($aggKey) {
                "average" { $v = $p.average }
                "maximum" { $v = $p.maximum }
                "total"   { $v = $p.total }
            }
            if ($null -eq $v) { continue }

            $pt = $null
            try { $pt = [datetime]$p.timeStamp } catch { continue }
            if ($pt -lt $WindowStart) { continue }   # ausserhalb des Auswertungsfensters

            $v = [double]$v
            [void]$sVals.Add($v)
            [void]$allVals.Add($v)
            $result.HasData = $true

            if ($null -eq $sLatestTs -or $pt -gt $sLatestTs) {
                $sLatestTs = $pt
                $sLatest   = $v
            }
        }

        if ($sVals.Count -gt 0) {
            $sMax  = ($sVals | Measure-Object -Maximum).Maximum
            $sMean = ($sVals | Measure-Object -Average).Average
            $result.Series[$label] = @{ Latest = $sLatest; Max = $sMax; Avg = $sMean; LatestTime = $sLatestTs }
            if ($sMax -gt $result.Max) { $result.Max = $sMax }
            if ($null -eq $result.LatestTime -or $sLatestTs -gt $result.LatestTime) {
                $result.LatestTime = $sLatestTs
            }
        }
    }

    if ($allVals.Count -gt 0) { $result.Avg = ($allVals | Measure-Object -Average).Average }

    # "Latest" gesamt = Summe der juengsten Werte aller Serien im juengsten Intervall
    if ($result.LatestTime) {
        $sum = 0.0
        foreach ($k in $result.Series.Keys) {
            if ($result.Series[$k].LatestTime -eq $result.LatestTime) {
                $sum += $result.Series[$k].Latest
            }
        }
        $result.Latest = $sum
    }

    return $result
}

function Write-Usage {
    param([string]$Label, [double]$Value, [double]$Limit, [string]$Unit)

    if ($Limit -le 0) { Write-Sub ("{0,-24} {1} {2}" -f $Label, $Value, $Unit) ; return 0 }
    $pct = [math]::Round(($Value / $Limit) * 100, 1)

    $color = "Green"
    if ($pct -ge $WarnThresholdPct) { $color = "Yellow" }
    if ($pct -ge 90)                { $color = "Red" }

    # kleiner Balken zur schnellen visuellen Einordnung
    $barLen  = [math]::Min([math]::Round($pct / 5, 0), 20)
    $bar     = ("#" * $barLen).PadRight(20, ".")

    Write-Sub ("{0,-24} {1,9} / {2,-9} {3}  [{4}] {5} %" -f $Label, $Value, "$Limit $Unit", "", $bar, $pct) $color
    return $pct
}

# =========================================================================
#  PRE-CHECK
# =========================================================================
Write-Section "PRE-CHECK"

Write-Info "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Err "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}

$verJson    = az version --output json 2>$null | ConvertFrom-Json
$cliVersion = $verJson.'azure-cli'
Write-Ok "Azure CLI gefunden: $cliVersion"

if (-not (Compare-Version -Current $cliVersion -Required $MinAzCliVersion)) {
    Write-Warn "Version aelter als $MinAzCliVersion - Update empfohlen (az upgrade)"
} else {
    Write-Ok "Azure CLI Version ausreichend (>= $MinAzCliVersion)"
}

Write-Info "Pruefe Azure-Anmeldung..."
$account = az account show --output json 2>$null | ConvertFrom-Json
if (-not $account) {
    Write-Warn "Kein Login vorhanden - starte 'az login'"
    az login --output none
    $account = az account show --output json 2>$null | ConvertFrom-Json
    if (-not $account) { Write-Err "Anmeldung fehlgeschlagen." ; exit 1 }
}
Write-Ok "Login vorhanden: $($account.user.name)"

if (-not [string]::IsNullOrWhiteSpace($SubscriptionId)) {
    az account set --subscription $SubscriptionId --output none 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Err "Subscription '$SubscriptionId' konnte nicht gesetzt werden." ; exit 1 }
    $account = az account show --output json | ConvertFrom-Json
}
Write-Ok "Subscription: $($account.name)"

# =========================================================================
#  GATEWAY
# =========================================================================
Write-Section "GATEWAY"

Write-Log "Lese Gateway '$GatewayName'..."
$gwJson = az network vnet-gateway show --name $GatewayName --resource-group $ResourceGroupName --output json 2>$null
if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($gwJson)) {
    Write-Err "Gateway '$GatewayName' in Resource Group '$ResourceGroupName' nicht gefunden."
    exit 1
}
$gw         = $gwJson | ConvertFrom-Json
$resourceId = $gw.id
$sku        = $gw.sku.name
$generation = $gw.vpnGatewayGeneration
if ([string]::IsNullOrWhiteSpace($generation)) { $generation = "Generation1" }

Write-Ok "Gateway gefunden: $GatewayName"
Write-Sub "SKU           : $sku ($generation)"
Write-Sub "Active-Active : $($gw.activeActive)"
Write-Sub "Region        : $($gw.location)"

if (-not $SkuLimits[$generation] -or -not $SkuLimits[$generation][$sku]) {
    Write-Err "Keine Limit-Daten fuer SKU '$sku' ($generation) hinterlegt."
    exit 1
}
$limits = $SkuLimits[$generation][$sku]
Write-Info "Limits: $($limits.Mbps) Mbps | $($limits.S2S) S2S-Tunnel | $($limits.P2S) P2S"

# Konfigurierte Verbindungen (aendert sich selten - einmalig lesen)
$connJson = az network vpn-connection list `
    --resource-group $ResourceGroupName `
    --query "[?virtualNetworkGateway1.id=='$resourceId']" `
    --output json 2>$null
$connections = @()
if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($connJson)) {
    $connections = @($connJson | ConvertFrom-Json)
}

# =========================================================================
#  GRANULARITAET ERMITTELN
# =========================================================================
Write-Section "GRANULARITAET"

$probeEnd   = (Get-Date).ToUniversalTime()
$probeStart = $probeEnd.AddMinutes(-30)
$activeInterval = $PreferredInterval

Write-Log "Pruefe Unterstuetzung fuer $PreferredInterval..."
$probe = Get-MetricWindow -ResourceId $resourceId -MetricName "AverageBandwidth" `
         -StartTime $probeStart.ToString("yyyy-MM-ddTHH:mm:ssZ") `
         -EndTime   $probeEnd.ToString("yyyy-MM-ddTHH:mm:ssZ") `
         -Interval  $PreferredInterval `
         -WindowStart $probeStart

if ($null -eq $probe) {
    $activeInterval = $FallbackInterval
    Write-Warn "$PreferredInterval nicht unterstuetzt - verwende $FallbackInterval"
} else {
    Write-Ok "Granularitaet: $activeInterval"
}

if ($LookbackMinutes -lt 5 -and $activeInterval -eq "PT5M") {
    Write-Warn "Fenster von $LookbackMinutes Minuten ist kleiner als die Granularitaet $activeInterval."
}

# =========================================================================
#  LIVE-AUSWERTUNG
# =========================================================================
function Show-LiveUtilization {

    $now         = (Get-Date).ToUniversalTime()
    $windowStart = $now.AddMinutes(-$LookbackMinutes)
    $queryStart  = $now.AddMinutes(-($LookbackMinutes + $LatencyBufferMinutes))

    $qsStr = $queryStart.ToString("yyyy-MM-ddTHH:mm:ssZ")
    $qeStr = $now.ToString("yyyy-MM-ddTHH:mm:ssZ")

    Write-Section "AUSLASTUNG - LETZTE $LookbackMinutes MINUTEN"
    Write-Sub ("Fenster : {0} - {1} UTC" -f $windowStart.ToString("HH:mm:ss"), $now.ToString("HH:mm:ss"))
    Write-Sub ("Abfrage : {0} Granularitaet, {1} Min. Latenzpuffer" -f $activeInterval, $LatencyBufferMinutes)

    $mS2S  = Get-MetricWindow -ResourceId $resourceId -MetricName "AverageBandwidth"   -StartTime $qsStr -EndTime $qeStr -Interval $activeInterval -WindowStart $windowStart
    $mP2S  = Get-MetricWindow -ResourceId $resourceId -MetricName "P2SBandwidth"       -StartTime $qsStr -EndTime $qeStr -Interval $activeInterval -WindowStart $windowStart
    $mP2SC = Get-MetricWindow -ResourceId $resourceId -MetricName "P2SConnectionCount" -StartTime $qsStr -EndTime $qeStr -Interval $activeInterval -WindowStart $windowStart -Aggregation "Maximum"

    # --- Datenaktualitaet -------------------------------------------------
    $latestTime = $null
    foreach ($m in @($mS2S, $mP2S)) {
        if ($m -and $m.LatestTime) {
            if ($null -eq $latestTime -or $m.LatestTime -gt $latestTime) { $latestTime = $m.LatestTime }
        }
    }

    Write-Host ""
    if ($null -eq $latestTime) {
        Write-Warn "Keine Messwerte im Fenster - kein Traffic oder Metriken noch nicht verfuegbar."
        Write-Sub "Plattform-Metriken erscheinen typischerweise mit 2-5 Minuten Verzoegerung." "Cyan"
        Write-Sub "Bei $LookbackMinutes Minuten Fenster ggf. LatencyBufferMinutes erhoehen." "Cyan"
        return
    }

    $ageSec = [math]::Round(($now - $latestTime).TotalSeconds, 0)
    $ageTxt = "{0} Sek." -f $ageSec
    if ($ageSec -gt 120) { $ageTxt = "{0} Min." -f [math]::Round($ageSec / 60, 1) }

    if ($ageSec -le 300) { Write-Ok "Juengster Datenpunkt: $($latestTime.ToString('HH:mm:ss')) UTC (vor $ageTxt)" }
    else                 { Write-Warn "Juengster Datenpunkt: $($latestTime.ToString('HH:mm:ss')) UTC (vor $ageTxt)" }

    # --- Durchsatz --------------------------------------------------------
    $s2sNow = 0.0 ; $s2sMax = 0.0 ; $s2sAvg = 0.0
    if ($mS2S -and $mS2S.HasData) {
        $s2sNow = ConvertTo-Mbps $mS2S.Latest
        $s2sMax = ConvertTo-Mbps $mS2S.Max
        $s2sAvg = ConvertTo-Mbps $mS2S.Avg
    }

    $p2sNow = 0.0 ; $p2sMax = 0.0 ; $p2sAvg = 0.0
    if ($mP2S -and $mP2S.HasData) {
        $p2sNow = ConvertTo-Mbps $mP2S.Latest
        $p2sMax = ConvertTo-Mbps $mP2S.Max
        $p2sAvg = ConvertTo-Mbps $mP2S.Avg
    }

    $totalNow = [math]::Round($s2sNow + $p2sNow, 2)
    $totalMax = [math]::Round($s2sMax + $p2sMax, 2)

    Write-Host ""
    Write-Host "  DURCHSATZ - AKTUELL (juengstes Intervall)" -ForegroundColor White
    $null      = Write-Usage -Label "S2S"    -Value $s2sNow   -Limit $limits.Mbps -Unit "Mbps"
    $null      = Write-Usage -Label "P2S"    -Value $p2sNow   -Limit $limits.Mbps -Unit "Mbps"
    $pctNow    = Write-Usage -Label "Gesamt" -Value $totalNow -Limit $limits.Mbps -Unit "Mbps"

    Write-Host ""
    Write-Host "  DURCHSATZ - FENSTER ($LookbackMinutes Min.)" -ForegroundColor White
    $pctMax = Write-Usage -Label "Spitze gesamt" -Value $totalMax -Limit $limits.Mbps -Unit "Mbps"
    Write-Sub ("{0,-24} S2S {1} Mbps | P2S {2} Mbps" -f "Mittelwert", $s2sAvg, $p2sAvg)

    # --- Verbindungen -----------------------------------------------------
    Write-Host ""
    Write-Host "  VERBINDUNGEN" -ForegroundColor White
    $null = Write-Usage -Label "S2S-Tunnel (konfig.)" -Value $connections.Count -Limit $limits.S2S -Unit "Tunnel"
    $p2sCount = 0
    if ($mP2SC -and $mP2SC.HasData) { $p2sCount = [math]::Round($mP2SC.Max, 0) }
    $pctP2SC = Write-Usage -Label "P2S-Verbindungen" -Value $p2sCount -Limit $limits.P2S -Unit "Verb."

    # --- Tunnel-Detail ----------------------------------------------------
    if ($ShowTunnelDetail) {
        $mTun = Get-MetricWindow -ResourceId $resourceId -MetricName "TunnelAverageBandwidth" `
                -StartTime $qsStr -EndTime $qeStr -Interval $activeInterval `
                -WindowStart $windowStart -SplitBy "ConnectionName"

        Write-Host ""
        Write-Host "  JE TUNNEL" -ForegroundColor White
        if ($mTun -and $mTun.HasData) {
            foreach ($key in ($mTun.Series.Keys | Sort-Object)) {
                $tNow = ConvertTo-Mbps $mTun.Series[$key].Latest
                $tMax = ConvertTo-Mbps $mTun.Series[$key].Max
                Write-Sub ("{0,-28} aktuell {1,8} Mbps | Spitze {2,8} Mbps" -f $key, $tNow, $tMax)
            }
        } else {
            Write-Sub "keine Tunnel-Metriken im Fenster" "Gray"
        }
    }

    # --- Bewertung --------------------------------------------------------
    $peakPct = 0
    foreach ($p in @($pctNow, $pctMax, $pctP2SC)) { if ($p -gt $peakPct) { $peakPct = $p } }

    Write-Host ""
    if ($peakPct -ge 90) {
        Write-Err "Kritische Auslastung ($peakPct %) - Engpass wahrscheinlich."
    } elseif ($peakPct -ge $WarnThresholdPct) {
        Write-Warn "Hohe Auslastung ($peakPct %) - Entwicklung beobachten."
    } elseif ($peakPct -lt $IdleThresholdPct) {
        Write-Ok "Geringe Auslastung ($peakPct %)."
    } else {
        Write-Ok "Auslastung im gruenen Bereich ($peakPct %)."
    }

    Write-Sub "Momentaufnahme - fuer die SKU-Entscheidung Langzeitauswertung heranziehen." "Cyan"
}

# =========================================================================
#  AUSFUEHRUNG
# =========================================================================
if (-not $WatchMode) {
    Show-LiveUtilization
    Write-Host ""
    Write-Line
} else {
    Write-Section "WATCH-MODUS"
    Write-Info "Aktualisierung alle $WatchIntervalSeconds Sekunden - Abbruch mit STRG+C"
    if ($WatchCount -gt 0) { Write-Sub "Anzahl Durchlaeufe: $WatchCount" }
    Start-Sleep -Seconds 2

    $run = 0
    while ($true) {
        $run++
        if ($ClearOnRefresh) { Clear-Host }

        Write-Line
        Write-Host ("[ LIVE ] $GatewayName ($sku)  -  Durchlauf $run  -  " + (Get-Date -Format "HH:mm:ss")) -ForegroundColor White
        Write-Line

        Show-LiveUtilization

        if ($WatchCount -gt 0 -and $run -ge $WatchCount) {
            Write-Host ""
            Write-Ok "Alle $WatchCount Durchlaeufe abgeschlossen."
            break
        }

        Write-Host ""
        Write-Line
        Start-Sleep -Seconds $WatchIntervalSeconds
    }
}
