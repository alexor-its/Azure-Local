﻿#Requires -Modules ActiveDirectory, GroupPolicy
#Requires -RunAsAdministrator

<#
.SYNOPSIS
    Befuellt die AVD-GPOs mit allen notwendigen Registry-Einstellungen.

.DESCRIPTION
    Teil 2 des AVD-AD-Prep. Setzt alle GPO-Werte fuer:
      - AVD-SessionHost-Base     (NLA, Timeouts, Firewall, RDP-Verschluesselung)
      - AVD-FSLogix-Config       (Profile Container, ODFC, Defender-Ausnahmen)
      - AVD-Security-Hardening   (Credential Guard, USB, SMB-Signing, Audit)
      - AVD-UserExperience       (OneDrive KFM, Wallpaper, Laufwerk-Redirect)
      - AVD-Loopback-UserSettings (bereits in Teil 1 gesetzt, wird hier ueberprueft)

    Voraussetzung: New-AVD-ADPrep.ps1 wurde erfolgreich ausgefuehrt.

.PARAMETER FSLogixProfileShare
    UNC-Pfad zur FSLogix-Profilfreigabe.
    Beispiel: \\fileserver01\profiles$

.PARAMETER FSLogixODFCShare
    UNC-Pfad fuer den Office Container (ODFC). Kann identisch mit ProfileShare sein.
    Wenn weggelassen, wird derselbe Pfad wie FSLogixProfileShare verwendet.

.PARAMETER FSLogixVHDSizeGB
    Maximale Groesse eines Profil-VHDs in GB. Standard: 30 GB.

.PARAMETER OneDriveTenantID
    Optional: Entra ID Tenant ID fuer OneDrive Known Folder Move (KFM).
    Leitet Desktop, Dokumente und Bilder automatisch nach OneDrive um.
    Zu finden im Azure Portal: Entra ID -> Uebersicht -> Tenant-ID.
    Oder per CLI: az account show --query tenantId --output tsv
    Wenn weggelassen, werden keine OneDrive KFM Einstellungen gesetzt.

.PARAMETER WallpaperUNCPath
    Optional: UNC-Pfad zu einer Wallpaper-Datei fuer AVD-Desktops.
    Beispiel: \\fileserver01\avd-resources\wallpaper.jpg

.EXAMPLE
    # Minimaler Aufruf - ohne OneDrive KFM
    .\2-Set-AVD-GPOSettings.ps1 `
        -FSLogixProfileShare '\\fileserver01\profiles$'

.EXAMPLE
    # Mit OneDrive KFM
    .\2-Set-AVD-GPOSettings.ps1 `
        -FSLogixProfileShare '\\fileserver01\profiles$' `
        -OneDriveTenantID    'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'

.EXAMPLE
    # Alle Parameter
    .\2-Set-AVD-GPOSettings.ps1 `
        -FSLogixProfileShare '\\fileserver01\profiles$' `
        -FSLogixVHDSizeGB    50 `
        -OneDriveTenantID    'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' `
        -WallpaperUNCPath    '\\fileserver01\avd-resources\wallpaper.jpg' `
        -WhatIf
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)]
    [ValidatePattern('^\\\\.*\\.*$')]
    [string]$FSLogixProfileShare,

    [Parameter()]
    [ValidatePattern('^\\\\.*\\.*$')]
    [string]$FSLogixODFCShare,

    [Parameter()]
    [ValidatePattern('^([0-9a-fA-F\-]{36})?$')]
    [string]$OneDriveTenantID = '',

    [Parameter()]
    [ValidateRange(10, 500)]
    [int]$FSLogixVHDSizeGB = 30,

    [Parameter()]
    [string]$WallpaperUNCPath = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ODFC-Share auf ProfileShare zurueckfallen lassen wenn nicht angegeben
if (-not $FSLogixODFCShare) { $FSLogixODFCShare = $FSLogixProfileShare }

$FSLogixVHDSizeMB = $FSLogixVHDSizeGB * 1024

# -----------------------------------------------------------------------------
# REGION: Hilfsfunktionen
# -----------------------------------------------------------------------------

function Write-Step  { param([string]$M); Write-Host "`n  >> $M" -ForegroundColor Cyan }
function Write-OK    { param([string]$M); Write-Host "    OK $M" -ForegroundColor Green }
function Write-Info  { param([string]$M); Write-Host "    . $M" -ForegroundColor Gray }
function Write-Fail  { param([string]$M); Write-Host "    XX $M" -ForegroundColor Red }

function Set-GPReg {
    <#
    .SYNOPSIS
        Setzt einen Registry-Wert in einem GPO (Computer- oder Benutzerkonfiguration).
        Wrapper um Set-GPRegistryValue mit ShouldProcess-Support und Logging.
    #>
    param(
        [string]$GpoName,
        [string]$Key,
        [string]$ValueName,
        [Microsoft.Win32.RegistryValueKind]$Type,
        $Value
    )
    $displayVal = if ($Value -is [array]) { $Value -join '; ' } else { $Value }
    if ($PSCmdlet.ShouldProcess("$GpoName -> $Key\$ValueName = $displayVal", 'GPO-Wert setzen')) {
        Set-GPRegistryValue `
            -Name      $GpoName `
            -Key       $Key `
            -ValueName $ValueName `
            -Type      $Type `
            -Value     $Value | Out-Null
        Write-OK "$ValueName = $displayVal"
    }
}

function Assert-GPOExists {
    param([string]$GpoName)
    $gpo = Get-GPO -Name $GpoName -ErrorAction SilentlyContinue
    if ($null -eq $gpo) {
        Write-Fail "GPO '$GpoName' nicht gefunden. Bitte zuerst New-AVD-ADPrep.ps1 ausfuehren."
        throw "GPO fehlt: $GpoName"
    }
    Write-Info "GPO gefunden: $GpoName (ID: $($gpo.Id))"
}

# -----------------------------------------------------------------------------
# REGION: Vorab-Pruefungen
# -----------------------------------------------------------------------------

Write-Host "`n========================================================" -ForegroundColor White
Write-Host   "|   AVD GPO Settings - Teil 2                          |" -ForegroundColor White
Write-Host   "========================================================`n" -ForegroundColor White

Write-Step "Pruefe Voraussetzungen..."

$requiredGPOs = @(
    'AVD-SessionHost-Base',
    'AVD-FSLogix-Config',
    'AVD-Security-Hardening',
    'AVD-UserExperience',
    'AVD-Loopback-UserSettings'
)
foreach ($gpoName in $requiredGPOs) { Assert-GPOExists -GpoName $gpoName }

Write-Info "FSLogix Profile Share : $FSLogixProfileShare"
Write-Info "FSLogix ODFC Share    : $FSLogixODFCShare"
Write-Info "FSLogix VHD-Groesse     : $FSLogixVHDSizeGB GB ($FSLogixVHDSizeMB MB)"
Write-Info "OneDrive Tenant ID    : $OneDriveTenantID"
if ($WallpaperUNCPath) { Write-Info "Wallpaper-Pfad        : $WallpaperUNCPath" }

# -----------------------------------------------------------------------------
# REGION: GPO 1 - AVD-SessionHost-Base
# -----------------------------------------------------------------------------

Write-Step "AVD-SessionHost-Base - RDP, NLA, Timeouts, Firewall..."

$gpo1 = 'AVD-SessionHost-Base'

# RDP aktivieren
Set-GPReg $gpo1 `
    'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server' `
    'fDenyTSConnections' DWord 0

# Network Level Authentication erzwingen
Set-GPReg $gpo1 `
    'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' `
    'UserAuthentication' DWord 1

# Verschluesselungsstufe: High (3)
Set-GPReg $gpo1 `
    'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' `
    'MinEncryptionLevel' DWord 3

# TLS/SSL-Sicherheitsebene erzwingen (2 = SSL)
Set-GPReg $gpo1 `
    'HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' `
    'SecurityLayer' DWord 2

# Sitzungs-Timeouts (in Millisekunden)
# Maximale Idle-Zeit: 2 Stunden = 7.200.000 ms
Set-GPReg $gpo1 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    'MaxIdleTime' DWord 7200000

# Maximale Zeit einer getrennten Sitzung: 4 Stunden = 14.400.000 ms
Set-GPReg $gpo1 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    'MaxDisconnectionTime' DWord 14400000

# Maximale Gesamtsitzungszeit: 12 Stunden = 43.200.000 ms (0 = unbegrenzt)
Set-GPReg $gpo1 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    'MaxConnectionTime' DWord 0

# Getrennte Sitzungen bei Idle beenden
Set-GPReg $gpo1 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    'fResetBroken' DWord 1

# Zeitzonenumlenkung aktivieren (Nutzer sieht seine eigene Zeitzone)
Set-GPReg $gpo1 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    'fEnableTimeZoneRedirection' DWord 1

# Drucker-Redirection standardmaessig aktivieren
Set-GPReg $gpo1 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    'fDisableCpm' DWord 0

# Clipboard-Redirection aktivieren (kann in Hardening-GPO eingeschraenkt werden)
Set-GPReg $gpo1 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    'fDisableClip' DWord 0

# Laufwerk-Redirection deaktivieren (Sicherheit - Nutzer sollen keine lokalen Laufwerke mounten)
Set-GPReg $gpo1 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    'fDisableCdm' DWord 1

# Windows-Firewall: RDP-Regel aktivieren (lokale Netzwerke)
Set-GPReg $gpo1 `
    'HKLM\SOFTWARE\Policies\Microsoft\WindowsFirewall\DomainProfile' `
    'EnableFirewall' DWord 1

# -----------------------------------------------------------------------------
# REGION: GPO 2 - AVD-FSLogix-Config
# -----------------------------------------------------------------------------

Write-Step "AVD-FSLogix-Config - Profile Container, ODFC, Defender-Ausnahmen..."

$gpo2     = 'AVD-FSLogix-Config'
$keyFSL   = 'HKLM\SOFTWARE\FSLogix\Profiles'
$keyODFC  = 'HKLM\SOFTWARE\Policies\FSLogix\ODFC'

# -- Profile Container ------------------------------------------------------

# Profile Container aktivieren
Set-GPReg $gpo2 $keyFSL 'Enabled' DWord 1

# VHD-Speicherpfad (Mehrfachpfade als Multi-String moeglich)
Set-GPReg $gpo2 $keyFSL 'VHDLocations' MultiString @($FSLogixProfileShare)

# VHD-Format: VHDX (1) statt VHD (0)
Set-GPReg $gpo2 $keyFSL 'VolumeType' String 'VHDX'

# Maximale VHD-Groesse in MB
Set-GPReg $gpo2 $keyFSL 'SizeInMBs' DWord $FSLogixVHDSizeMB

# Lokales Profil loeschen wenn VHD greift
Set-GPReg $gpo2 $keyFSL 'DeleteLocalProfileWhenVHDShouldApply' DWord 1

# Concurrent User Sessions (wichtig fuer Pooled - mehrere Sessions desselben Nutzers)
Set-GPReg $gpo2 $keyFSL 'ConcurrentUserSessions' DWord 1

# Profil bei sauberem Logout kompaktieren (reduziert VHD-Groesse)
Set-GPReg $gpo2 $keyFSL 'ShrinkDynamicDisks' DWord 1

# Keine lokalen Profile fuer Nutzer die in Ausnahme-Gruppe sind
Set-GPReg $gpo2 $keyFSL 'PreventLoginWithFailure' DWord 1

# Retry-Verhalten beim VHD-Mount-Fehler
Set-GPReg $gpo2 $keyFSL 'ReAttachIntervalSeconds' DWord 15
Set-GPReg $gpo2 $keyFSL 'ReAttachRetryCount'      DWord 3

# -- Office Container (ODFC) -------------------------------------------------

# ODFC aktivieren
Set-GPReg $gpo2 $keyODFC 'Enabled' DWord 1

# ODFC VHD-Pfad
Set-GPReg $gpo2 $keyODFC 'VHDLocations' MultiString @($FSLogixODFCShare)

# ODFC VHD-Format
Set-GPReg $gpo2 $keyODFC 'VolumeType' String 'VHDX'

# ODFC Groesse (Standard: 30 GB, separater Container)
Set-GPReg $gpo2 $keyODFC 'SizeInMBs' DWord $FSLogixVHDSizeMB

# Teams-Cache in ODFC einschliessen
Set-GPReg $gpo2 $keyODFC 'IncludeTeams' DWord 1

# -- Defender-Ausnahmen fuer FSLogix -----------------------------------------
# Verhindert massiven I/O durch Defender beim VHD-Mount

$defExclKey = 'HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions'

# Pfad-Ausnahmen
$defPathKey = "$defExclKey\Paths"
Set-GPReg $gpo2 $defPathKey '%ProgramData%\FSLogix'         String 0
Set-GPReg $gpo2 $defPathKey '%SystemRoot%\Temp\*\*.VHD'    String 0
Set-GPReg $gpo2 $defPathKey '%SystemRoot%\Temp\*\*.VHDX'   String 0
Set-GPReg $gpo2 $defPathKey '%TEMP%\*\*.VHD'               String 0
Set-GPReg $gpo2 $defPathKey '%TEMP%\*\*.VHDX'              String 0
Set-GPReg $gpo2 $defPathKey $FSLogixProfileShare            String 0
Set-GPReg $gpo2 $defPathKey $FSLogixODFCShare               String 0

# Dateiendungs-Ausnahmen
$defExtKey = "$defExclKey\Extensions"
Set-GPReg $gpo2 $defExtKey 'VHD'      String 0
Set-GPReg $gpo2 $defExtKey 'VHDX'     String 0
Set-GPReg $gpo2 $defExtKey 'VHD.lock' String 0
Set-GPReg $gpo2 $defExtKey 'VHD.meta' String 0

# Defender-Ausnahmen Policy aktivieren (Wert muss gesetzt sein damit Ausnahmen greifen)
Set-GPReg $gpo2 $defExclKey 'DisableExtensionsMTPE' DWord 0

# -----------------------------------------------------------------------------
# REGION: GPO 3 - AVD-Security-Hardening
# -----------------------------------------------------------------------------

Write-Step "AVD-Security-Hardening - Credential Guard, USB, SMB, Audit..."

$gpo3 = 'AVD-Security-Hardening'

# -- Credential Guard --------------------------------------------------------

# Virtualization Based Security aktivieren
Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' `
    'EnableVirtualizationBasedSecurity' DWord 1

# Credential Guard aktivieren (1 = ohne UEFI Lock, 2 = mit UEFI Lock)
Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' `
    'LsaCfgFlags' DWord 1

# Secure Boot + DMA Protection
Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' `
    'RequirePlatformSecurityFeatures' DWord 3

# -- USB / Wechselmedien sperren ---------------------------------------------

# Alle Wechselmedien verweigern (Lesen & Schreiben)
Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices' `
    'Deny_All' DWord 1

# USB-Massenspeicher deaktivieren
Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices\{53f56307-b6bf-11d0-94f2-00a0c91efb8b}' `
    'Deny_Read' DWord 1

Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices\{53f56307-b6bf-11d0-94f2-00a0c91efb8b}' `
    'Deny_Write' DWord 1

# -- SMB-Signing erzwingen ---------------------------------------------------

# SMB-Client: Signing erforderlich
Set-GPReg $gpo3 `
    'HKLM\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' `
    'RequireSecuritySignature' DWord 1

Set-GPReg $gpo3 `
    'HKLM\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' `
    'EnableSecuritySignature' DWord 1

# SMB-Server: Signing erforderlich
Set-GPReg $gpo3 `
    'HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' `
    'RequireSecuritySignature' DWord 1

Set-GPReg $gpo3 `
    'HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' `
    'EnableSecuritySignature' DWord 1

# -- Audit-Richtlinien -------------------------------------------------------
# Werden ueber Registry (Advanced Audit) gesteuert

# Anmeldeereignisse protokollieren (Erfolg + Fehler)
Set-GPReg $gpo3 `
    'HKLM\SYSTEM\CurrentControlSet\Control\Lsa' `
    'SCENoApplyLegacyAuditPolicy' DWord 1

# Lokale Administratoren: Anmeldung einschraenken (nur ueber Jump-Host)
Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    'LocalAccountTokenFilterPolicy' DWord 0

# UAC: Alle Erhoehungen auf dem sicheren Desktop
Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    'ConsentPromptBehaviorAdmin' DWord 2

Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' `
    'PromptOnSecureDesktop' DWord 1

# -- LAPS (Local Administrator Password Solution) ---------------------------
# Empfohlen: Windows LAPS (ab 2023) aktivieren

Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\LAPS\Config' `
    'BackupDirectory' DWord 2   # 2 = Azure AD / Entra ID Backup

Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\LAPS\Config' `
    'PasswordComplexity' DWord 4   # Gross, Klein, Ziffern, Sonderzeichen

Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\LAPS\Config' `
    'PasswordLength' DWord 20

Set-GPReg $gpo3 `
    'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\LAPS\Config' `
    'PasswordAgeDays' DWord 30

# -----------------------------------------------------------------------------
# REGION: GPO 4 - AVD-UserExperience
# -----------------------------------------------------------------------------

Write-Step "AVD-UserExperience - OneDrive KFM, Wallpaper, Startmenue..."

$gpo4 = 'AVD-UserExperience'

# -- OneDrive Known Folder Move ----------------------------------------------
# Nur wenn Tenant ID angegeben wurde

if ($OneDriveTenantID -ne '') {
    Write-Info "OneDrive KFM wird konfiguriert (Tenant ID: $OneDriveTenantID)"

    # KFM silent activation (Desktop, Dokumente, Bilder nach OneDrive)
    Set-GPReg $gpo4 `
        'HKCU\SOFTWARE\Policies\Microsoft\OneDrive' `
        'KFMSilentOptIn' String $OneDriveTenantID

    # Nutzer darf KFM nicht deaktivieren
    Set-GPReg $gpo4 `
        'HKCU\SOFTWARE\Policies\Microsoft\OneDrive' `
        'KFMBlockOptOut' DWord 1

    # OneDrive beim Login automatisch starten
    Set-GPReg $gpo4 `
        'HKCU\SOFTWARE\Policies\Microsoft\OneDrive' `
        'DisablePersonalSync' DWord 0

    # Dateien on-demand (kein vollstaendiger Download auf Session Host)
    Set-GPReg $gpo4 `
        'HKLM\SOFTWARE\Policies\Microsoft\OneDrive' `
        'FilesOnDemandEnabled' DWord 1

    # OneDrive fuer alle Nutzer auf dem Session Host (Machine-weite Installation)
    Set-GPReg $gpo4 `
        'HKLM\SOFTWARE\Policies\Microsoft\OneDrive' `
        'AllUsersInstall' DWord 1

    # Tenant ID fuer Single-Tenant-Erzwingung
    Set-GPReg $gpo4 `
        'HKLM\SOFTWARE\Policies\Microsoft\OneDrive\AllowTenantList' `
        $OneDriveTenantID String $OneDriveTenantID
}
else {
    Write-Info "OneDrive KFM uebersprungen - kein -OneDriveTenantID angegeben"
    Write-Info "Nachtraeglich aktivierbar mit: .\2-Set-AVD-GPOSettings.ps1 -FSLogixProfileShare '...' -OneDriveTenantID 'xxxx-...'"
}

# -- Wallpaper ---------------------------------------------------------------

if ($WallpaperUNCPath) {
    Set-GPReg $gpo4 `
        'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System' `
        'Wallpaper' String $WallpaperUNCPath

    # Wallpaper-Stil: 2 = Gestreckt, 10 = Fuellen
    Set-GPReg $gpo4 `
        'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System' `
        'WallpaperStyle' String '10'

    # Nutzer darf Wallpaper nicht aendern
    Set-GPReg $gpo4 `
        'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\ActiveDesktop' `
        'NoChangingWallPaper' DWord 1
}

# -- Startmenue / Taskleiste einschraenken ------------------------------------

# Suchleiste in Taskleiste ausblenden (reduziert Ablenkung auf VDI)
Set-GPReg $gpo4 `
    'HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Search' `
    'SearchboxTaskbarMode' DWord 0

# Cortana deaktivieren
Set-GPReg $gpo4 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search' `
    'AllowCortana' DWord 0

# News und Interessen in Taskleiste deaktivieren
Set-GPReg $gpo4 `
    'HKCU\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds' `
    'EnableFeeds' DWord 0

# Widgets deaktivieren (Windows 11)
Set-GPReg $gpo4 `
    'HKLM\SOFTWARE\Policies\Microsoft\Dsh' `
    'AllowNewsAndInterests' DWord 0

# Teams Chat-Icon in Taskleiste entfernen (Windows 11 Consumer Teams)
Set-GPReg $gpo4 `
    'HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Chat' `
    'ChatIcon' DWord 3

# -- Leistungsoptimierung fuer VDI --------------------------------------------

# Animationen reduzieren
Set-GPReg $gpo4 `
    'HKCU\Control Panel\Desktop\WindowMetrics' `
    'MinAnimate' String '0'

# Visuelle Effekte auf Performance optimieren
Set-GPReg $gpo4 `
    'HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' `
    'VisualFXSetting' DWord 2

# Screensaver deaktivieren (Sitzungstimeout uebernimmt das)
Set-GPReg $gpo4 `
    'HKCU\Software\Policies\Microsoft\Windows\Control Panel\Desktop' `
    'ScreenSaveActive' String '0'

# -----------------------------------------------------------------------------
# REGION: GPO 5 - AVD-Loopback-UserSettings (Verifizierung)
# -----------------------------------------------------------------------------

Write-Step "AVD-Loopback-UserSettings - Loopback-Modus verifizieren..."

$gpo5 = 'AVD-Loopback-UserSettings'

$loopbackVal = Get-GPRegistryValue `
    -Name      $gpo5 `
    -Key       'HKLM\SOFTWARE\Policies\Microsoft\Windows\System' `
    -ValueName 'UserPolicyMode' `
    -ErrorAction SilentlyContinue

if ($null -eq $loopbackVal -or $loopbackVal.Value -ne 1) {
    Write-Info "Loopback-Wert nicht gesetzt oder falsch - wird korrigiert..."
    Set-GPReg $gpo5 `
        'HKLM\SOFTWARE\Policies\Microsoft\Windows\System' `
        'UserPolicyMode' DWord 1
}
else {
    Write-OK "Loopback Processing = Replace bereits korrekt gesetzt"
}

# -----------------------------------------------------------------------------
# REGION: Zusammenfassung
# -----------------------------------------------------------------------------

Write-Host "`n========================================================" -ForegroundColor White
Write-Host   "|   Alle GPO-Einstellungen gesetzt                     |" -ForegroundColor White
Write-Host   "========================================================" -ForegroundColor White

$oneDriveStatus = if ($OneDriveTenantID -ne '') { "KFM aktiv (Tenant: $OneDriveTenantID)" } else { "KFM nicht konfiguriert (kein -OneDriveTenantID)" }

Write-Host @"

  GPO-Uebersicht:
  +-----------------------------+--------------+-------------------------------------+
  | GPO                         | Konfiguration| Zweck                               |
  +-----------------------------+--------------+-------------------------------------+
  | AVD-SessionHost-Base        | Computer     | RDP, NLA, Timeouts, Clipboard       |
  | AVD-FSLogix-Config          | Computer     | Profile + ODFC Container, Defender  |
  | AVD-Security-Hardening      | Computer     | Credential Guard, USB, SMB, LAPS    |
  | AVD-UserExperience          | User         | Wallpaper, Taskleiste               |
  | AVD-Loopback-UserSettings   | Computer     | Loopback Replace                    |
  +-----------------------------+--------------+-------------------------------------+

  OneDrive KFM : $oneDriveStatus

  Naechste Schritte:
  1. gpupdate /force auf einem Session Host testen (nach erstem Domain Join)
  2. RSoP pruefen:  gpresult /h C:\Temp\gpresult.html /f
  3. FSLogix-Profilpfad erreichbar? Test-Path '$FSLogixProfileShare'
  4. Defender-Ausnahmen aktiv?  Get-MpPreference | Select-Object ExclusionPath,ExclusionExtension
  5. LAPS: Az-Modul installieren und  Get-LapsAADPassword -DeviceId <SessionHost>

"@ -ForegroundColor White
