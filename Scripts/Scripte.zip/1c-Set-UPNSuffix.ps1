﻿# UPN Migration: azl.com → arcdemolab.org
# Mit WhatIf-Modus und Einzelbenutzer-Auswahl

$OldSuffix = "@azl.com"
$NewSuffix = "@arcdemolab.org"

# Alle betroffenen Benutzer laden
Write-Host "`n=== UPN Migration Tool ===" -ForegroundColor Cyan
Write-Host "Lade Benutzer mit Suffix '$OldSuffix'...`n" -ForegroundColor Yellow

$Users = Get-ADUser -Filter {UserPrincipalName -like "*@azl.com"} -Properties UserPrincipalName, DisplayName

if ($Users.Count -eq 0) {
    Write-Host "Keine Benutzer mit '$OldSuffix' gefunden." -ForegroundColor Red
    exit
}

# Benutzer auflisten
Write-Host "Gefundene Benutzer:" -ForegroundColor Green
$i = 1
foreach ($User in $Users) {
    Write-Host "  [$i] $($User.DisplayName) → $($User.UserPrincipalName)" -ForegroundColor White
    $i++
}

# Auswahl
Write-Host "`nOptionen:" -ForegroundColor Cyan
Write-Host "  [0] Alle Benutzer migrieren" -ForegroundColor White
Write-Host "  [1-$($Users.Count)] Einzelnen Benutzer auswählen" -ForegroundColor White
Write-Host "  [Q] Abbrechen`n" -ForegroundColor White

$Input = Read-Host "Auswahl"

if ($Input -eq "Q" -or $Input -eq "q") {
    Write-Host "Abgebrochen." -ForegroundColor Yellow
    exit
}

# Ziel-Benutzer bestimmen
if ($Input -eq "0") {
    $TargetUsers = $Users
    Write-Host "`nAlle $($Users.Count) Benutzer ausgewählt." -ForegroundColor Yellow
} elseif ($Input -match '^\d+$' -and [int]$Input -ge 1 -and [int]$Input -le $Users.Count) {
    $TargetUsers = @($Users[[int]$Input - 1])
    Write-Host "`nBenutzer '$($TargetUsers[0].DisplayName)' ausgewählt." -ForegroundColor Yellow
} else {
    Write-Host "Ungültige Eingabe. Abgebrochen." -ForegroundColor Red
    exit
}

# WhatIf-Modus abfragen
Write-Host "`nModus wählen:" -ForegroundColor Cyan
Write-Host "  [1] WhatIf (nur simulieren, keine Änderungen)" -ForegroundColor White
Write-Host "  [2] Live (Änderungen wirklich durchführen)`n" -ForegroundColor White

$ModeInput = Read-Host "Modus"

$WhatIf = $true
if ($ModeInput -eq "2") {
    Write-Host "`n⚠️  ACHTUNG: Änderungen werden WIRKLICH durchgeführt!" -ForegroundColor Red
    $Confirm = Read-Host "Bist du sicher? (j/ja/nein)"
    
    if ($Confirm -notin @("j", "ja")) {
        Write-Host "Abgebrochen." -ForegroundColor Yellow
        exit
    }
    $WhatIf = $false
} else {
    Write-Host "`n[WhatIf-Modus] Keine echten Änderungen werden vorgenommen.`n" -ForegroundColor Cyan
}

# Migration durchführen
Write-Host "`n=== Starte Migration ===" -ForegroundColor Cyan

foreach ($User in $TargetUsers) {
    $OldUPN = $User.UserPrincipalName
    $NewUPN = $OldUPN -replace [regex]::Escape($OldSuffix), $NewSuffix

    if ($WhatIf) {
        Write-Host "[WhatIf] '$($User.DisplayName)': $OldUPN → $NewUPN" -ForegroundColor DarkYellow
    } else {
        try {
            Set-ADUser $User -UserPrincipalName $NewUPN
            Write-Host "[OK] '$($User.DisplayName)': $OldUPN → $NewUPN" -ForegroundColor Green
        } catch {
            Write-Host "[FEHLER] '$($User.DisplayName)': $($_.Exception.Message)" -ForegroundColor Red
        }
    }
}

Write-Host "`n=== Migration abgeschlossen ===" -ForegroundColor Cyan