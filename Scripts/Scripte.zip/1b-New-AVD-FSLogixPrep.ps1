﻿#Requires -RunAsAdministrator
#Requires -Modules ActiveDirectory

<#
.SYNOPSIS
    Bereitet den Fileserver fuer FSLogix Profile Container vor (AVD auf Azure Local).

.DESCRIPTION
    Wird lokal auf dem Windows Server 2025 Member-Server ausgefuehrt.

    Erstellt:
      - Verzeichnis fuer FSLogix Profile + ODFC (ein Share fuer beides)
      - SMB-Share mit korrekten Share-Berechtigungen
      - NTFS-Berechtigungen gemaess FSLogix Best Practices:
          Creator Owner        : Modify (Subfolders + Files)
          svc-avd-fslogix      : Modify (This Folder + Subfolders + Files)
          GRP-AVD-Pooled-Users : Modify (Subfolders + Files, kein Zugriff auf Root)
          GRP-AVD-Personal-Users: Modify (Subfolders + Files, kein Zugriff auf Root)
          SYSTEM               : Full Control
          Domain Admins        : Full Control
      - DFS-Namespace Hinweis (optional, manuell)
      - FSLogix Feature-Validierung

.PARAMETER SharePath
    Lokaler Pfad fuer den FSLogix Share.
    Standard: D:\FSLogix\Profiles

.PARAMETER ShareName
    Name des SMB-Shares.
    Standard: profiles$

.PARAMETER DomainFQDN
    FQDN der Domain. Wird automatisch ermittelt wenn nicht angegeben.

.PARAMETER DomainNetBIOS
    NetBIOS-Name der Domain. Wird automatisch ermittelt wenn nicht angegeben.

.PARAMETER MaxShareSizeGB
    Maximale Share-Groesse in GB (fuer Quota-Hinweis). Standard: 500

.EXAMPLE
    .\1b-New-AVD-FSLogixPrep.ps1

.EXAMPLE
    .\1b-New-AVD-FSLogixPrep.ps1 -SharePath 'E:\FSLogix\Profiles' -ShareName 'profiles$'

.EXAMPLE
    .\1b-New-AVD-FSLogixPrep.ps1 -WhatIf
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter()]
    [string]$SharePath = 'D:\FSLogix\Profiles',

    [Parameter()]
    [string]$ShareName = 'profiles$',

    [Parameter()]
    [string]$DomainFQDN = '',

    [Parameter()]
    [string]$DomainNetBIOS = '',

    [Parameter()]
    [ValidateRange(50, 10000)]
    [int]$MaxShareSizeGB = 500
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
# REGION: Hilfsfunktionen
# ---------------------------------------------------------------------------

function Write-Step { param([string]$M); Write-Host "`n  >> $M" -ForegroundColor Cyan }
function Write-OK   { param([string]$M); Write-Host "    OK  $M" -ForegroundColor Green }
function Write-Info { param([string]$M); Write-Host "    ..  $M" -ForegroundColor Gray }
function Write-Warn { param([string]$M); Write-Host "    !!  $M" -ForegroundColor Yellow }
function Write-Fail { param([string]$M); Write-Host "    XX  $M" -ForegroundColor Red }

# ---------------------------------------------------------------------------
# REGION: Header
# ---------------------------------------------------------------------------

Write-Host ''
Write-Host '======================================================' -ForegroundColor White
Write-Host '   FSLogix Fileserver Vorbereitung - AVD Azure Local  ' -ForegroundColor White
Write-Host '   Windows Server 2025 Member Server                  ' -ForegroundColor White
Write-Host '======================================================' -ForegroundColor White
Write-Host ''

# ---------------------------------------------------------------------------
# REGION: Domain-Info ermitteln
# ---------------------------------------------------------------------------

Write-Step 'Ermittle Domain-Informationen...'

try {
    $domain = Get-ADDomain -ErrorAction Stop
    if ($DomainFQDN    -eq '') { $DomainFQDN    = $domain.DNSRoot }
    if ($DomainNetBIOS -eq '') { $DomainNetBIOS = $domain.NetBIOSName }
    Write-OK "Domain FQDN:    $DomainFQDN"
    Write-OK "Domain NetBIOS: $DomainNetBIOS"
}
catch {
    Write-Fail "Domain-Info konnte nicht ermittelt werden: $_"
    Write-Fail "Bitte -DomainFQDN und -DomainNetBIOS manuell angeben."
    exit 1
}

$UNCPath    = "\\$env:COMPUTERNAME\$ShareName"
$ServerFQDN = "$env:COMPUTERNAME.$DomainFQDN"

Write-OK "Server:         $ServerFQDN"
Write-OK "Share-Pfad:     $SharePath"
Write-OK "UNC-Pfad:       $UNCPath"

# ---------------------------------------------------------------------------
# REGION: Voraussetzungen pruefen
# ---------------------------------------------------------------------------

Write-Step 'Pruefe Voraussetzungen...'

# Windows Server Version
$osInfo = Get-CimInstance Win32_OperatingSystem
Write-OK "Betriebssystem: $($osInfo.Caption)"

# File-Server Role (FS-FileServer)
$fsRole = Get-WindowsFeature -Name FS-FileServer -ErrorAction SilentlyContinue
if ($fsRole.InstallState -ne 'Installed') {
    Write-Warn "File Server Rolle nicht installiert - wird installiert..."
    if ($PSCmdlet.ShouldProcess('FS-FileServer', 'Windows Feature installieren')) {
        Install-WindowsFeature -Name FS-FileServer -IncludeManagementTools | Out-Null
        Write-OK "File Server Rolle installiert"
    }
}
else {
    Write-OK "File Server Rolle: installiert"
}

# SMB1 deaktivieren (Sicherheit)
$smb1 = Get-SmbServerConfiguration | Select-Object -ExpandProperty EnableSMB1Protocol
if ($smb1) {
    Write-Warn "SMB1 ist aktiv - wird deaktiviert (Sicherheitsempfehlung)..."
    if ($PSCmdlet.ShouldProcess('SMB1', 'Deaktivieren')) {
        Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force
        Write-OK "SMB1 deaktiviert"
    }
}
else {
    Write-OK "SMB1: deaktiviert (OK)"
}

# SMB Signing pruefen
$smbSigning = Get-SmbServerConfiguration | Select-Object -ExpandProperty RequireSecuritySignature
if (-not $smbSigning) {
    Write-Warn "SMB Signing nicht erzwungen - wird aktiviert..."
    if ($PSCmdlet.ShouldProcess('SMB Signing', 'Aktivieren')) {
        Set-SmbServerConfiguration -RequireSecuritySignature $true -Force
        Write-OK "SMB Signing aktiviert"
    }
}
else {
    Write-OK "SMB Signing: erzwungen (OK)"
}

# ---------------------------------------------------------------------------
# REGION: AD-Gruppen und Service Account pruefen
# ---------------------------------------------------------------------------

Write-Step 'Pruefe AD-Objekte (aus Skript 1-New-AVD-ADPrep.ps1)...'

$requiredADObjects = @(
    @{ Type = 'User';  Name = 'svc-avd-fslogix' },
    @{ Type = 'Group'; Name = 'GRP-AVD-Pooled-Users' },
    @{ Type = 'Group'; Name = 'GRP-AVD-Personal-Users' }
)

$adOK = $true
foreach ($obj in $requiredADObjects) {
    try {
        if ($obj.Type -eq 'User') {
            Get-ADUser -Identity $obj.Name -ErrorAction Stop | Out-Null
        }
        else {
            Get-ADGroup -Identity $obj.Name -ErrorAction Stop | Out-Null
        }
        Write-OK "$($obj.Type) gefunden: $($obj.Name)"
    }
    catch {
        Write-Fail "$($obj.Type) nicht gefunden: $($obj.Name)"
        Write-Fail "Bitte zuerst 1-New-AVD-ADPrep.ps1 ausfuehren!"
        $adOK = $false
    }
}

if (-not $adOK) {
    Write-Host ''
    Write-Fail "Fehlende AD-Objekte - Skript wird beendet."
    exit 1
}

# ---------------------------------------------------------------------------
# REGION: Verzeichnis erstellen
# ---------------------------------------------------------------------------

Write-Step "Erstelle Verzeichnis: $SharePath"

$parentPath = Split-Path $SharePath -Parent

# Laufwerk pruefen
$drive = Split-Path $SharePath -Qualifier
if (-not (Test-Path $drive)) {
    Write-Fail "Laufwerk $drive nicht gefunden. Bitte -SharePath anpassen."
    exit 1
}

if (Test-Path $SharePath) {
    Write-Warn "Verzeichnis existiert bereits: $SharePath"
}
else {
    if ($PSCmdlet.ShouldProcess($SharePath, 'Verzeichnis erstellen')) {
        New-Item -Path $SharePath -ItemType Directory -Force | Out-Null
        Write-OK "Verzeichnis erstellt: $SharePath"
    }
}

# ---------------------------------------------------------------------------
# REGION: NTFS-Berechtigungen setzen
# ---------------------------------------------------------------------------

Write-Step 'Setze NTFS-Berechtigungen (FSLogix Best Practice)...'

# Berechtigungskonzept laut Microsoft FSLogix Docs:
#
#   SYSTEM               : Full Control  (This Folder, Subfolders, Files)
#   Domain Admins        : Full Control  (This Folder, Subfolders, Files)
#   Creator Owner        : Modify        (Subfolders + Files only - kein Root-Zugriff)
#   svc-avd-fslogix      : Modify        (This Folder, Subfolders, Files)
#   GRP-AVD-Pooled-Users : Modify        (Subfolders + Files only - kein Root-Zugriff)
#   GRP-AVD-Personal-Users: Modify       (Subfolders + Files only - kein Root-Zugriff)
#
# WICHTIG: Nutzer koennen eigenes Profil-VHDX lesen/schreiben,
#          aber NICHT die Profile anderer Nutzer sehen (kein Root-Zugriff)

if ($PSCmdlet.ShouldProcess($SharePath, 'NTFS-Berechtigungen setzen')) {

    # Bestehende ACL laden
    $acl = Get-Acl -Path $SharePath

    # Vererbung deaktivieren und bestehende Rechte entfernen (Clean Slate)
    $acl.SetAccessRuleProtection($true, $false)

    # Hilfsfunktion fuer ACE-Erstellung
    function New-ACE {
        param(
            [string]$Identity,
            [string]$Rights,
            [string]$Inheritance,  # 'Full', 'SubOnly', 'None'
            [string]$Type = 'Allow'
        )
        $fsRights = [System.Security.AccessControl.FileSystemRights]$Rights

        switch ($Inheritance) {
            'Full' {
                # This Folder, Subfolders, Files
                $inherit = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
                $prop    = [System.Security.AccessControl.PropagationFlags]'None'
            }
            'SubOnly' {
                # Subfolders + Files only (kein direkter Root-Zugriff)
                $inherit = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
                $prop    = [System.Security.AccessControl.PropagationFlags]'InheritOnly'
            }
            'None' {
                $inherit = [System.Security.AccessControl.InheritanceFlags]'None'
                $prop    = [System.Security.AccessControl.PropagationFlags]'None'
            }
        }

        return New-Object System.Security.AccessControl.FileSystemAccessRule(
            $Identity, $fsRights, $inherit, $prop,
            [System.Security.AccessControl.AccessControlType]$Type
        )
    }

    # Alle ACEs hinzufuegen
    $aces = @(
        # SYSTEM - Full Control - This Folder + Subfolders + Files
        New-ACE "$DomainNetBIOS\Domain Admins"          'FullControl' 'Full'
        New-ACE 'SYSTEM'                                 'FullControl' 'Full'
        # svc-avd-fslogix - Modify - This Folder + Subfolders + Files
        New-ACE "$DomainNetBIOS\svc-avd-fslogix"        'Modify'      'Full'
        # Nutzergruppen - Modify - nur Subfolders + Files (InheritOnly)
        # Kein direkter Lesezugriff auf Root -> Nutzer sehen keine anderen Profile
        New-ACE "$DomainNetBIOS\GRP-AVD-Pooled-Users"   'Modify'      'SubOnly'
        New-ACE "$DomainNetBIOS\GRP-AVD-Personal-Users" 'Modify'      'SubOnly'
        # Creator Owner - Modify - Subfolders + Files (eigenes Profil)
        New-ACE 'CREATOR OWNER'                          'Modify'      'SubOnly'
    )

    foreach ($ace in $aces) {
        $acl.AddAccessRule($ace)
    }

    Set-Acl -Path $SharePath -AclObject $acl
    Write-OK "NTFS-Berechtigungen gesetzt"

    # Berechtigungen ausgeben zur Verifikation
    Write-Host ''
    Write-Host '    NTFS-Berechtigungen auf ' -NoNewline -ForegroundColor Gray
    Write-Host $SharePath -ForegroundColor White
    Write-Host '    +---------------------------+-------------+---------------------------+' -ForegroundColor Gray
    Write-Host '    | Identitaet                | Rechte      | Vererbung                 |' -ForegroundColor Gray
    Write-Host '    +---------------------------+-------------+---------------------------+' -ForegroundColor Gray
    $ntfsDisplay = @(
        @{ ID = 'SYSTEM';                    R = 'Full Control'; I = 'This+Sub+Files' },
        @{ ID = 'Domain Admins';             R = 'Full Control'; I = 'This+Sub+Files' },
        @{ ID = 'svc-avd-fslogix';           R = 'Modify';       I = 'This+Sub+Files' },
        @{ ID = 'GRP-AVD-Pooled-Users';      R = 'Modify';       I = 'Sub+Files only' },
        @{ ID = 'GRP-AVD-Personal-Users';    R = 'Modify';       I = 'Sub+Files only' },
        @{ ID = 'CREATOR OWNER';             R = 'Modify';       I = 'Sub+Files only' }
    )
    foreach ($row in $ntfsDisplay) {
        Write-Host "    | $($row.ID.PadRight(25)) | $($row.R.PadRight(11)) | $($row.I.PadRight(25)) |" -ForegroundColor Gray
    }
    Write-Host '    +---------------------------+-------------+---------------------------+' -ForegroundColor Gray
}

# ---------------------------------------------------------------------------
# REGION: SMB-Share erstellen
# ---------------------------------------------------------------------------

Write-Step "Erstelle SMB-Share: $ShareName"

$existingShare = Get-SmbShare -Name $ShareName -ErrorAction SilentlyContinue

if ($existingShare) {
    Write-Warn "SMB-Share '$ShareName' existiert bereits: $($existingShare.Path)"
}
else {
    if ($PSCmdlet.ShouldProcess($ShareName, 'SMB-Share erstellen')) {
        New-SmbShare `
            -Name        $ShareName `
            -Path        $SharePath `
            -Description 'FSLogix Profile + Office Container (AVD)' `
            -FullAccess  'Everyone' `
            -FolderEnumerationMode 'AccessBased' `
            -CachingMode 'None' `
            -EncryptData $true | Out-Null

        Write-OK "SMB-Share erstellt: \\$env:COMPUTERNAME\$ShareName"
        Write-Info "Share-Berechtigungen: Everyone = Full Control"
        Write-Info "Zugriffskontrolle erfolgt ausschliesslich ueber NTFS-Berechtigungen"
        Write-Info "AccessBased Enumeration: aktiviert (Nutzer sehen nur eigene Ordner)"
        Write-Info "Verschluesselung: aktiviert (EncryptData)"
        Write-Info "Caching: deaktiviert (empfohlen fuer FSLogix)"
    }
}

# ---------------------------------------------------------------------------
# REGION: Firewall-Regeln pruefen
# ---------------------------------------------------------------------------

Write-Step 'Pruefe Windows Firewall (SMB Port 445)...'

$fwRule = Get-NetFirewallRule -DisplayGroup 'File and Printer Sharing' `
    -ErrorAction SilentlyContinue |
    Where-Object { $_.Enabled -eq 'True' -and $_.Direction -eq 'Inbound' }

if ($fwRule) {
    Write-OK "Firewall: 'File and Printer Sharing' Regeln aktiv ($($fwRule.Count) Regeln)"
}
else {
    Write-Warn "Firewall-Regeln fuer 'File and Printer Sharing' nicht aktiv"
    if ($PSCmdlet.ShouldProcess('File and Printer Sharing', 'Firewall-Regeln aktivieren')) {
        Enable-NetFirewallRule -DisplayGroup 'File and Printer Sharing'
        Write-OK "Firewall-Regeln aktiviert"
    }
}

# ---------------------------------------------------------------------------
# REGION: Share-Verbindungstest
# ---------------------------------------------------------------------------

Write-Step 'Teste Share-Verbindung...'

if (-not $WhatIfPreference) {
    $testPath = "\\$env:COMPUTERNAME\$ShareName"
    if (Test-Path $testPath) {
        Write-OK "Share erreichbar: $testPath"
    }
    else {
        Write-Warn "Share nicht erreichbar: $testPath"
        Write-Warn "Bitte Firewall und Share-Konfiguration pruefen"
    }
}
else {
    Write-Info "WhatIf: Share-Test uebersprungen"
}

# ---------------------------------------------------------------------------
# REGION: Zusammenfassung
# ---------------------------------------------------------------------------

Write-Host ''
Write-Host '======================================================' -ForegroundColor White
Write-Host '   FSLogix Vorbereitung abgeschlossen                 ' -ForegroundColor White
Write-Host '======================================================' -ForegroundColor White
Write-Host ''
Write-Host '  Share-Informationen:' -ForegroundColor White
Write-Host "    UNC-Pfad     : \\$ServerFQDN\$ShareName" -ForegroundColor Gray
Write-Host "    Lokal        : $SharePath" -ForegroundColor Gray
Write-Host "    Verwendung   : FSLogix Profile Container + Office Container (ODFC)" -ForegroundColor Gray
Write-Host ''
Write-Host '  Naechste Schritte:' -ForegroundColor White
Write-Host "  1. Skript 2-Set-AVD-GPOSettings.ps1 ausfuehren:" -ForegroundColor White
Write-Host "       -FSLogixProfileShare '\\$ServerFQDN\$ShareName'" -ForegroundColor Gray
Write-Host "       -FSLogixODFCShare    '\\$ServerFQDN\$ShareName'" -ForegroundColor Gray
Write-Host ''
Write-Host '  2. Verbindung von einem Session Host testen:' -ForegroundColor White
Write-Host "       Test-NetConnection -ComputerName $ServerFQDN -Port 445" -ForegroundColor Gray
Write-Host "       Test-Path '\\$ServerFQDN\$ShareName'" -ForegroundColor Gray
Write-Host ''
Write-Host '  3. FSLogix Defender-Ausnahmen (per GPO in Skript 2 gesetzt):' -ForegroundColor White
Write-Host "       *.VHD, *.VHDX, *.VHD.lock, *.VHD.meta" -ForegroundColor Gray
Write-Host "       \\$ServerFQDN\$ShareName" -ForegroundColor Gray
Write-Host ''
Write-Host '  4. Optional - DFS-Namespace fuer Hochverfuegbarkeit:' -ForegroundColor White
Write-Host "       Empfohlen: \\$DomainFQDN\FSLogix als DFS-Namespace" -ForegroundColor Gray
Write-Host "       Dann in Skript 2: -FSLogixProfileShare '\\$DomainFQDN\FSLogix'" -ForegroundColor Gray
Write-Host ''
