#Requires -Modules ActiveDirectory, GroupPolicy
#Requires -RunAsAdministrator

<#
.SYNOPSIS
    Bereitet Active Directory fuer Azure Virtual Desktop (AVD) auf Azure Local vor.

.DESCRIPTION
    Das Skript legt die empfohlene OU-Struktur, Service Accounts, Sicherheitsgruppen
    sowie GPO-Grundgerueste fuer AVD an. Der Domain-Name wird automatisch aus dem
    lokalen System ausgelesen.

.NOTES
    Voraussetzungen:
      - RSAT: Active Directory & Group Policy Management installiert
      - Ausfuehrung als Domain Admin (oder delegierter Account mit OU-Erstellungsrechten)
      - PowerShell 5.1+

.EXAMPLE
    .\1-New-AVD-ADPrep.ps1
    .\1-New-AVD-ADPrep.ps1 -WhatIf
    .\1-New-AVD-ADPrep.ps1 -CreateTestUsers
    .\1-New-AVD-ADPrep.ps1 -CreateTestUsers -WhatIf
#>

[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter()]
    [switch]$CreateTestUsers
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------------------------------------------------------------------
# REGION: Hilfsfunktionen
# ---------------------------------------------------------------------------

function Write-Step {
    param([string]$Message)
    Write-Host "`n  >> $Message" -ForegroundColor Cyan
}

function Write-OK {
    param([string]$Message)
    Write-Host "    OK  $Message" -ForegroundColor Green
}

function Write-Skip {
    param([string]$Message)
    Write-Host "    --  $Message (bereits vorhanden, uebersprungen)" -ForegroundColor Yellow
}

function Write-Fail {
    param([string]$Message)
    Write-Host "    !!  $Message" -ForegroundColor Red
}

function New-OUSafe {
    param(
        [string]$Name,
        [string]$Path,
        [string]$Description = ''
    )
    $dn = "OU=$Name,$Path"
    try {
        Get-ADOrganizationalUnit -Identity $dn -ErrorAction Stop | Out-Null
        Write-Skip "OU: $dn"
    }
    catch {
        if ($PSCmdlet.ShouldProcess($dn, 'Neue OU erstellen')) {
            New-ADOrganizationalUnit `
                -Name $Name `
                -Path $Path `
                -Description $Description `
                -ProtectedFromAccidentalDeletion $true
            Write-OK "OU erstellt: $dn"
        }
    }
}

function New-ServiceAccountSafe {
    param(
        [string]$SamAccountName,
        [string]$DisplayName,
        [string]$Description,
        [string]$Path,
        [System.Security.SecureString]$Password
    )
    try {
        Get-ADUser -Identity $SamAccountName -ErrorAction Stop | Out-Null
        Write-Skip "Service Account: $SamAccountName"
    }
    catch {
        if ($PSCmdlet.ShouldProcess($SamAccountName, 'Service Account erstellen')) {
            New-ADUser `
                -SamAccountName       $SamAccountName `
                -Name                 $DisplayName `
                -DisplayName          $DisplayName `
                -Description          $Description `
                -Path                 $Path `
                -AccountPassword      $Password `
                -PasswordNeverExpires  $true `
                -CannotChangePassword  $true `
                -Enabled              $true
            Write-OK "Service Account erstellt: $SamAccountName"
        }
    }
}

function New-ADGroupSafe {
    param(
        [string]$Name,
        [string]$Path,
        [string]$Description    = '',
        [string]$GroupScope     = 'Global',
        [string]$GroupCategory  = 'Security'
    )
    try {
        Get-ADGroup -Identity $Name -ErrorAction Stop | Out-Null
        Write-Skip "Gruppe: $Name"
    }
    catch {
        if ($PSCmdlet.ShouldProcess($Name, 'AD-Gruppe erstellen')) {
            New-ADGroup `
                -Name           $Name `
                -SamAccountName $Name `
                -GroupScope     $GroupScope `
                -GroupCategory  $GroupCategory `
                -Path           $Path `
                -Description    $Description
            Write-OK "Gruppe erstellt: $Name"
        }
    }
}

function New-GPOSafe {
    param(
        [string]$GpoName,
        [string]$TargetOU,
        [string]$Comment = ''
    )
    $existing = Get-GPO -Name $GpoName -ErrorAction SilentlyContinue
    if ($null -eq $existing) {
        if ($PSCmdlet.ShouldProcess($GpoName, 'GPO erstellen')) {
            $gpo = New-GPO -Name $GpoName -Comment $Comment
            Write-OK "GPO erstellt: $GpoName"
        }
        else {
            # -WhatIf aktiv: OU und GPO wurden nicht erstellt, Link-Pruefung ueberspringen
            Write-Host "    WhatIf: GPO-Link '$GpoName' -> '$TargetOU' wuerde gesetzt werden" -ForegroundColor DarkGray
            return
        }
    }
    else {
        Write-Skip "GPO: $GpoName"
        $gpo = $existing
    }

    # Ziel-OU auf Existenz pruefen bevor Get-GPInheritance aufgerufen wird
    try {
        $ouExists = Get-ADOrganizationalUnit -Identity $TargetOU -ErrorAction Stop
    }
    catch {
        Write-Host "    WhatIf/Skip: Ziel-OU '$TargetOU' existiert noch nicht - Link wird nach OU-Erstellung gesetzt" -ForegroundColor DarkGray
        return
    }

    $links = (Get-GPInheritance -Target $TargetOU).GpoLinks |
             Where-Object { $_.DisplayName -eq $GpoName }
    if ($null -eq $links) {
        if ($PSCmdlet.ShouldProcess("$GpoName -> $TargetOU", 'GPO verknuepfen')) {
            New-GPLink -Name $GpoName -Target $TargetOU -LinkEnabled Yes | Out-Null
            Write-OK "GPO verknuepft: $GpoName -> $TargetOU"
        }
    }
    else {
        Write-Skip "GPO-Link bereits vorhanden: $GpoName -> $TargetOU"
    }
}

# ---------------------------------------------------------------------------
# REGION: Domain-Info automatisch ermitteln
# ---------------------------------------------------------------------------

Write-Host ''
Write-Host '======================================================' -ForegroundColor White
Write-Host '   AVD Active Directory Preparation Script            ' -ForegroundColor White
Write-Host '======================================================' -ForegroundColor White
Write-Host ''

Write-Step 'Ermittle Domain-Informationen...'

$Domain        = Get-ADDomain
$DomainDN      = $Domain.DistinguishedName
$DomainFQDN    = $Domain.DNSRoot
$DomainNetBIOS = $Domain.NetBIOSName
$PDC           = $Domain.PDCEmulator

Write-OK "Domain:    $DomainFQDN"
Write-OK "DN:        $DomainDN"
Write-OK "NetBIOS:   $DomainNetBIOS"
Write-OK "PDC:       $PDC"

# ---------------------------------------------------------------------------
# REGION: Passwort-Abfragen (alle auf einmal vor den AD-Operationen)
# ---------------------------------------------------------------------------

Write-Step 'Passwort-Abfragen...'

if ($WhatIfPreference) {
    $svcPassDomainJoin = ConvertTo-SecureString 'WhatIf-Placeholder' -AsPlainText -Force
    $svcPassFSLogix    = ConvertTo-SecureString 'WhatIf-Placeholder' -AsPlainText -Force
    $testPass          = ConvertTo-SecureString 'WhatIf-Placeholder' -AsPlainText -Force
    Write-Host '    WhatIf: Passwortabfragen uebersprungen' -ForegroundColor DarkGray
}
else {
    $svcPassDomainJoin = Read-Host '  Passwort fuer svc-avd-domainjoin' -AsSecureString
    $svcPassFSLogix    = Read-Host '  Passwort fuer svc-avd-fslogix' -AsSecureString

    if ($CreateTestUsers) {
        $testPass = Read-Host '  Initiales Passwort fuer Test-User (Picard, Kirk, Janeway)' -AsSecureString
    }

    Write-OK 'Passwoerter eingelesen - Skript laeuft jetzt ohne weitere Unterbrechungen durch'
}

# ---------------------------------------------------------------------------
# REGION: OU-Struktur
# ---------------------------------------------------------------------------

Write-Step 'Erstelle OU-Struktur...'

New-OUSafe -Name 'AVD' -Path $DomainDN `
    -Description 'Azure Virtual Desktop - alle Objekte'

$ouAVD = "OU=AVD,$DomainDN"

New-OUSafe -Name 'Session Hosts' -Path $ouAVD `
    -Description 'AVD Session Host VMs (Arc-joined)'

$ouSessionHosts = "OU=Session Hosts,$ouAVD"

New-OUSafe -Name 'Pooled' -Path $ouSessionHosts `
    -Description 'Pooled Host Pool Session Hosts'

New-OUSafe -Name 'Personal' -Path $ouSessionHosts `
    -Description 'Personal Host Pool Session Hosts'

New-OUSafe -Name 'Service Accounts' -Path $ouAVD `
    -Description 'AVD-Dienstkonten'

New-OUSafe -Name 'AVD Groups' -Path $ouAVD `
    -Description 'AVD Sicherheitsgruppen fuer Nutzer-Zuweisung'

New-OUSafe -Name 'FSLogix' -Path $ouAVD `
    -Description 'FSLogix-bezogene Objekte (optional)'

# ---------------------------------------------------------------------------
# REGION: Service Accounts
# ---------------------------------------------------------------------------

Write-Step 'Erstelle Service Accounts...'

$ouServiceAccounts = "OU=Service Accounts,$ouAVD"

New-ServiceAccountSafe `
    -SamAccountName 'svc-avd-domainjoin' `
    -DisplayName    'AVD Domain Join Service Account' `
    -Description    'Minimale Rechte: Computer-Objekte in OU=Session Hosts erstellen/loeschen' `
    -Path           $ouServiceAccounts `
    -Password       $svcPassDomainJoin

New-ServiceAccountSafe `
    -SamAccountName 'svc-avd-fslogix' `
    -DisplayName    'AVD FSLogix Service Account' `
    -Description    'Lese-/Schreibzugriff auf FSLogix-Profilshare' `
    -Path           $ouServiceAccounts `
    -Password       $svcPassFSLogix

# ---------------------------------------------------------------------------
# REGION: AD-Gruppen
# ---------------------------------------------------------------------------

Write-Step 'Erstelle AD-Sicherheitsgruppen...'

$ouAVDGroups = "OU=AVD Groups,$ouAVD"

New-ADGroupSafe `
    -Name        'GRP-AVD-Pooled-Users' `
    -Path        $ouAVDGroups `
    -Description 'Nutzer mit Zugriff auf Pooled Desktop App Group'

New-ADGroupSafe `
    -Name        'GRP-AVD-Personal-Users' `
    -Path        $ouAVDGroups `
    -Description 'Nutzer mit Zugriff auf Personal Desktop App Group'

New-ADGroupSafe `
    -Name        'GRP-AVD-Admins' `
    -Path        $ouAVDGroups `
    -Description 'AVD-Administratoren (Session Host Management)'

# ---------------------------------------------------------------------------
# REGION: Test-User (optional, -CreateTestUsers)
# ---------------------------------------------------------------------------

if ($CreateTestUsers) {
    Write-Step 'Erstelle Test-User OU und Test-User...'

    # Eigene OU fuer Test-User unterhalb von OU=AVD
    New-OUSafe -Name 'AVD Test Users' -Path $ouAVD `
        -Description 'AVD Test-User (Captains auf Abruf)'

    $ouTestUsers = "OU=AVD Test Users,$ouAVD"

    $testUsers = @(
        @{
            SamAccountName = 'jlpicard'
            GivenName      = 'Jean-Luc'
            Surname        = 'Picard'
            DisplayName    = 'Jean-Luc Picard'
            Description    = 'AVD Test-User - Pooled Desktop'
            Group          = 'GRP-AVD-Pooled-Users'
        },
        @{
            SamAccountName = 'jkirk'
            GivenName      = 'Jim'
            Surname        = 'Kirk'
            DisplayName    = 'Jim Kirk'
            Description    = 'AVD Test-User - Pooled Desktop'
            Group          = 'GRP-AVD-Pooled-Users'
        },
        @{
            SamAccountName = 'kjaneway'
            GivenName      = 'Kathryn'
            Surname        = 'Janeway'
            DisplayName    = 'Kathryn Janeway'
            Description    = 'AVD Test-User - Personal Desktop'
            Group          = 'GRP-AVD-Personal-Users'
        }
    )

    foreach ($u in $testUsers) {
        $upn = "$($u.SamAccountName)@$DomainFQDN"
        try {
            Get-ADUser -Identity $u.SamAccountName -ErrorAction Stop | Out-Null
            Write-Skip "Test-User: $($u.DisplayName) ($($u.SamAccountName))"
        }
        catch {
            if ($PSCmdlet.ShouldProcess($u.DisplayName, 'Test-User erstellen')) {
                New-ADUser `
                    -SamAccountName       $u.SamAccountName `
                    -GivenName            $u.GivenName `
                    -Surname              $u.Surname `
                    -Name                 $u.DisplayName `
                    -DisplayName          $u.DisplayName `
                    -UserPrincipalName    $upn `
                    -Description          $u.Description `
                    -Path                 $ouTestUsers `
                    -AccountPassword      $testPass `
                    -PasswordNeverExpires  $true `
                    -ChangePasswordAtLogon $false `
                    -Enabled              $true
                Write-OK "Test-User erstellt: $($u.DisplayName) ($upn)"
            }
        }

        # Gruppe zuweisen
        try {
            $grpMembers = Get-ADGroupMember -Identity $u.Group -ErrorAction Stop |
                          Where-Object { $_.SamAccountName -eq $u.SamAccountName }
            if ($grpMembers) {
                Write-Skip "$($u.SamAccountName) bereits in $($u.Group)"
            }
            else {
                if ($PSCmdlet.ShouldProcess($u.SamAccountName, "Zu $($u.Group) hinzufuegen")) {
                    Add-ADGroupMember -Identity $u.Group -Members $u.SamAccountName
                    Write-OK "$($u.SamAccountName) -> $($u.Group)"
                }
            }
        }
        catch {
            Write-Host "    Skip: Gruppe $($u.Group) noch nicht vorhanden (WhatIf?)" -ForegroundColor DarkGray
        }
    }

    Write-Host ''
    Write-Host '  Test-User Uebersicht:' -ForegroundColor White
    Write-Host '  +-----------------+------------------+---------------------------+' -ForegroundColor Gray
    Write-Host '  | SamAccountName  | UPN                          | Gruppe                  |' -ForegroundColor Gray
    Write-Host '  +-----------------+------------------------------+-------------------------+' -ForegroundColor Gray
    foreach ($u in $testUsers) {
        $upn = "$($u.SamAccountName)@$DomainFQDN"
        Write-Host "  | $($u.SamAccountName.PadRight(15)) | $($upn.PadRight(28)) | $($u.Group) |" -ForegroundColor Gray
    }
    Write-Host '  +-----------------+------------------------------+-------------------------+' -ForegroundColor Gray
    Write-Host ''
}



Write-Step 'Erstelle und verknuepfe GPOs...'

New-GPOSafe `
    -GpoName  'AVD-SessionHost-Base' `
    -TargetOU $ouSessionHosts `
    -Comment  'Basis-Richtlinien fuer alle AVD Session Host VMs (NLA, Timeouts, Firewall)'

New-GPOSafe `
    -GpoName  'AVD-FSLogix-Config' `
    -TargetOU $ouSessionHosts `
    -Comment  'FSLogix Profile Container Einstellungen (VHD-Pfad, Groesse, ODFC)'

New-GPOSafe `
    -GpoName  'AVD-Security-Hardening' `
    -TargetOU $ouSessionHosts `
    -Comment  'Credential Guard, USB-Sperre, Defender-Ausnahmen, SMB-Signing'

New-GPOSafe `
    -GpoName  'AVD-UserExperience' `
    -TargetOU $ouAVDGroups `
    -Comment  'Laufwerke, Drucker, Wallpaper, OneDrive KFM fuer AVD-Nutzer'

New-GPOSafe `
    -GpoName  'AVD-Loopback-UserSettings' `
    -TargetOU $ouSessionHosts `
    -Comment  'Loopback Replace - erzwingt User-GPOs der Session-Host-OU auf eingeloggte Nutzer'

$loopbackGpo = Get-GPO -Name 'AVD-Loopback-UserSettings' -ErrorAction SilentlyContinue
if ($null -ne $loopbackGpo) {
    if ($PSCmdlet.ShouldProcess('AVD-Loopback-UserSettings', 'Loopback Processing = Replace setzen')) {
        Set-GPRegistryValue `
            -Name      'AVD-Loopback-UserSettings' `
            -Key       'HKLM\SOFTWARE\Policies\Microsoft\Windows\System' `
            -ValueName 'UserPolicyMode' `
            -Type      DWord `
            -Value     1
        Write-OK "Loopback Processing auf 'Replace' gesetzt"
    }
}
else {
    Write-Host '    WhatIf/Skip: GPO AVD-Loopback-UserSettings noch nicht vorhanden - Registry-Wert wird nach GPO-Erstellung gesetzt' -ForegroundColor DarkGray
}

# ---------------------------------------------------------------------------
# REGION: Domain-Join-Delegation
# ---------------------------------------------------------------------------

Write-Step 'Delegiere Domain-Join-Rechte fuer svc-avd-domainjoin...'

try {
    $djUser = Get-ADUser -Identity 'svc-avd-domainjoin' -ErrorAction Stop
}
catch {
    $djUser = $null
}

if ($null -ne $djUser) {
    $ouPooled   = "OU=Pooled,$ouSessionHosts"
    $ouPersonal = "OU=Personal,$ouSessionHosts"
    $djAccount  = "$DomainNetBIOS\svc-avd-domainjoin"

    foreach ($targetOU in @($ouPooled, $ouPersonal)) {
        # Ziel-OU auf Existenz pruefen (kann bei -WhatIf noch fehlen)
        try {
            Get-ADOrganizationalUnit -Identity $targetOU -ErrorAction Stop | Out-Null
        }
        catch {
            Write-Host "    WhatIf/Skip: Ziel-OU '$targetOU' existiert noch nicht - Delegation wird nach OU-Erstellung gesetzt" -ForegroundColor DarkGray
            continue
        }
        if ($PSCmdlet.ShouldProcess($targetOU, "Domain-Join-Delegation fuer $djAccount")) {
            & dsacls.exe $targetOU /I:T /G "${djAccount}:CCDC;Computer" 2>&1 | Out-Null
            & dsacls.exe $targetOU /I:S /G "${djAccount}:RPWP;;Computer" 2>&1 | Out-Null
            Write-OK "Delegation gesetzt: $djAccount -> $targetOU"
        }
    }
}
else {
    Write-Host '    WhatIf/Skip: svc-avd-domainjoin noch nicht vorhanden - Delegation wird nach Account-Erstellung gesetzt' -ForegroundColor DarkGray
}

# ---------------------------------------------------------------------------
# REGION: Zusammenfassung
# ---------------------------------------------------------------------------

Write-Host ''
Write-Host '======================================================' -ForegroundColor White
Write-Host '   Abgeschlossen - naechste manuelle Schritte         ' -ForegroundColor White
Write-Host '======================================================' -ForegroundColor White
Write-Host ''
Write-Host '  1. GPO-Einstellungen befuellen (Set-AVD-GPOSettings.ps1):' -ForegroundColor White
Write-Host '       - AVD-SessionHost-Base     : NLA, Sitzungslimits, Firewall' -ForegroundColor Gray
Write-Host '       - AVD-FSLogix-Config       : VHDLocations auf Fileserver zeigen' -ForegroundColor Gray
Write-Host '       - AVD-Security-Hardening   : Defender-Ausnahmen fuer FSLogix' -ForegroundColor Gray
Write-Host '       - AVD-UserExperience       : Laufwerke, Drucker, OneDrive KFM' -ForegroundColor Gray
Write-Host ''
Write-Host '  2. Passwort svc-avd-domainjoin sicher hinterlegen:' -ForegroundColor White
Write-Host '       - Azure Key Vault (empfohlen fuer Arc-Deployment)' -ForegroundColor Gray
Write-Host '       - Alternativ: Azure Local Deployment Parameter' -ForegroundColor Gray
Write-Host ''
Write-Host '  3. Passwort svc-avd-fslogix in Share-Berechtigungen eintragen:' -ForegroundColor White
Write-Host '       - NTFS: Modify auf \\<server>\profiles$\' -ForegroundColor Gray
Write-Host '       - Share: Full Control (NTFS regelt den Zugriff)' -ForegroundColor Gray
Write-Host ''
Write-Host '  4. Entra ID Connect pruefen:' -ForegroundColor White
Write-Host '       - svc-* Konten NICHT nach Entra ID synchronisieren' -ForegroundColor Gray
Write-Host '       - GRP-AVD-* Gruppen synchronisieren' -ForegroundColor Gray
Write-Host ''
Write-Host "  Domain:  $DomainFQDN" -ForegroundColor White
Write-Host "  AVD-OU:  $ouAVD" -ForegroundColor White
Write-Host ''