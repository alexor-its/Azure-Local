#Requires -Version 5.1
<#
.SYNOPSIS
    SCHRITT 3 von 3 - Erstellt einen E-Mail-Alert, wenn auf einem Azure Arc-enabled Server der
    freie Speicher eines Laufwerks (Standard: C:) unter einen Schwellwert
    (Standard: 15 %) sinkt.
.DESCRIPTION
    Reihenfolge der Scripts:
      1. Test-ArcMonitoringPrereq.ps1  - Voraussetzungen pruefen
      2. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      3. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten (dieses Script)

    Fuer Arc-Server (Microsoft.HybridCompute/machines) existieren keine
    Gast-Metriken im Metrics Explorer. Ein klassischer Metric-Alert auf
    "Disk Free Space" ist deshalb nicht moeglich. Dieses Script legt statt-
    dessen einen Log Search Alert (Scheduled Query Rule v2) auf dem Log
    Analytics Workspace an:

      * Scope        = Log Analytics Workspace
      * TargetType   = Microsoft.HybridCompute/machines
      * resourceIdColumn = _ResourceId  -> betroffene Ressource ist der Server
      * Dimensions   = Computer + Disk  -> ein Alert je Server/Laufwerk

    Hinweis zu Azure-Regeln: 'autoMitigate' und 'muteActionsDuration' duerfen
    nicht gleichzeitig gesetzt sein. Mit Auto-Resolve ist der Alert stateful
    und feuert nicht erneut, solange er offen ist - eine Unterdrueckungsdauer
    waere ohnehin wirkungslos.

    Eine Managed Identity ist NICHT erforderlich (nur ARG-Queries brauchen
    eine MI). Die Regel wird per 'az rest' (PUT) erstellt, weil die
    Condition-Mini-Sprache von 'az monitor scheduled-query create' beim
    Quoting in PowerShell fehleranfaellig ist und keine sauberen Dimensions
    zulaesst.

    Ablauf:
      1. Pre-Check (Azure CLI, Version, Login)
      2. Konfiguration bestaetigen
      3. Log Analytics Workspace pruefen (ID + CustomerId)
      4. Optional: Datenverfuegbarkeit der Query pruefen (Dry-Run)
      5. Action Group (E-Mail) anlegen / wiederverwenden
      6. Scheduled Query Rule per 'az rest' anlegen
      7. Zusammenfassung

    Datenquelle waehlbar:
      InsightsMetrics -> VM Insights / Monitor-Blade (Namespace LogicalDisk,
                         Name FreeSpacePercentage)
      Perf            -> eigene DCR mit Counter '\LogicalDisk(*)\% Free Space'
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 17.08.2026
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\New-ArcDiskSpaceAlert.ps1
#>

# =========================================================================
# [ KONFIGURATION ]
# =========================================================================
$SubscriptionId        = ""                                  # leer = aktuelle Subscription

# --- Log Analytics Workspace (Datenquelle) ---
$WorkspaceResourceGroup = "arcmanagement-rg"
$WorkspaceName          = "server-external-law"

# --- Ablageort der Alert-Objekte ---
$AlertResourceGroup    = "arcmanagement-rg"
$Location              = "westeurope"                        # muss NICHT = LAW-Region sein

# --- Action Group (E-Mail) ---
$ActionGroupName       = "ag-arc-diskspace"
$ActionGroupShortName  = "ArcDisk"                           # max. 12 Zeichen
$EmailName             = "ITAlert"
$EmailAddress          = "statusmails@ortha-itsolutions.de"

# --- Alert-Regel ---
$RuleName              = "alert-arc-disk-c-below-15pct"
$RuleDisplayName       = "Arc: Laufwerk C: unter 15 % frei"
$Severity              = 2                                   # 0=schwerwiegend ... 4=info
$ThresholdPercent      = 15                                  # Schwellwert freier Speicher in %
$DriveLetter           = "C:"                                # z. B. 'C:' | 'D:'  (Linux: '/')
$EvaluationFrequency   = "PT15M"                             # Auswertungsintervall
$WindowSize            = "PT15M"                             # Zeitfenster je Auswertung
$NumberOfEvalPeriods   = 2                                   # Anzahl betrachteter Perioden
$MinFailingPeriods     = 2                                   # davon muessen X verletzt sein
# ACHTUNG: $AutoMitigate und $MuteActionsDuration schliessen sich in Azure
# gegenseitig aus ("Auto mitigation must be disabled when action suppression
# is set"). Nur EINES von beiden setzen:
#   $AutoMitigate = $true   -> Alert loest sich selbst auf, sendet Entwarnung.
#                              Feuert nicht erneut, solange er offen ist.
#                              Eine Unterdrueckungsdauer waere wirkungslos.
#   $AutoMitigate = $false  -> Alert bleibt offen; dann kann
#                              $MuteActionsDuration wiederholte Mails bremsen.
# Empfehlung fuer Disk-Alerts: AutoMitigate, weil die Entwarnung nuetzlich ist.
$AutoMitigate          = $true                               # Auto-Resolve
$MuteActionsDuration   = ""                                  # nur bei AutoMitigate = $false

# --- Datenquelle: 'InsightsMetrics' oder 'Perf' ---
$DataSource            = "InsightsMetrics"

# --- Filter ---
$ArcOnly               = $true                               # nur Microsoft.HybridCompute
# Einschraenkung auf bestimmte Maschinen (leer = alle im Workspace):
$ComputerFilter        = @()                                 # z. B. @("HCLArcDemoSRV01")

# --- Optionen ---
$RunDataCheck          = $true                               # Query vorab testen (Dry-Run)
$ApiVersion            = "2021-08-01"                        # scheduledQueryRules (GA)

# =========================================================================
# [ AUSGABE-HELFER ]
# =========================================================================
$ErrorActionPreference = "Stop"

function Write-Trenner   { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Abschnitt { param($T) Write-Host ""; Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok        { param($T) Write-Host "OK   $T" -ForegroundColor Green }
function Write-Fehler    { param($T) Write-Host "FEHL $T" -ForegroundColor Red }
function Write-Warnung   { param($T) Write-Host "WARN $T" -ForegroundColor Yellow }
function Write-Info      { param($T) Write-Host "INFO $T" -ForegroundColor Cyan }
function Write-Prozess   { param($T) Write-Host "LAEUFT $T" -ForegroundColor Cyan }
function Write-Sub       { param($T) Write-Host ("    " + $T) -ForegroundColor Gray }
function Write-Log       { param($T) Write-Host ("[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $T) -ForegroundColor Cyan }

# Symbole (werden vor den Status gesetzt, damit auch aeltere Konsolen lesbar bleiben)
# Hinweis: Zeichen ausserhalb der BMP (z. B. U+1F504) benoetigen ein Surrogate
# Pair und lassen sich NICHT per [char]0x1F504 erzeugen -> ConvertFromUtf32.
function New-Symbol { param([int]$CodePoint) [System.Char]::ConvertFromUtf32($CodePoint) }
$SymOk   = New-Symbol 0x2705      # Haken
$SymErr  = New-Symbol 0x274C      # Kreuz
$SymWarn = (New-Symbol 0x26A0) + (New-Symbol 0xFE0F)   # Warnzeichen (Emoji-Variante)
$SymInf  = (New-Symbol 0x2139) + (New-Symbol 0xFE0F)   # Info (Emoji-Variante)
$SymRun  = New-Symbol 0x1F504     # Prozess laeuft

# =========================================================================
# [ PRE-CHECK ]
# =========================================================================
Write-Trenner
Write-Abschnitt "PRE-CHECK"

Write-Info "$SymInf Pruefe Azure CLI..."
try {
    $azVersionJson = az version --output json 2>$null | ConvertFrom-Json
    $azVersion     = $azVersionJson.'azure-cli'
    Write-Ok "$SymOk Azure CLI gefunden: $azVersion"
} catch {
    Write-Fehler "$SymErr Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecli"
    Write-Trenner
    exit 1
}

# Versionshinweis (rein informativ, kein Abbruch)
$MinVersion = [version]"2.60.0"
try {
    if ([version]$azVersion -lt $MinVersion) {
        Write-Warnung "$SymWarn Aeltere CLI-Version. Empfohlen: >= $MinVersion  (az upgrade)"
    } else {
        Write-Ok "$SymOk CLI-Version ausreichend aktuell"
    }
} catch {
    Write-Warnung "$SymWarn Versionsvergleich nicht moeglich."
}

Write-Info "$SymInf Pruefe Azure Login..."
$account = $null
try { $account = az account show --output json 2>$null | ConvertFrom-Json } catch { $account = $null }
if (-not $account) {
    Write-Warnung "$SymWarn Kein Login vorhanden - starte 'az login'..."
    az login --only-show-errors | Out-Null
    $account = az account show --output json | ConvertFrom-Json
}
Write-Ok "$SymOk Login vorhanden: $($account.user.name)"

if ($SubscriptionId) {
    Write-Prozess "$SymRun Wechsle Subscription..."
    az account set --subscription $SubscriptionId | Out-Null
    $account = az account show --output json | ConvertFrom-Json
}
Write-Ok "$SymOk Subscription: $($account.name)"
Write-Sub "Id: $($account.id)"
Write-Trenner

# =========================================================================
# [ KONFIGURATION PRUEFEN ]
# =========================================================================
Write-Abschnitt "KONFIGURATION PRUEFEN"
Write-Info "$SymInf Folgende Objekte werden angelegt / verwendet:"
Write-Sub "Subscription       : $($account.name)"
Write-Sub "Workspace          : $WorkspaceName  (RG: $WorkspaceResourceGroup)"
Write-Sub "Alert-RG / Region  : $AlertResourceGroup / $Location"
Write-Sub "Action Group       : $ActionGroupName  ->  $EmailAddress"
Write-Sub "Alert-Regel        : $RuleName"
Write-Sub "Bedingung          : $DriveLetter freier Speicher < $ThresholdPercent %"
Write-Sub "Datenquelle        : $DataSource"
Write-Sub "Auswertung         : alle $EvaluationFrequency / Fenster $WindowSize"
Write-Sub "Verletzungen       : $MinFailingPeriods von $NumberOfEvalPeriods Perioden"
if ($AutoMitigate) {
    Write-Sub "Auto-Resolve       : aktiv (Entwarnung wird gesendet)"
} else {
    Write-Sub "Auto-Resolve       : aus  /  Unterdrueckung: $(if ($MuteActionsDuration) { $MuteActionsDuration } else { 'keine' })"
}
if ($ComputerFilter.Count -gt 0) {
    Write-Sub "Maschinen-Filter   : $($ComputerFilter -join ', ')"
} else {
    Write-Sub "Maschinen-Filter   : ALLE Maschinen im Workspace"
}
Write-Host ""
Write-Warnung "$SymWarn Es wird eine kostenpflichtige Alert-Regel erstellt."
$answer = Read-Host "Konfiguration korrekt? [J] Ja  /  [N] Abbrechen"
if ($answer -notmatch '^(j|ja|y|yes)$') {
    Write-Warnung "$SymWarn Abbruch durch Benutzer."
    Write-Trenner
    exit 0
}
Write-Ok "$SymOk Bestaetigt - fahre fort."
Write-Trenner

# =========================================================================
# [ LOG ANALYTICS WORKSPACE ]
# =========================================================================
Write-Abschnitt "LOG ANALYTICS WORKSPACE"
Write-Prozess "$SymRun Lese Workspace-Informationen..."
$law = $null
try {
    $law = az monitor log-analytics workspace show `
        --resource-group $WorkspaceResourceGroup `
        --workspace-name $WorkspaceName `
        --output json 2>$null | ConvertFrom-Json
} catch { $law = $null }

if (-not $law) {
    Write-Fehler "$SymErr Workspace '$WorkspaceName' in RG '$WorkspaceResourceGroup' nicht gefunden."
    Write-Sub "Vorhandene Workspaces auflisten:"
    Write-Sub "az monitor log-analytics workspace list --query ""[].{Name:name,RG:resourceGroup,Region:location}"" -o table"
    Write-Trenner
    exit 1
}
$WorkspaceId         = $law.id
$WorkspaceCustomerId = $law.customerId
Write-Ok "$SymOk Workspace gefunden: $WorkspaceName"
Write-Sub "Region     : $($law.location)"
Write-Sub "CustomerId : $WorkspaceCustomerId"
Write-Trenner

# =========================================================================
# [ KQL-QUERY AUFBAUEN ]
# =========================================================================
Write-Abschnitt "KQL-QUERY"

$arcFilterLine = ""
if ($ArcOnly) { $arcFilterLine = '| where _ResourceId has "/microsoft.hybridcompute/"' }

if ($DataSource -eq "InsightsMetrics") {
    $queryTemplate = @'
InsightsMetrics
| where Origin == "vm.azm.ms"
| where Namespace == "LogicalDisk" and Name == "FreeSpacePercentage"
| extend Disk = tostring(todynamic(Tags)["vm.azm.ms/mountId"])
| where Disk == "__DRIVE__"
__ARCFILTER__
| summarize FreeSpacePercentage = avg(Val) by bin(TimeGenerated, 5m), Computer, Disk, _ResourceId
'@
} elseif ($DataSource -eq "Perf") {
    $queryTemplate = @'
Perf
| where ObjectName == "LogicalDisk" and CounterName == "% Free Space"
| where InstanceName == "__DRIVE__"
__ARCFILTER__
| summarize FreeSpacePercentage = avg(CounterValue) by bin(TimeGenerated, 5m), Computer, Disk = InstanceName, _ResourceId
'@
} else {
    Write-Fehler "$SymErr Unbekannte Datenquelle '$DataSource'. Erlaubt: InsightsMetrics | Perf"
    Write-Trenner
    exit 1
}

$Query = $queryTemplate.Replace("__DRIVE__", $DriveLetter).Replace("__ARCFILTER__", $arcFilterLine)
# Query fuer die REGEL darf mehrzeilig bleiben (geht als JSON-Body, nicht als
# CLI-Argument). Fuer den Dry-Run unten wird zusaetzlich eine EINZEILIGE
# Variante gebaut: az.cmd schneidet mehrzeilige Argumentwerte am ersten
# Zeilenumbruch ab.
$Query = ($Query -split "`n" | Where-Object { $_.Trim() -ne "" }) -join "`n"
$QuerySingleLine = (($Query -split "`n" | ForEach-Object { $_.Trim() }) -join " ").Replace('"', "'")

Write-Info "$SymInf Verwendete Query:"
$Query -split "`n" | ForEach-Object { Write-Sub $_ }
Write-Host ""
Write-Info "$SymInf Kein Schwellwert in der Query - die Auswertung erfolgt in der Regel"
Write-Sub "(sonst funktioniert das automatische Aufloesen des Alerts nicht)."
Write-Trenner

# =========================================================================
# [ DATENPRUEFUNG (DRY-RUN) ]
# =========================================================================
if ($RunDataCheck) {
    Write-Abschnitt "DATENPRUEFUNG"
    Write-Prozess "$SymRun Pruefe, ob Daten im Workspace vorliegen (letzte 1 h)..."

    $extOk = $true
    try {
        $exts = az extension list --query "[].name" --output json 2>$null | ConvertFrom-Json
        if ($exts -notcontains "log-analytics") {
            Write-Info "$SymInf Installiere CLI-Extension 'log-analytics'..."
            az extension add --name log-analytics --only-show-errors 2>$null | Out-Null
        }
    } catch { $extOk = $false }

    if ($extOk) {
        $checkQuery = $QuerySingleLine + " | summarize Datenpunkte = count(), Server = dcount(Computer)"
        try {
            $res = az monitor log-analytics query `
                --workspace $WorkspaceCustomerId `
                --analytics-query $checkQuery `
                --timespan "PT1H" `
                --output json 2>$null | ConvertFrom-Json

            if ($res -and $res.Count -gt 0 -and [int]$res[0].Datenpunkte -gt 0) {
                Write-Ok "$SymOk Daten vorhanden: $($res[0].Datenpunkte) Datenpunkte / $($res[0].Server) Server"
            } else {
                Write-Warnung "$SymWarn Keine Daten fuer '$DriveLetter' in der letzten Stunde gefunden."
                Write-Sub "Moegliche Ursachen:"
                Write-Sub "- AzureMonitorWindowsAgent-Extension fehlt auf dem Arc-Server"
                Write-Sub "- DCR nicht mit dem Arc-Server assoziiert (oder falsche Region)"
                Write-Sub "- Counter '% Free Space' / VM Insights nicht aktiviert"
                Write-Sub "- Einzelne Laufwerksbuchstaben brauchen nach DCR-Aenderung bis zu 1 h"
                $goOn = Read-Host "Trotzdem fortfahren? [J] Ja / [N] Abbrechen"
                if ($goOn -notmatch '^(j|ja|y|yes)$') {
                    Write-Warnung "$SymWarn Abbruch durch Benutzer."
                    Write-Trenner
                    exit 0
                }
            }
        } catch {
            Write-Warnung "$SymWarn Datenpruefung nicht moeglich (Rechte oder Extension). Fahre fort."
        }
    }
    Write-Trenner
}

# =========================================================================
# [ RESOURCE GROUP ]
# =========================================================================
Write-Abschnitt "RESOURCE GROUP"
$rgExists = az group exists --name $AlertResourceGroup --output tsv
if ($rgExists -eq "true") {
    Write-Ok "$SymOk Resource Group vorhanden: $AlertResourceGroup"
} else {
    Write-Prozess "$SymRun Erstelle Resource Group '$AlertResourceGroup'..."
    az group create --name $AlertResourceGroup --location $Location --output none
    Write-Ok "$SymOk Resource Group erstellt"
}
Write-Trenner

# =========================================================================
# [ ACTION GROUP ]
# =========================================================================
Write-Abschnitt "ACTION GROUP"
$ag = $null
try {
    $ag = az monitor action-group show `
        --name $ActionGroupName `
        --resource-group $AlertResourceGroup `
        --output json 2>$null | ConvertFrom-Json
} catch { $ag = $null }

if ($ag) {
    Write-Ok "$SymOk Action Group vorhanden: $ActionGroupName"
} else {
    Write-Prozess "$SymRun Erstelle Action Group '$ActionGroupName'..."
    az monitor action-group create `
        --name $ActionGroupName `
        --resource-group $AlertResourceGroup `
        --short-name $ActionGroupShortName `
        --action email $EmailName $EmailAddress `
        --output none
    $ag = az monitor action-group show `
        --name $ActionGroupName `
        --resource-group $AlertResourceGroup `
        --output json | ConvertFrom-Json
    Write-Ok "$SymOk Action Group erstellt"
}
$ActionGroupId = $ag.id
Write-Sub "Empfaenger: $EmailAddress"
Write-Sub "Hinweis   : Die erste E-Mail muss ggf. bestaetigt werden (Opt-in)."
Write-Trenner

# =========================================================================
# [ ALERT-REGEL (SCHEDULED QUERY RULE) ]
# =========================================================================
Write-Abschnitt "ALERT-REGEL"

# Gegenseitigen Ausschluss durchsetzen, bevor Azure ihn beanstandet
if ($AutoMitigate -and $MuteActionsDuration) {
    Write-Warnung "$SymWarn AutoMitigate und MuteActionsDuration schliessen sich aus."
    Write-Sub "Azure lehnt diese Kombination ab. MuteActionsDuration wird ignoriert."
    Write-Sub "Fuer eine Unterdrueckungsdauer `$AutoMitigate = `$false setzen."
    $MuteActionsDuration = ""
}

# Dimensionen: Computer (Split je Server) + Disk (Split je Laufwerk)
#
# ACHTUNG PowerShell-Falle: Einelementige Arrays werden beim Durchlaufen der
# Pipeline oder bei Zuweisung aus einem if-Ausdruck zum Skalar entpackt.
# ConvertTo-Json macht daraus dann "*" statt ["*"] und Azure lehnt den
# Payload ab ("Error converting value * to type List[System.String]").
# Der Cast auf [string[]] erzwingt den Array-Typ zuverlaessig.
if ($ComputerFilter.Count -gt 0) {
    [string[]]$dimComputerValues = $ComputerFilter
} else {
    [string[]]$dimComputerValues = @("*")
}
[string[]]$dimDiskValues = @("*")

$dimensions = [object[]]@(
    @{ name = "Computer"; operator = "Include"; values = $dimComputerValues }
    @{ name = "Disk";     operator = "Include"; values = $dimDiskValues }
)

$payload = [ordered]@{
    location   = $Location
    properties = [ordered]@{
        displayName         = $RuleDisplayName
        description         = "Feuert, wenn auf einem Arc-enabled Server der freie Speicher von $DriveLetter unter $ThresholdPercent % sinkt."
        severity            = $Severity
        enabled             = $true
        scopes              = [string[]]@($WorkspaceId)
        targetResourceTypes = [string[]]@("Microsoft.HybridCompute/machines")
        evaluationFrequency = $EvaluationFrequency
        windowSize          = $WindowSize
        criteria            = @{
            allOf = [object[]]@(
                [ordered]@{
                    query              = $Query
                    timeAggregation    = "Minimum"
                    metricMeasureColumn = "FreeSpacePercentage"
                    resourceIdColumn   = "_ResourceId"
                    dimensions         = $dimensions
                    operator           = "LessThan"
                    threshold          = $ThresholdPercent
                    failingPeriods     = @{
                        numberOfEvaluationPeriods = $NumberOfEvalPeriods
                        minFailingPeriodsToAlert  = $MinFailingPeriods
                    }
                }
            )
        }
        autoMitigate        = $AutoMitigate
        actions             = @{ actionGroups = [string[]]@($ActionGroupId) }
    }
}

# Nur setzen, wenn Auto-Resolve aus ist - sonst weist Azure den Payload ab.
if (-not $AutoMitigate -and $MuteActionsDuration) {
    $payload.properties.muteActionsDuration = $MuteActionsDuration
}

$json     = $payload | ConvertTo-Json -Depth 12
$tempFile = Join-Path $env:TEMP ("sqr-" + [guid]::NewGuid().ToString() + ".json")
[System.IO.File]::WriteAllText($tempFile, $json, (New-Object System.Text.UTF8Encoding($false)))

# Payload gegenpruefen, bevor er rausgeht
try {
    $check = Get-Content $tempFile -Raw -Encoding UTF8 | ConvertFrom-Json
    Write-Ok "$SymOk Payload ist valides JSON ($([math]::Round((Get-Item $tempFile).Length / 1KB, 1)) KB)"

    # Typpruefung: Azure verlangt an diesen Stellen zwingend Arrays.
    # PowerShell entpackt einelementige Arrays gern zum Skalar.
    $arrayFelder = @{
        "scopes"              = $check.properties.scopes
        "targetResourceTypes" = $check.properties.targetResourceTypes
        "criteria.allOf"      = $check.properties.criteria.allOf
        "actions.actionGroups"= $check.properties.actions.actionGroups
    }
    foreach ($k in $arrayFelder.Keys) {
        if ($arrayFelder[$k] -isnot [System.Array]) {
            throw "Feld '$k' wurde als Skalar serialisiert, Azure erwartet ein Array."
        }
    }
    $di = 0
    foreach ($d in @($check.properties.criteria.allOf[0].dimensions)) {
        if ($d.values -isnot [System.Array]) {
            throw "dimensions[$di].values ('$($d.name)') wurde als Skalar serialisiert."
        }
        $di++
    }
    Write-Ok "$SymOk Array-Felder korrekt serialisiert"
    Write-Sub ("Aggregation : {0}" -f $check.properties.criteria.allOf[0].timeAggregation)
    Write-Sub ("Messspalte  : {0}" -f $check.properties.criteria.allOf[0].metricMeasureColumn)
    Write-Sub ("Operator    : {0} {1}" -f $check.properties.criteria.allOf[0].operator, $check.properties.criteria.allOf[0].threshold)
    Write-Sub ("Dimensionen : {0}" -f (($check.properties.criteria.allOf[0].dimensions | ForEach-Object { $_.name }) -join ", "))
} catch {
    Write-Fehler "$SymErr Payload ist kein valides JSON: $($_.Exception.Message)"
    Write-Sub "Datei: $tempFile"
    Write-Trenner
    exit 1
}

$ruleId  = "/subscriptions/$($account.id)/resourceGroups/$AlertResourceGroup/providers/Microsoft.Insights/scheduledQueryRules/$RuleName"
$ruleUrl = "https://management.azure.com$($ruleId)?api-version=$ApiVersion"

Write-Prozess "$SymRun Erstelle / aktualisiere Regel '$RuleName' per 'az rest'..."
Write-Log "PUT $ruleUrl"

# WICHTIG: Rohausgabe erst als Text einsammeln. 'az' schreibt Fehler als
# Klartext ("ERROR: ...") - direktes Weiterleiten an ConvertFrom-Json wuerde
# daran scheitern und die eigentliche Azure-Meldung verschlucken.
$raw = ""
try {
    $raw = (az rest `
        --method put `
        --url $ruleUrl `
        --headers "Content-Type=application/json" `
        --body "@$tempFile" `
        --output json 2>&1 | Out-String).Trim()
} catch {
    $raw = "$($_.Exception.Message)"
}

$created = $null
if ($raw -match '^\s*\{') {
    try { $created = $raw | ConvertFrom-Json } catch { $created = $null }
}

if ($created -and $created.id) {
    Write-Ok "$SymOk Alert-Regel angelegt: $($created.name)"
    Write-Sub "Status aktiviert: $($created.properties.enabled)"
    Write-Sub "Schwellwert     : $($created.properties.criteria.allOf[0].threshold) %"
    Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
} else {
    Write-Fehler "$SymErr Erstellung fehlgeschlagen. Antwort von Azure:"
    Write-Host ""
    if ($raw) {
        $raw -split "`n" | ForEach-Object { Write-Host ("    " + $_.TrimEnd()) -ForegroundColor Red }
    } else {
        Write-Sub "(keine Ausgabe erhalten)"
    }
    Write-Host ""
    Write-Info "$SymInf Gesendeter Payload:"
    Write-Sub $tempFile
    Write-Host ""
    Write-Info "$SymInf Haeufige Ursachen bei Log-Search-Alerts:"
    Write-Sub "- Regel-Region weicht von der Workspace-Region ab"
    Write-Sub "  Regel: $Location  /  Workspace: $($law.location)"
    Write-Sub "- Rolle 'Monitoring Contributor' auf der Resource Group fehlt"
    Write-Sub "- Query-Validierung schlaegt fehl (Spalte aus metricMeasureColumn"
    Write-Sub "  oder resourceIdColumn nicht im Ergebnis enthalten)"
    Write-Sub "- Dimension 'Disk' oder 'Computer' fehlt im summarize"
    Write-Sub "- autoMitigate und muteActionsDuration gleichzeitig gesetzt"
    Write-Trenner
    exit 1
}
Write-Trenner

# =========================================================================
# [ ZUSAMMENFASSUNG ]
# =========================================================================
Write-Abschnitt "ZUSAMMENFASSUNG"
Write-Ok "$SymOk Einrichtung abgeschlossen"
Write-Sub "Alert-Regel   : $RuleName"
Write-Sub "Bedingung     : min($DriveLetter freier Speicher) < $ThresholdPercent % ueber $MinFailingPeriods x $WindowSize"
Write-Sub "Empfaenger    : $EmailAddress"
if ($AutoMitigate) {
    Write-Sub "Auto-Resolve  : aktiv - Entwarnung sobald wieder Platz frei ist"
    Write-Sub "Wiederholung  : keine, solange der Alert offen ist (stateful)"
} else {
    Write-Sub "Auto-Resolve  : aus"
    Write-Sub "Wiederholung  : $(if ($MuteActionsDuration) { "unterdrueckt fuer $MuteActionsDuration" } else { 'nicht unterdrueckt' })"
}
Write-Host ""
Write-Info "$SymInf Naechste Schritte / Pruefbefehle:"
Write-Sub "Regel anzeigen:"
Write-Sub "  az monitor scheduled-query show -g $AlertResourceGroup -n $RuleName -o json"
Write-Sub "Gefeuerte Alerts anzeigen:"
Write-Sub "  az monitor activity-log alert list -g $AlertResourceGroup -o table"
Write-Sub "Aktuelle Werte abfragen:"
Write-Sub "  .\Get-ArcDiskSpace.ps1"
Write-Host ""
Write-Warnung "$SymWarn Test: Schwellwert temporaer hochsetzen (z. B. 95) und Regel erneut anlegen,"
Write-Sub "danach wieder auf $ThresholdPercent zuruecksetzen."
Write-Trenner
