#Requires -Version 5.1
<#
.SYNOPSIS
    SCHRITT 2 von 6 - Prueft die Voraussetzungen fuer Disk-Space-Alerts,
    beschraenkt auf VIRTUAL SERVER (VMs). AVD-Session-Hosts und physische
    Server werden vor der Auswertung ausgeschlossen.
.DESCRIPTION
    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung

    AENDERUNG IN 3.5.0 - MEHRERE POLICY-TAGS
    -------------------------------------------------------------------------
    Die Policy waehlt nicht mehr ueber ein einzelnes Tag aus, sondern ueber
    mehrere UND-verknuepfte. Der Report bildet das ueber $PolicyTagFilter
    nach - dieselbe Hashtable wie in New-ArcMonitoringPolicy.ps1. Beide
    Bloecke gehoeren gemeinsam gepflegt, sonst prueft der Report einen
    anderen Serverkreis als die Policy erfasst.

    Die Spalte 'Tag' zeigt jetzt, WELCHES Kriterium fehlt, nicht nur den
    Wert eines einzelnen Tags.

    AENDERUNG IN 3.4.0 - POLICY-TAG WIRD GEPRUEFT
    -------------------------------------------------------------------------
    Bis 3.3.0 las das Script das Tag Monitoring=VirtualServer gar nicht.
    Das war eine Luecke, seit die Policy ueber dieses Tag auswaehlt: fehlt
    es, wird eine fehlende DCR-Zuordnung nie automatisch nachgezogen. Der
    Report meldete das erst nachgelagert als 'Disk-DCR fehlt', ohne die
    eigentliche Ursache zu nennen.

    Das Tag steht jetzt als eigene Spalte im Report. Es wird ZULETZT
    geprueft: liefert eine Maschine bereits Daten, ist sie alert-faehig -
    ein fehlendes Tag ist dann ein Risiko fuer die Zukunft, kein aktueller
    Mangel. Der Status lautet in dem Fall 'OK, Tag fehlt'.

    AENDERUNG IN 3.3.0 - DISK-DATEN VOR HEARTBEAT
    -------------------------------------------------------------------------
    Bis 3.2.0 wurde 'Kein Heartbeat' VOR 'Keine Disk-Daten' geprueft. Das
    ist die falsche Reihenfolge: beide Signale stammen aus verschiedenen
    DCRs - InsightsMetrics aus der VM-Insights-DCR, Heartbeat aus der
    Change-Tracking-DCR. Ein Server kann also Disk-Daten liefern, ohne
    Heartbeat zu senden, und ist fuer den Disk-Alert trotzdem vollstaendig
    funktionsfaehig. Er wurde dennoch als 'Kein Heartbeat' gemeldet.

    Jetzt gilt: fehlen BEIDE, lautet der Status 'Keine Daten'. Fehlen nur
    die Disk-Daten, 'Keine Disk-Daten'. Fehlt nur der Heartbeat, ist der
    Status 'OK' und ein Hinweis am Ende nennt die betroffenen Server.

    AENDERUNG IN 3.2.0 - AMA-ZUSTAND UND DCR-NAMEN
    -------------------------------------------------------------------------
    Bis 3.1.0 galt die AMA-Extension als vorhanden, sobald sie existierte -
    unabhaengig vom provisioningState. Eine Extension in 'Failed' oder
    'Creating' wurde damit als in Ordnung gewertet, obwohl sie nichts
    sammelt. Jetzt zaehlt nur 'Succeeded' als in Ordnung; jeder andere
    Zustand erscheint als eigener Status, z. B. 'AMA Failed'.

    Ausserdem fuehrt der Report jetzt die NAMEN der zugeordneten DCRs mit.
    Der fruehere Status 'DCR ohne Disk-Counter' war zwar korrekt, aber nicht
    handlungsfaehig: der Server hat DCRs, nur nicht die richtige. Der Status
    heisst deshalb jetzt 'Disk-DCR fehlt', und ein Detailblock am Ende zeigt
    je Problemfall, welche DCRs tatsaechlich zugeordnet sind.

    AENDERUNG IN 3.1.0 - MATCHING UEBER _ResourceId
    -------------------------------------------------------------------------
    Bis 3.0.0 wurde der Arc-Maschinenname gegen die Spalte 'Computer' aus
    Log Analytics verglichen. Das schlaegt bei domaenengejointen Maschinen
    immer fehl:

        Arc-Ressourcenname : sckkr11
        LAW-Spalte Computer: sckkr11.ldkads.local

    Ergebnis war "Kein Heartbeat" fuer alle Domaenenmitglieder, waehrend nur
    Workgroup-Maschinen ohne Suffix korrekt erkannt wurden.

    Die Korrektur schneidet NICHT das Suffix ab - das waere fehleranfaellig,
    sobald ein Hostname selbst einen Punkt enthaelt oder zwei Maschinen in
    verschiedenen Domaenen denselben Kurznamen tragen. Stattdessen wird
    _ResourceId verwendet: Heartbeat und InsightsMetrics fuehren beide die
    vollstaendige ARM-Ressourcen-ID der Arc-Maschine mit. Das ist ein
    eindeutiger Schluessel ohne Namensinterpretation.

    Der Kurzname bleibt als Fallback, falls _ResourceId in einer Zeile leer
    ist. Abweichungen zwischen beiden Wegen werden ausgegeben.

    ZIELTABELLE
    -------------------------------------------------------------------------
    Geprueft wird InsightsMetrics, NICHT Perf. Die DCR aus Script 1 nutzt
    \VmInsights\DetailedMetrics mit Stream Microsoft-InsightsMetrics und
    schreibt damit ausschliesslich nach InsightsMetrics. Die Perf-Tabelle
    bleibt leer, solange keine DCR mit Stream Microsoft-Perf existiert -
    das ist erwartetes Verhalten, kein Fehler.

    AUSSCHLUSS IN VIER STUFEN (erste zutreffende Regel gewinnt)
    -------------------------------------------------------------------------
      1. Namensliste     - $ExcludeNames, exakte Treffer
      2. Namensmuster    - $ExcludeNamePatterns, Regex (AVD: '^avd')
      3. Hardware        - detectedProperties.model / .manufacturer
      4. Ist-Workspace   - DCR zeigt auf einen Workspace aus
                           $ExcludeWorkspacePatterns
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 18.08.2026
    Version     : 3.5.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Test-ArcMonitoringPrereq.ps1
.EXAMPLE
    # Ausgeschlossene Maschinen einzeln auflisten statt nur zaehlen
    $ShowExcluded = $true; .\Test-ArcMonitoringPrereq.ps1
#>

# Python-Warnungen aus CLI-Extensions unterdruecken (sonst stderr-Rauschen,
# das PowerShell als NativeCommandError wertet)
$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

$SubscriptionId         = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local

# --- Ziel-Workspace ---
$WorkspaceName          = "law-LDK-VirtualServer"
$WorkspaceResourceGroup = "rg-arcmgmt"

# --- AUSSCHLUSS 1: exakte Namen ---
$ExcludeNames           = @()

# --- AUSSCHLUSS 2: Namensmuster (Regex, case-insensitive) ---
$ExcludeNamePatterns    = @(
    '^avd'                       # AVD-Session-Hosts
)

# --- AUSSCHLUSS 3: physische Server ueber Hardware-Erkennung ---
$ExcludePhysical        = $true
$VirtualModelPatterns   = @('Virtual Machine', 'VMware Virtual', 'HVM domU', 'KVM', 'QEMU')
$VirtualVendorPatterns  = @('Microsoft Corporation', 'VMware', 'QEMU', 'Xen', 'Nutanix', 'Parallels')
$UnknownHardwareIsPhysical = $false

# --- AUSSCHLUSS 4: DCR fremder Workspaces ---
$ExcludeWorkspacePatterns = @('physicalserver', 'avd')

# --- Policy-Tag ---
# Die Policy aus New-ArcMonitoringPolicy.ps1 waehlt Maschinen ueber dieses
# Tag aus. Fehlt es, greift die Policy nicht - die Maschine bleibt dauerhaft
# ohne DCR-Zuordnung, ohne dass es an DCR oder Agent liegt.
# ALLE Eintraege muessen zutreffen - identisch zu $PolicyTagFilter in
# New-ArcMonitoringPolicy.ps1. Beide Bloecke gehoeren gemeinsam gepflegt,
# sonst prueft der Report einen anderen Serverkreis als die Policy erfasst.
$PolicyTagFilter        = [ordered]@{
    "Monitoring"      = "VirtualServer"
    "OperatingSystem" = "Windows Server"
}
$CheckPolicyTag         = $true

# --- Pruefparameter ---
$DiskCounterPattern     = "LogicalDisk|VmInsights"   # auch \VmInsights\DetailedMetrics
$DataLookbackHours      = 2
$CheckDataFlow          = $true
$ShowExcluded           = $false
$ExportCsv              = $false
$CsvPath                = ".\ArcMonitoringPrereq_$(Get-Date -f 'yyyyMMdd-HHmmss').csv"

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    <#
      Ruft Azure CLI auf und liefert sauberes JSON zurueck. Trennt stdout und
      stderr, damit Python-Warnungen der CLI-Extensions das JSON nicht
      zerstoeren. Rueckgabe: PSObject bei Erfolg, $null bei Fehler.
      Fehlertext steht danach in $script:LastAzError.
    #>
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort erhalten: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Ensure-Extension {
    param([Parameter(Mandatory)][string]$Name)
    $exts = Invoke-AzJson @("extension","list")
    if ($exts | Where-Object { $_.name -eq $Name }) { return $true }
    Write-Warn2 "Extension '$Name' fehlt - wird installiert."
    az extension add --name $Name --only-show-errors 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Installation von '$Name' fehlgeschlagen."; return $false }
    return $true
}

function Test-IsVirtual {
    <#
      Erst das Modell pruefen, dann den Hersteller: ein physischer Hyper-V-Host
      meldet ebenfalls 'Microsoft Corporation', aber ein echtes Servermodell.
    #>
    param([string]$Model, [string]$Manufacturer)

    if ([string]::IsNullOrWhiteSpace($Model) -and [string]::IsNullOrWhiteSpace($Manufacturer)) {
        return (-not $UnknownHardwareIsPhysical)
    }
    foreach ($p in $VirtualModelPatterns) { if ($Model -like "*$p*") { return $true } }
    if (-not [string]::IsNullOrWhiteSpace($Model)) { return $false }
    foreach ($p in $VirtualVendorPatterns) { if ($Manufacturer -like "*$p*") { return $true } }
    return $false
}

function Get-ShortName {
    <#
      Kurzname aus einem moeglichen FQDN. Nur als Fallback, wenn _ResourceId
      in einer LAW-Zeile fehlt.
    #>
    param([string]$Name)
    if ([string]::IsNullOrWhiteSpace($Name)) { return "" }
    return ($Name -split '\.')[0].ToLower()
}

# =============================================================================
#  STUFE 0 - PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - bitte 'az upgrade' ausfuehren."
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
    Write-Ok "Subscription gesetzt."
}

Write-Run "Pruefe benoetigte Extensions..."
$extOk = $true
foreach ($e in @("monitor-control-service","resource-graph")) {
    if (-not (Ensure-Extension -Name $e)) { $extOk = $false }
}
if ($CheckDataFlow) { if (-not (Ensure-Extension -Name "log-analytics")) { $CheckDataFlow = $false } }
if (-not $extOk) { exit 1 }
Write-Ok "Alle benoetigten Extensions verfuegbar."
Write-Line

# =============================================================================
#  STUFE 1 - ZIEL-WORKSPACE
# =============================================================================
Write-Head "STUFE 1 - ZIEL-WORKSPACE"

Write-Run "Loese '$WorkspaceName' auf..."
$ws = Invoke-AzJson @("monitor","log-analytics","workspace","show",
                      "--resource-group",$WorkspaceResourceGroup,
                      "--name",$WorkspaceName,"-o","json")
if (-not $ws) {
    Write-Fail "Workspace '$WorkspaceName' in RG '$WorkspaceResourceGroup' nicht erreichbar."
    Write-Sub "Ursache: $script:LastAzError"
    exit 1
}
Write-Ok "Workspace gefunden: $($ws.name) ($($ws.location))"
Write-Sub "Workspace-ID: $($ws.customerId)"
$WorkspaceResourceId = $ws.id.ToLower()
Write-Line

# =============================================================================
#  STUFE 2 - ARC-INVENTAR (Resource Graph, ein Aufruf)
# =============================================================================
Write-Head "STUFE 2 - ARC-INVENTAR"

Write-Run "Lade Arc-Maschinen inkl. Hardware und AMA-Status..."

# Nur einfache Anfuehrungszeichen - doppelte ueberleben az.cmd unter Windows nicht.
$argQuery = "resources " `
  + "| where type =~ 'microsoft.hybridcompute/machines' " `
  + "| extend mid = tolower(id) " `
  + "| project mid, name, resourceGroup, " `
  +   "status = tostring(properties.status), " `
  +   "osName = tostring(properties.osName), " `
  +   "model = tostring(properties.detectedProperties.model), " `
  +   "manufacturer = tostring(properties.detectedProperties.manufacturer), " `
  +   "tagBag = tostring(tags) " `
  + "| join kind=leftouter ( " `
  +   "resources " `
  +   "| where type =~ 'microsoft.hybridcompute/machines/extensions' " `
  +   "| where properties.type in~ ('AzureMonitorWindowsAgent','AzureMonitorLinuxAgent') " `
  +   "| extend mid = tolower(substring(id, 0, indexof(id, '/extensions/'))) " `
  +   "| project mid, amaState = tostring(properties.provisioningState) " `
  + ") on mid " `
  + "| project mid, name, resourceGroup, status, osName, model, manufacturer, tagBag, amaState"

$argRes = Invoke-AzJson @("graph","query","-q",$argQuery,"--first","1000","-o","json")
if (-not $argRes -or -not $argRes.data) {
    Write-Fail "Arc-Inventar nicht abrufbar: $script:LastAzError"
    exit 1
}
$machines = @($argRes.data)
Write-Ok "$($machines.Count) Arc-Maschine(n) gefunden."
if ($machines.Count -ge 1000) {
    Write-Warn2 "Limit von 1000 erreicht - Ergebnis moeglicherweise unvollstaendig."
}

$mitHw = @($machines | Where-Object { $_.model -or $_.manufacturer }).Count
Write-Sub "Mit Hardware-Angaben: $mitHw / $($machines.Count)"
Write-Line

# =============================================================================
#  STUFE 3 - DCR-INVENTAR UND ZUORDNUNG
# =============================================================================
Write-Head "STUFE 3 - DATA COLLECTION RULES"

Write-Run "Lade DCRs der Subscription..."
$dcrs = Invoke-AzJson @("monitor","data-collection","rule","list","-o","json")
if (-not $dcrs) { Write-Fail "Keine DCRs abrufbar: $script:LastAzError"; exit 1 }
$dcrs = @($dcrs)
Write-Ok "$($dcrs.Count) DCR(s) gefunden."

$istMap   = @{}   # machineId -> Liste von Zuordnungen
$zielDcrs = @()

foreach ($dcr in $dcrs) {

    # --- Ziel-Workspaces der DCR ---
    $wsIds   = @()
    $wsNames = @()
    if ($dcr.destinations -and $dcr.destinations.logAnalytics) {
        foreach ($d in $dcr.destinations.logAnalytics) {
            $wsIds   += $d.workspaceResourceId.ToLower()
            $wsNames += ($d.workspaceResourceId -split '/')[-1]
        }
    }
    $trifftZiel = ($wsIds -contains $WorkspaceResourceId)

    # --- Disk-Counter enthalten? Drei Erkennungswege ---
    #     \VmInsights\DetailedMetrics enthaelt NICHT die Zeichenfolge
    #     'LogicalDisk' - deshalb deckt $DiskCounterPattern beides ab.
    $diskGrund = $null
    if ($dcr.dataSources -and $dcr.dataSources.performanceCounters) {
        foreach ($pc in $dcr.dataSources.performanceCounters) {
            if ($pc.counterSpecifiers -and ($pc.counterSpecifiers -join " ") -match $DiskCounterPattern) {
                $diskGrund = "Counter"
            }
            if (-not $diskGrund -and $pc.streams -and ($pc.streams -join " ") -match "InsightsMetrics") {
                $diskGrund = "VM Insights"
            }
        }
    }
    if (-not $diskGrund -and $dcr.kind -eq "Insights") { $diskGrund = "Kind=Insights" }
    $hasDisk = [bool]$diskGrund

    if ($trifftZiel -and $hasDisk) { $zielDcrs += $dcr.name }

    # --- Associations je DCR holen, nicht je Maschine ---
    $assocs = Invoke-AzJson @("monitor","data-collection","rule","association","list",
                              "--rule-name",$dcr.name,
                              "--resource-group",$dcr.resourceGroup,"-o","json")
    $assocs = @($assocs)

    foreach ($a in $assocs) {
        $idx = $a.id.ToLower().IndexOf("/providers/microsoft.insights/datacollectionruleassociations/")
        if ($idx -lt 1) { continue }
        $machineId = $a.id.Substring(0, $idx).ToLower()

        if (-not $istMap.ContainsKey($machineId)) { $istMap[$machineId] = @() }
        $istMap[$machineId] += [PSCustomObject]@{
            DcrName    = $dcr.name
            WsNames    = $wsNames
            TrifftZiel = $trifftZiel
            HasDisk    = $hasDisk
            DiskGrund  = $diskGrund
        }
    }
}

if ($zielDcrs.Count -gt 0) {
    Write-Ok "$($zielDcrs.Count) DCR(s) sammeln Disk-Daten auf '$WorkspaceName':"
    foreach ($z in $zielDcrs) { Write-Sub $z }
}
else {
    Write-Fail "Keine DCR sammelt Disk-Daten auf '$WorkspaceName'."
    Write-Sub "Bitte zuerst .\New-ArcVmInsightsDcr.ps1 ausfuehren."
}
Write-Line

# =============================================================================
#  STUFE 4 - FILTER
# =============================================================================
Write-Head "STUFE 4 - FILTER"

$inScope  = @()
$excluded = @()

foreach ($m in $machines) {

    $grund = $null

    if ($ExcludeNames -contains $m.name) { $grund = "Ausschlussliste" }

    if (-not $grund) {
        foreach ($p in $ExcludeNamePatterns) {
            if ($m.name -match $p) { $grund = "AVD (Namensmuster)"; break }
        }
    }

    if (-not $grund -and $ExcludePhysical) {
        if (-not (Test-IsVirtual -Model $m.model -Manufacturer $m.manufacturer)) {
            $grund = "Physisch (Hardware)"
        }
    }

    if (-not $grund -and $istMap.ContainsKey($m.mid)) {
        $alleWs = @($istMap[$m.mid] | ForEach-Object { $_.WsNames } | Select-Object -Unique)
        foreach ($w in $alleWs) {
            foreach ($p in $ExcludeWorkspacePatterns) {
                if ($w -match $p) { $grund = "Fremder Workspace ($w)"; break }
            }
            if ($grund) { break }
        }
    }

    if ($grund) {
        $excluded += [PSCustomObject]@{
            Server = $m.name
            Grund  = $grund
            Modell = if ($m.model) { $m.model } else { "-" }
        }
    }
    else { $inScope += $m }
}

Write-Ok "Im Scope (Virtual Server): $($inScope.Count)"
Write-Warn2 "Ausgeschlossen: $($excluded.Count)"
foreach ($g in ($excluded | Group-Object Grund | Sort-Object Count -Descending)) {
    Write-Sub ("{0,-30} {1,4}" -f $g.Name, $g.Count)
}

if ($ShowExcluded -and $excluded.Count -gt 0) {
    Write-Host ""
    Write-Info2 "Ausgeschlossene Maschinen im Detail:"
    foreach ($e in ($excluded | Sort-Object Grund, Server)) {
        Write-Host ("    {0,-26} {1,-30} {2}" -f $e.Server, $e.Grund, $e.Modell) -ForegroundColor DarkGray
    }
}

if ($inScope.Count -eq 0) {
    Write-Host ""
    Write-Fail "Keine Maschine im Scope - bitte Filterregeln pruefen."
    Write-Line
    exit 1
}
Write-Line

# =============================================================================
#  STUFE 5 - DATENFLUSS
# =============================================================================
$flowById   = @{}   # tolower(_ResourceId) -> @{ Heartbeat; Disk }
$flowByName = @{}   # Kurzname             -> @{ Heartbeat; Disk }   (Fallback)

if ($CheckDataFlow) {
    Write-Head "STUFE 5 - DATENFLUSS"
    Write-Run "Frage '$WorkspaceName' ab (letzte $DataLookbackHours h)..."
    Write-Sub "Zieltabelle: InsightsMetrics (nicht Perf)"

    # _ResourceId ist der eindeutige Schluessel. Computer kommt nur als
    # Fallback mit, weil LAW dort den FQDN fuehrt und Arc den Kurznamen.
    $flowQuery = "union " `
      + "(Heartbeat | where TimeGenerated > ago(${DataLookbackHours}h) " `
      +   "| summarize by ResId = tolower(_ResourceId), Computer | extend Art = 'Heartbeat'), " `
      + "(InsightsMetrics | where TimeGenerated > ago(${DataLookbackHours}h) " `
      +   "| where Namespace == 'LogicalDisk' and Name == 'FreeSpacePercentage' " `
      +   "| summarize by ResId = tolower(_ResourceId), Computer | extend Art = 'Disk')"

    $rows = Invoke-AzJson @("monitor","log-analytics","query",
                            "--workspace",$ws.customerId,
                            "--analytics-query",$flowQuery,"-o","json")
    if ($rows) {
        $hb = 0; $dk = 0; $ohneResId = 0

        foreach ($r in @($rows)) {
            $isHb = ($r.Art -eq "Heartbeat")
            if ($isHb) { $hb++ } else { $dk++ }

            if (-not [string]::IsNullOrWhiteSpace($r.ResId)) {
                if (-not $flowById.ContainsKey($r.ResId)) {
                    $flowById[$r.ResId] = @{ Heartbeat = $false; Disk = $false }
                }
                if ($isHb) { $flowById[$r.ResId].Heartbeat = $true }
                else       { $flowById[$r.ResId].Disk      = $true }
            }
            else { $ohneResId++ }

            $short = Get-ShortName -Name $r.Computer
            if ($short) {
                if (-not $flowByName.ContainsKey($short)) {
                    $flowByName[$short] = @{ Heartbeat = $false; Disk = $false }
                }
                if ($isHb) { $flowByName[$short].Heartbeat = $true }
                else       { $flowByName[$short].Disk      = $true }
            }
        }

        Write-Ok "Heartbeat: $hb / Disk-Daten: $dk (gesamter Workspace, vor Filter)"
        if ($ohneResId -gt 0) {
            Write-Warn2 "$ohneResId Zeile(n) ohne _ResourceId - dort greift der Kurznamen-Fallback."
        }
    }
    else {
        Write-Warn2 "Datenfluss-Abfrage fehlgeschlagen: $script:LastAzError"
        $CheckDataFlow = $false
    }
    Write-Line
}

# =============================================================================
#  STUFE 6 - AUSWERTUNG
# =============================================================================
Write-Head "STUFE 6 - AUSWERTUNG (nur Virtual Server)"

$results     = @()
$nurFallback = 0

foreach ($m in $inScope) {

    $connected  = ($m.status -eq "Connected")

    # AMA: nicht nur pruefen OB die Extension existiert, sondern in welchem
    # Zustand. Eine Extension in 'Failed' oder 'Creating' ist vorhanden,
    # sammelt aber nichts - das war bis 3.1.0 als 'AMA vorhanden' gewertet.
    $amaState   = if ([string]::IsNullOrWhiteSpace($m.amaState)) { "-" } else { $m.amaState }
    $hasAma     = ($amaState -ne "-")
    $amaOk      = ($amaState -eq "Succeeded")

    $dcrEntries = if ($istMap.ContainsKey($m.mid)) { @($istMap[$m.mid]) } else { @() }
    $zielDcr    = @($dcrEntries | Where-Object { $_.TrifftZiel -and $_.HasDisk })

    # Namen der zugeordneten DCRs mitfuehren - sonst ist 'DCR ohne
    # Disk-Counter' nicht nachvollziehbar.
    $dcrNamen   = if ($dcrEntries.Count -gt 0) {
                      (@($dcrEntries | ForEach-Object { $_.DcrName } | Select-Object -Unique)) -join ", "
                  } else { "-" }

    # --- Datenfluss: primaer ueber _ResourceId, sonst ueber Kurznamen ---
    $hb = $false; $dk = $false; $via = "-"

    if ($flowById.ContainsKey($m.mid)) {
        $hb  = $flowById[$m.mid].Heartbeat
        $dk  = $flowById[$m.mid].Disk
        $via = "ResId"
    }
    else {
        $short = $m.name.ToLower()
        if ($flowByName.ContainsKey($short)) {
            $hb  = $flowByName[$short].Heartbeat
            $dk  = $flowByName[$short].Disk
            $via = "Name"
            $nurFallback++
        }
    }

    # Policy-Tags: keine technische Voraussetzung fuer die Datensammlung,
    # aber die Auswahlbedingung der Policy. Fehlt EINER, wird eine fehlende
    # DCR-Zuordnung nie automatisch nachgezogen.
    $tags = @{}
    if (-not [string]::IsNullOrWhiteSpace($m.tagBag)) {
        try { ($m.tagBag | ConvertFrom-Json).PSObject.Properties |
              ForEach-Object { $tags[$_.Name] = [string]$_.Value } } catch { }
    }
    $fehlendeTags = @()
    foreach ($k in $PolicyTagFilter.Keys) {
        if ($tags[$k] -ne $PolicyTagFilter[$k]) { $fehlendeTags += $k }
    }
    $tagOk   = (-not $CheckPolicyTag) -or ($fehlendeTags.Count -eq 0)
    $tagWert = if ($tagOk) { "ok" }
               elseif ($fehlendeTags.Count -eq $PolicyTagFilter.Count) { "alle fehlen" }
               else { "fehlt: " + ($fehlendeTags -join ",") }

    # --- Statuslogik, erste zutreffende Regel gewinnt ---
    #
    # REIHENFOLGE: Disk-Daten VOR Heartbeat. Beide stammen aus
    # verschiedenen DCRs - InsightsMetrics aus der VM-Insights-DCR,
    # Heartbeat aus der Change-Tracking-DCR. Ein Server kann Disk-Daten
    # liefern, ohne Heartbeat zu senden; fuer den Disk-Alert ist er dann
    # vollstaendig funktionsfaehig. Umgekehrt priorisiert waere der
    # Status irrefuehrend.
    #
    # Der Tag wird ZULETZT geprueft: liefert die Maschine bereits Daten,
    # ist sie alert-faehig - der fehlende Tag ist dann ein Risiko fuer die
    # Zukunft, kein aktueller Mangel. Er erscheint deshalb als eigener
    # Status nur dann, wenn sonst alles in Ordnung ist.
    $status = "OK"
    if     (-not $connected)                           { $status = "Agent offline" }
    elseif (-not $hasAma -and $dcrEntries.Count -eq 0) { $status = "AMA/DCR fehlt" }
    elseif (-not $hasAma)                              { $status = "AMA fehlt" }
    elseif (-not $amaOk)                               { $status = "AMA $amaState" }
    elseif ($dcrEntries.Count -eq 0)                   { $status = "Keine DCR" }
    elseif ($zielDcr.Count -eq 0)                      { $status = "Disk-DCR fehlt" }
    elseif ($CheckDataFlow -and -not $dk -and -not $hb){ $status = "Keine Daten" }
    elseif ($CheckDataFlow -and -not $dk)              { $status = "Keine Disk-Daten" }
    elseif (-not $tagOk)                               { $status = "OK, Tag fehlt" }

    $results += [PSCustomObject]@{
        Server    = $m.name
        RG        = $m.resourceGroup
        OS        = $m.osName
        Modell    = if ($m.model) { $m.model } else { "-" }
        Agent     = $m.status
        AMA       = $amaState
        Tag       = $tagWert
        DCR       = $dcrEntries.Count
        DcrNamen  = $dcrNamen
        DiskDCR   = $zielDcr.Count
        Heartbeat = if ($hb) { "ja" } else { "nein" }
        DiskDaten = if ($dk) { "ja" } else { "nein" }
        MatchUeber= $via
        Status    = $status
    }
}

Write-Host ""
Write-Host ("    {0,-26} {1,-10} {2,-11} {3,-15} {4}" -f `
            "Server","Heartbeat","Disk-Daten","Tag","Bewertung") -ForegroundColor White
Write-Host ("    " + ("-" * 80)) -ForegroundColor White

foreach ($r in ($results | Sort-Object Status, Server)) {
    $farbe = switch ($r.Status) {
        "OK"               { "Green" }
        "Keine Disk-Daten" { "Yellow" }
        "Disk-DCR fehlt"   { "Yellow" }
        "Keine Daten"      { "Red" }
        "OK, Tag fehlt"    { "Yellow" }
        default            { "Red" }
    }
    Write-Host ("    {0,-26} {1,-10} {2,-11} {3,-15} {4}" -f `
                $r.Server, $r.Heartbeat, $r.DiskDaten, $r.Tag, $r.Status) -ForegroundColor $farbe
}
Write-Host ""
Write-Line

# =============================================================================
#  ZUSAMMENFASSUNG
# =============================================================================
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "Arc-Maschinen gesamt : $($machines.Count)"
Write-Sub "Ausgeschlossen       : $($excluded.Count)"
Write-Sub "Virtual Server       : $($results.Count)"
Write-Host ""

foreach ($grp in ($results | Group-Object Status | Sort-Object Count -Descending)) {
    $farbe = if ($grp.Name -eq "OK") { "Green" } elseif ($grp.Name -like "*fehlt*") { "Red" } else { "Yellow" }
    Write-Host ("    {0,-24} {1,4}" -f $grp.Name, $grp.Count) -ForegroundColor $farbe
}

Write-Host ""
$bereit = @($results | Where-Object { $_.Status -eq "OK" })
Write-Info2 "Alert-faehig: $($bereit.Count) von $($results.Count) Virtual Servern"

# --- Detailblock: bei Problemfaellen die zugeordneten DCRs zeigen ---------
# Ohne diese Angabe ist 'Disk-DCR fehlt' nicht nachvollziehbar - der Server
# hat ja DCRs, nur nicht die richtige.
$probleme = @($results | Where-Object { $_.Status -ne "OK" })
if ($probleme.Count -gt 0) {
    Write-Host ""
    Write-Head "DETAILS ZU DEN PROBLEMFAELLEN"
    Write-Host ("    {0,-22} {1,-16} {2,-12} {3,-14} {4}" -f `
                "Server","Bewertung","AMA","Tag","Zugeordnete DCRs") -ForegroundColor White
    Write-Host ("    " + ("-" * 100)) -ForegroundColor White

    foreach ($r in ($probleme | Sort-Object Status, Server)) {
        $farbe = if ($r.Status -like "*fehlt*" -or $r.Status -like "AMA *") { "Red" } else { "Yellow" }
        Write-Host ("    {0,-22} {1,-16} {2,-12} {3,-14} {4}" -f `
                    $r.Server, $r.Status, $r.AMA, $r.Tag, $r.DcrNamen) -ForegroundColor $farbe
    }
}

if ($nurFallback -gt 0) {
    Write-Host ""
    Write-Warn2 "$nurFallback Maschine(n) nur ueber den Kurznamen zugeordnet."
    Write-Sub "Bei doppelten Kurznamen in verschiedenen Domaenen ist das nicht eindeutig."
}

$ohneDaten = @($results | Where-Object { $_.Status -eq "Keine Disk-Daten" })
if ($ohneDaten.Count -gt 0) {
    Write-Host ""
    Write-Warn2 "$($ohneDaten.Count) Server ohne Disk-Daten."
    Write-Sub "Nach einer neuen DCR-Association dauert es 5 bis 15 Minuten bis zu den"
    Write-Sub "ersten Werten. Bei anhaltendem Fehlen die DCR-Datenquelle pruefen."
}

# Policy-Tag: eigener Block, weil die Folge zeitversetzt eintritt.
if ($CheckPolicyTag) {
    $krit    = ($PolicyTagFilter.Keys | ForEach-Object { "$_=$($PolicyTagFilter[$_])" }) -join " UND "
    $ohneTag = @($results | Where-Object { $_.Tag -ne "ok" })
    if ($ohneTag.Count -gt 0) {
        Write-Host ""
        Write-Warn2 "$($ohneTag.Count) Virtual Server erfuellen nicht $krit."
        Write-Sub "Die Policy waehlt ueber dieses Tag aus. Ohne Tag wird eine fehlende"
        Write-Sub "DCR-Zuordnung nie automatisch nachgezogen - auch wenn heute noch"
        Write-Sub "Daten fliessen."
        foreach ($t in ($ohneTag | Sort-Object Server | Select-Object -First 15)) {
            Write-Sub "  $($t.Server)  ($($t.Tag))"
        }
        if ($ohneTag.Count -gt 15) { Write-Sub "  ... und $($ohneTag.Count - 15) weitere" }
    }
    else {
        Write-Host ""
        Write-Ok "Alle $($results.Count) Virtual Server erfuellen $krit."
    }
}

# Heartbeat fehlt, Disk-Daten sind aber da: kein Fehler fuer den Alert, aber
# ein Hinweis auf die Change-Tracking-DCR, die den Heartbeat liefert.
$ohneHb = @($results | Where-Object { $_.Heartbeat -eq "nein" -and $_.DiskDaten -eq "ja" })
if ($ohneHb.Count -gt 0) {
    Write-Host ""
    Write-Info2 "$($ohneHb.Count) Server liefern Disk-Daten, aber keinen Heartbeat."
    Write-Sub "Fuer den Disk-Alert unerheblich - Heartbeat kommt aus einer anderen DCR"
    Write-Sub "(Change Tracking), nicht aus der VM-Insights-DCR."
    foreach ($h in ($ohneHb | Sort-Object Server | Select-Object -First 10)) {
        Write-Sub "  $($h.Server)"
    }
}

if ($ExportCsv) {
    $results | Export-Csv -Path $CsvPath -NoTypeInformation -Encoding UTF8
    Write-Host ""
    Write-Ok "CSV geschrieben: $CsvPath"
}

Write-Host ""
Write-Info2 "Naechster Schritt: .\Get-ArcDiskSpace.ps1"
Write-Line
