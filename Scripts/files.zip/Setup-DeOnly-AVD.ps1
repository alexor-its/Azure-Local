﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Konfiguriert einen en-US deployten Windows 11 Enterprise Multi-Session
    AVD Session Host auf deutsche Sprache, Region, Tastatur und Zeitzone.
.DESCRIPTION
    Post-Deployment-Script fuer Windows 11 Enterprise Multi-Session,
    ausgefuehrt ueber die Azure Arc / Azure VM Custom Script Extension.

    Ablauf:
      1. Offline-Datentraeger online schalten
      2. RAW-Datentraeger initialisieren und formatieren
      3. Deutsches Sprachpaket installieren
         3a. LXP-/LP-Cleanup-Tasks deaktivieren
         3b. FOD-Capabilities via DISM aus Windows Update
      4. Locale, UI-Sprache, Tastatur und Region setzen (inkl. DefaultUser + SYSTEM)
      5. Zeitzone setzen
      6. WinRM aktivieren
      7. Installationsverzeichnis anlegen
      8. Platzhalter fuer eigene Anwendungsinstallation

    Warum DISM statt Install-Language:
      Install-Language wird fuer gepoolte Multi-Session Host Pools von
      Microsoft nicht unterstuetzt. DISM /Online /Add-Capability ohne
      /LimitAccess bezieht die Pakete direkt von Windows Update - kein ISO
      und keine Dateifreigabe erforderlich.

    Aenderungen gegenueber v1.1.0:
      - Das Script endet immer mit Exit Code 0. Teilfehler werden protokolliert,
        beenden aber nicht die Custom Script Extension und damit nicht das
        ARM-Deployment.
      - Jeder DISM-Aufruf laeuft mit hartem Timeout und kann nicht mehr
        unbegrenzt blockieren.
      - Einheitlicher Pre-Check-Block inklusive Pruefung der
        Windows-Update-Quelle fuer optionale Inhalte.
      - Neustart ueber shutdown.exe mit Verzoegerung, damit die Extension
        ihren Status noch melden kann.
      - en-US wird nur entfernt, wenn de-DE nachweislich installiert ist.
      - Einheitliche Konsolenausgabe, ASCII-Quellcode, PowerShell 5.1/7.x.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 30.03.2026
    Modified    : 27.08.2026
    Version     : 2.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Zielplattform : Windows 11 Enterprise Multi-Session (AVD Session Host)
    Gegenstueck   : Setup-DeOnly-WS.ps1 (Windows Server 2025 Datacenter)
    Logfile       : C:\Windows\Temp\cse-setup-avd.log
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Setup-DeOnly-AVD.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - alle Parameter fest im Script hinterlegt
# =============================================================================
$PowerShellMode          = "Compat"      # "Compat" = 5.1 + 7.x | "Seven" = nur 7.x

# Sprache und Region
$LanguageTag             = "de-DE"
$LanguageTagLower        = "de-de"
$GeoId                   = 94            # 94 = Deutschland
$InputLocaleAdd          = "0407:00000407"
$InputLocaleRemove       = "0409:00000409"
$TimeZoneId              = "W. Europe Standard Time"
$RemoveEnUsLanguage      = $true

# Sprachpaket-Installation
$DismTimeoutSeconds      = 600           # Hartes Timeout je DISM-Aufruf

# Systemkonfiguration
$InstallPath             = "C:\Tools"
$EnableWinRMRemoting     = $true
$AutoReboot              = $true
$RebootDelaySeconds      = 120

$LogFile                 = "C:\Windows\Temp\cse-setup-avd.log"

# =============================================================================
# [ INITIALISIERUNG ]
# =============================================================================
$ErrorActionPreference = "Continue"

try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

# Symbole zur Laufzeit erzeugen - Quellcode bleibt reines ASCII
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

$Script:Summary = @()

function Write-Line {
    param([string]$Text, [string]$Color = "White", [int]$Indent = 0)
    $pad = " " * $Indent
    Write-Host ($pad + $Text) -ForegroundColor $Color
    try { Add-Content -Path $LogFile -Value ($pad + $Text) -Encoding UTF8 } catch { }
}
function Write-Sep     { Write-Line ("=" * 60) "White" }
function Write-Section { param([string]$Name) Write-Sep; Write-Line ("[ " + $Name + " ]") "White"; }
function Get-Stamp     { return "[" + (Get-Date -Format "HH:mm:ss") + "] " }
function Write-Ok      { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymOk   + "  " + $Text) "Green"  $Indent }
function Write-Err     { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymErr  + "  " + $Text) "Red"    $Indent }
function Write-Warn    { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymWarn + "  " + $Text) "Yellow" $Indent }
function Write-Info    { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymInfo + "  " + $Text) "Cyan"   $Indent }
function Write-Run     { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymRun  + "  " + $Text) "Cyan"   $Indent }

# Externe Programme immer ueber den Exit Code pruefen, nie ueber try/catch allein
function Assert-NativeSuccess {
    param(
        [string]$Context,
        [int]$ExitCode = $LASTEXITCODE,
        [int[]]$AllowedCodes = @(0)
    )
    if ($AllowedCodes -contains $ExitCode) {
        Write-Ok ($Context + " erfolgreich (ExitCode " + $ExitCode + ")") 4
        return $true
    }
    Write-Warn ($Context + " fehlgeschlagen (ExitCode " + $ExitCode + ")") 4
    return $false
}

# Wrapper fuer dism.exe: Argumente als Array, stderr unterdrueckt, hartes Timeout
function Invoke-DismQuiet {
    param(
        [string[]]$DismArguments,
        [int]$TimeoutSeconds = 600,
        [string]$Context = "DISM"
    )
    $runId    = [guid]::NewGuid().ToString()
    $outFile  = Join-Path $env:TEMP ("dism-out-" + $runId + ".txt")
    $errFile  = Join-Path $env:TEMP ("dism-err-" + $runId + ".txt")
    $exitCode = -1

    try {
        $procItem = Start-Process -FilePath "dism.exe" -ArgumentList $DismArguments `
            -NoNewWindow -PassThru `
            -RedirectStandardOutput $outFile -RedirectStandardError $errFile
        if (-not $procItem.WaitForExit($TimeoutSeconds * 1000)) {
            Write-Err ($Context + ": Timeout nach " + $TimeoutSeconds + "s - Prozess wird beendet") 4
            try { Stop-Process -Id $procItem.Id -Force -ErrorAction SilentlyContinue } catch { }
            return $false
        }
        $exitCode = $procItem.ExitCode
    } catch {
        Write-Err ($Context + ": Start fehlgeschlagen - " + $_.Exception.Message) 4
        return $false
    } finally {
        Remove-Item -Path $outFile -Force -ErrorAction SilentlyContinue
        Remove-Item -Path $errFile -Force -ErrorAction SilentlyContinue
    }

    # 0 = OK, 3010 = OK, Neustart erforderlich
    return (Assert-NativeSuccess -Context $Context -ExitCode $exitCode -AllowedCodes @(0, 3010))
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Sep
Write-Line "[ SETUP-DEONLY-AVD 2.0.0 - WINDOWS 11 MULTI-SESSION ]" "White"
Write-Section "PRE-CHECK"

$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
Write-Info ("PowerShell : " + $PSVersionTable.PSVersion.ToString())
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) {
    Write-Err "PowerShellMode 'Seven' erfordert PowerShell 7.x - Abbruch."
    exit 0
}
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Info "PSNativeCommandUseErrorActionPreference deaktiviert" 4
}
Write-Ok ("Modus      : " + $PowerShellMode) 4

$osInfo = Get-CimInstance -ClassName Win32_OperatingSystem
Write-Info ("Computer   : " + $env:COMPUTERNAME)
Write-Info ("Benutzer   : " + $env:USERDOMAIN + "\" + $env:USERNAME)
Write-Info ("OS         : " + $osInfo.Caption + " (Build " + $osInfo.BuildNumber + ")")
if ($osInfo.ProductType -ne 1) {
    Write-Warn "Dies ist eine Server-SKU. Fuer Windows Server bitte Setup-DeOnly-WS.ps1 verwenden." 4
} else {
    Write-Ok "SKU-Typ    : Client (Multi-Session)" 4
}

$currentIdentity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$currentPrincipal = New-Object System.Security.Principal.WindowsPrincipal($currentIdentity)
if (-not $currentPrincipal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Err "Keine administrativen Rechte - Abbruch."
    exit 0
}
Write-Ok "Rechte     : elevated" 4
Write-Info ("Logfile    : " + $LogFile) 4

# FOD-Bezug direkt von Windows Update freischalten
Write-Run "Pruefe Windows-Update-Quelle fuer optionale Inhalte..." 4

$servicingKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Servicing"
try {
    if (-not (Test-Path $servicingKey)) { New-Item -Path $servicingKey -Force | Out-Null }
    New-ItemProperty -Path $servicingKey -Name "RepairContentServerSource" -Value 2 -PropertyType DWord -Force | Out-Null
    Write-Ok "RepairContentServerSource = 2 (direkt von Windows Update)" 8
} catch {
    Write-Warn ("RepairContentServerSource nicht setzbar: " + $_.Exception.Message) 8
}

$auKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
try {
    if (Test-Path $auKey) {
        $useWuServer = (Get-ItemProperty -Path $auKey -Name "UseWUServer" -ErrorAction SilentlyContinue).UseWUServer
        if ($useWuServer -eq 1) {
            Set-ItemProperty -Path $auKey -Name "UseWUServer" -Value 0 -Force
            Write-Warn "UseWUServer war 1 (WSUS) - auf 0 gesetzt" 8
        } else {
            Write-Ok "Keine WSUS-Umleitung aktiv" 8
        }
    } else {
        Write-Ok "Keine WindowsUpdate-Policy vorhanden" 8
    }
} catch {
    Write-Warn ("UseWUServer-Pruefung fehlgeschlagen: " + $_.Exception.Message) 8
}

try {
    $wuService = Get-Service -Name "wuauserv" -ErrorAction Stop
    if ($wuService.StartType -eq "Disabled") {
        Set-Service -Name "wuauserv" -StartupType Manual
        Write-Warn "wuauserv war deaktiviert - auf Manual gesetzt" 8
    }
    if ($wuService.Status -ne "Running") {
        Start-Service -Name "wuauserv"
        Write-Ok "wuauserv gestartet" 8
    } else {
        Write-Ok "wuauserv laeuft" 8
    }
} catch {
    Write-Warn ("wuauserv nicht verfuegbar: " + $_.Exception.Message) 8
}

$wuReachable = $false
try {
    $tcpTest = Test-NetConnection -ComputerName "fe2cr.update.microsoft.com" -Port 443 -WarningAction SilentlyContinue -InformationLevel Quiet
    $wuReachable = [bool]$tcpTest
} catch { }
if ($wuReachable) { Write-Ok "Windows Update (443) erreichbar" 8 }
else              { Write-Warn "Windows Update nicht erreichbar - Sprachpaket-Installation wird scheitern" 8 }

# =============================================================================
# [ SCHRITT 1 ] Offline-Datentraeger online schalten
# =============================================================================
Write-Section "SCHRITT 1 - DATENTRAEGER ONLINE"
try {
    $offlineDisks = @(Get-Disk | Where-Object { $_.OperationalStatus -eq "Offline" })
    if ($offlineDisks.Count -eq 0) {
        Write-Ok "Keine Offline-Datentraeger vorhanden" 4
    } else {
        foreach ($diskItem in $offlineDisks) {
            Write-Run ("Setze Disk " + $diskItem.Number + " online...") 4
            Set-Disk -Number $diskItem.Number -IsOffline $false
            Set-Disk -Number $diskItem.Number -IsReadOnly $false
            Write-Ok ("Disk " + $diskItem.Number + " ist online") 8
        }
    }
    $Script:Summary += "Schritt 1 (Disks online)       : OK"
} catch {
    Write-Err ("Fehlgeschlagen: " + $_.Exception.Message) 4
    $Script:Summary += "Schritt 1 (Disks online)       : FEHLER"
}

# =============================================================================
# [ SCHRITT 2 ] RAW-Datentraeger initialisieren
# =============================================================================
Write-Section "SCHRITT 2 - RAW-DATENTRAEGER INITIALISIEREN"
try {
    $rawDisks = @(Get-Disk | Where-Object { $_.PartitionStyle -eq "RAW" -and $_.IsSystem -eq $false })
    if ($rawDisks.Count -eq 0) {
        Write-Ok "Keine RAW-Datentraeger vorhanden" 4
    } else {
        foreach ($diskItem in $rawDisks) {
            Write-Run ("Initialisiere Disk " + $diskItem.Number + " (" + [math]::Round($diskItem.Size / 1GB, 0) + " GB)...") 4
            Initialize-Disk -Number $diskItem.Number -PartitionStyle GPT
            $partItem = New-Partition -DiskNumber $diskItem.Number -AssignDriveLetter -UseMaximumSize
            $volLabel = "DataDisk" + $diskItem.Number
            Format-Volume -DriveLetter $partItem.DriveLetter -FileSystem NTFS -NewFileSystemLabel $volLabel -Confirm:$false | Out-Null
            Write-Ok ("Disk " + $diskItem.Number + " -> " + $partItem.DriveLetter + ": (" + $volLabel + ")") 8
        }
    }
    $Script:Summary += "Schritt 2 (RAW-Disks)          : OK"
} catch {
    Write-Err ("Fehlgeschlagen: " + $_.Exception.Message) 4
    $Script:Summary += "Schritt 2 (RAW-Disks)          : FEHLER"
}

# =============================================================================
# [ SCHRITT 3 ] Deutsches Sprachpaket via DISM
# =============================================================================
Write-Section "SCHRITT 3 - SPRACHPAKET $LanguageTag"

$languageOk = $false

# --- Schritt 3a: Cleanup-Tasks deaktivieren --------------------------------
# Windows entfernt Sprachpakete, die es als "unbenutzt" einstuft, nach einem
# Neustart wieder. Das muss vor der Installation unterbunden werden.
Write-Run "Deaktiviere LXP-/LP-Cleanup-Tasks..." 4
Disable-ScheduledTask -TaskPath "\Microsoft\Windows\AppxDeploymentClient\"       -TaskName "Pre-staged app cleanup" -ErrorAction SilentlyContinue | Out-Null
Disable-ScheduledTask -TaskPath "\Microsoft\Windows\MUI\"                        -TaskName "LPRemove"               -ErrorAction SilentlyContinue | Out-Null
Disable-ScheduledTask -TaskPath "\Microsoft\Windows\LanguageComponentsInstaller\" -TaskName "Uninstallation"         -ErrorAction SilentlyContinue | Out-Null
try {
    $intlPolicyKey = "HKLM:\SOFTWARE\Policies\Microsoft\Control Panel\International"
    if (-not (Test-Path $intlPolicyKey)) { New-Item -Path $intlPolicyKey -Force | Out-Null }
    New-ItemProperty -Path $intlPolicyKey -Name "BlockCleanupOfUnusedPreinstalledLangPacks" -Value 1 -PropertyType DWord -Force | Out-Null
    Write-Ok "BlockCleanupOfUnusedPreinstalledLangPacks = 1" 8
} catch {
    Write-Warn ("Policy nicht setzbar: " + $_.Exception.Message) 8
}

# --- Schritt 3b: FOD-Capabilities via DISM ---------------------------------
# DISM /Add-Capability ohne /LimitAccess bezieht die Pakete direkt von
# Windows Update. Install-Language wird fuer gepoolte Multi-Session Host
# Pools von Microsoft nicht unterstuetzt.
if ($wuReachable) {
    Write-Run "Installiere Sprach-Capabilities via DISM..." 4

    $basicCapability = "Language.Basic~~~" + $LanguageTagLower + "~0.0.1.0"
    $basicOk = Invoke-DismQuiet -DismArguments @(
        "/Online", "/Add-Capability", ("/CapabilityName:" + $basicCapability), "/NoRestart", "/Quiet"
    ) -TimeoutSeconds $DismTimeoutSeconds -Context ("DISM " + $basicCapability)

    if ($basicOk) {
        $languageOk = $true
        # Basic ist Voraussetzung fuer alle weiteren Capabilities
        $optionalCapabilities = @(
            ("Language.Handwriting~~~"  + $LanguageTagLower + "~0.0.1.0"),
            ("Language.OCR~~~"          + $LanguageTagLower + "~0.0.1.0"),
            ("Language.Speech~~~"       + $LanguageTagLower + "~0.0.1.0"),
            ("Language.TextToSpeech~~~" + $LanguageTagLower + "~0.0.1.0")
        )
        foreach ($capName in $optionalCapabilities) {
            Invoke-DismQuiet -DismArguments @(
                "/Online", "/Add-Capability", ("/CapabilityName:" + $capName), "/NoRestart", "/Quiet"
            ) -TimeoutSeconds $DismTimeoutSeconds -Context ("DISM " + $capName) | Out-Null
        }
    } else {
        Write-Warn "Language.Basic fehlgeschlagen - abhaengige Capabilities uebersprungen" 8
    }
} else {
    Write-Warn "DISM-Pfad uebersprungen - Windows Update nicht erreichbar" 4
}

# Ergebnis gegenpruefen
try {
    Import-Module LanguagePackManagement -ErrorAction Stop
    $installedLang = @(Get-InstalledLanguage -ErrorAction Stop | Where-Object { $_.LanguageId -eq $LanguageTag })
    if ($installedLang.Count -gt 0) { $languageOk = $true }
} catch { }

if ($languageOk) {
    Write-Ok ("Sprachpaket " + $LanguageTag + " verfuegbar") 4
    $Script:Summary += "Schritt 3 (Sprachpaket)        : OK"
} else {
    Write-Warn "Sprachpaket nicht installiert - Locale/Region werden trotzdem gesetzt" 4
    $Script:Summary += "Schritt 3 (Sprachpaket)        : UEBERSPRUNGEN"
}

# =============================================================================
# [ SCHRITT 4 ] Locale, UI-Sprache, Tastatur und Region
# =============================================================================
Write-Section "SCHRITT 4 - LOCALE UND REGION"

try {
    Set-WinSystemLocale -SystemLocale $LanguageTag
    Write-Ok ("SystemLocale = " + $LanguageTag) 4
} catch { Write-Warn ("Set-WinSystemLocale: " + $_.Exception.Message) 4 }

if ($languageOk) {
    try {
        Set-WinUILanguageOverride -Language $LanguageTag
        Write-Ok ("UILanguageOverride = " + $LanguageTag) 4
    } catch { Write-Warn ("Set-WinUILanguageOverride: " + $_.Exception.Message) 4 }
} else {
    Write-Info "UILanguageOverride uebersprungen (kein Sprachpaket vorhanden)" 4
}

try {
    Set-Culture -CultureInfo $LanguageTag
    Set-WinHomeLocation -GeoId $GeoId
    Write-Ok ("Culture = " + $LanguageTag + ", GeoId = " + $GeoId + " (Deutschland)") 4
} catch { Write-Warn ("Set-Culture / Set-WinHomeLocation: " + $_.Exception.Message) 4 }

try {
    $langList = New-WinUserLanguageList $LanguageTag
    $langList[0].InputMethodTips.Clear()
    $langList[0].InputMethodTips.Add($InputLocaleAdd)
    Set-WinUserLanguageList $langList -Force
    Write-Ok ("Sprachliste = " + $LanguageTag + ", Tastatur = " + $InputLocaleAdd) 4
} catch { Write-Warn ("Set-WinUserLanguageList: " + $_.Exception.Message) 4 }

# intl.cpl uebertraegt die Einstellungen auf das Default-User-Profil und das
# SYSTEM-Konto (LogonUI, Sperrbildschirm). XML muss UTF-8 ohne BOM sein.
try {
    $intlXml = @"
<?xml version="1.0" encoding="UTF-8"?>
<gs:GlobalizationServices xmlns:gs="urn:longhornGlobalizationUnattend">
  <gs:UserList>
    <gs:User UserID="Current"
             CopySettingsToDefaultUserAcct="true"
             CopySettingsToSystemAcct="true"/>
  </gs:UserList>
  <gs:LocationPreferences>
    <gs:GeoID Value="$GeoId"/>
  </gs:LocationPreferences>
  <gs:MUILanguagePreferences>
    <gs:MUILanguage Value="$LanguageTag"/>
  </gs:MUILanguagePreferences>
  <gs:SystemLocale Name="$LanguageTag"/>
  <gs:InputPreferences>
    <gs:InputLanguageID Action="remove" ID="$InputLocaleRemove"/>
    <gs:InputLanguageID Action="add"    ID="$InputLocaleAdd" Default="true"/>
  </gs:InputPreferences>
  <gs:UserLocale>
    <gs:Locale Name="$LanguageTag" SetAsCurrent="true" ResetAllSettings="true"/>
  </gs:UserLocale>
</gs:GlobalizationServices>
"@
    $xmlPath = Join-Path $env:TEMP "de-DE-intl.xml"
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($xmlPath, $intlXml, $utf8NoBom)

    $intlProc = Start-Process -FilePath "control.exe" `
        -ArgumentList ("intl.cpl,,/f:`"" + $xmlPath + "`"") -Wait -PassThru
    Assert-NativeSuccess -Context "intl.cpl" -ExitCode $intlProc.ExitCode | Out-Null
    Write-Ok "Einstellungen auf DefaultUser und SYSTEM uebernommen" 8
    Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue
} catch {
    Write-Warn ("intl.cpl fehlgeschlagen: " + $_.Exception.Message) 4
}

# en-US entfernen, damit Windows die EN-Tastatur beim Anmelden nicht neu setzt
if ($RemoveEnUsLanguage -and $languageOk) {
    try {
        $enPack = @(Get-InstalledLanguage -ErrorAction Stop | Where-Object { $_.LanguageId -eq "en-US" })
        if ($enPack.Count -gt 0) {
            Uninstall-Language -Language "en-US" -ErrorAction Stop
            Write-Ok "Sprachpaket en-US entfernt" 4
        } else {
            Write-Info "Sprachpaket en-US nicht vorhanden" 4
        }
    } catch {
        Write-Warn ("Entfernen von en-US fehlgeschlagen (nicht kritisch): " + $_.Exception.Message) 4
    }
} elseif ($RemoveEnUsLanguage) {
    Write-Warn "en-US wird NICHT entfernt - ohne de-DE waere das System sonst ohne UI-Sprache" 4
}

$Script:Summary += "Schritt 4 (Locale/Region)      : OK"

# =============================================================================
# [ SCHRITT 5 ] Zeitzone
# =============================================================================
Write-Section "SCHRITT 5 - ZEITZONE"
try {
    Set-TimeZone -Id $TimeZoneId
    Write-Ok ("Zeitzone = " + $TimeZoneId) 4
    $Script:Summary += "Schritt 5 (Zeitzone)           : OK"
} catch {
    Write-Warn ("Set-TimeZone: " + $_.Exception.Message) 4
    $Script:Summary += "Schritt 5 (Zeitzone)           : FEHLER"
}

# =============================================================================
# [ SCHRITT 6 ] WinRM aktivieren
# =============================================================================
Write-Section "SCHRITT 6 - WINRM"
if ($EnableWinRMRemoting) {
    try {
        Enable-PSRemoting -Force -SkipNetworkProfileCheck | Out-Null
        Set-Item WSMan:\localhost\MaxEnvelopeSizekb -Value 8192
        Write-Ok "PSRemoting aktiviert, MaxEnvelopeSizekb = 8192" 4
        $Script:Summary += "Schritt 6 (WinRM)              : OK"
    } catch {
        Write-Warn ("WinRM-Konfiguration fehlgeschlagen: " + $_.Exception.Message) 4
        $Script:Summary += "Schritt 6 (WinRM)              : FEHLER"
    }
} else {
    Write-Info "Uebersprungen (EnableWinRMRemoting = false)" 4
}

# =============================================================================
# [ SCHRITT 7 ] Installationsverzeichnis
# =============================================================================
Write-Section "SCHRITT 7 - INSTALLATIONSVERZEICHNIS"
try {
    if (-not (Test-Path $InstallPath)) {
        New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
        Write-Ok ("Angelegt: " + $InstallPath) 4
    } else {
        Write-Ok ("Bereits vorhanden: " + $InstallPath) 4
    }
    $Script:Summary += "Schritt 7 (Verzeichnis)        : OK"
} catch {
    Write-Warn ("Anlegen fehlgeschlagen: " + $_.Exception.Message) 4
    $Script:Summary += "Schritt 7 (Verzeichnis)        : FEHLER"
}

# =============================================================================
# [ SCHRITT 8 ] Platzhalter fuer eigene Anwendungsinstallation
# =============================================================================
Write-Section "SCHRITT 8 - ANWENDUNGEN"
Write-Info "Platzhalter - keine Aktion" 4
# Eigene Installationslogik hier ergaenzen, z. B.:
# Invoke-WebRequest -Uri "https://example.com/app.msi" -OutFile (Join-Path $InstallPath "app.msi") -UseBasicParsing
# $msiProc = Start-Process msiexec.exe -ArgumentList ("/i `"" + (Join-Path $InstallPath "app.msi") + "`" /quiet /norestart") -Wait -PassThru
# Assert-NativeSuccess -Context "MSI-Installation" -ExitCode $msiProc.ExitCode -AllowedCodes @(0, 3010) | Out-Null

# =============================================================================
# [ ZUSAMMENFASSUNG ]
# =============================================================================
Write-Section "ZUSAMMENFASSUNG"
foreach ($summaryLine in $Script:Summary) { Write-Info $summaryLine 4 }
Write-Info ("Logfile: " + $LogFile) 4
Write-Ok "Post-Deployment abgeschlossen" 4

if ($AutoReboot) {
    Write-Run ("Neustart in " + $RebootDelaySeconds + " Sekunden zur Uebernahme der Spracheinstellungen") 4
    # shutdown.exe statt Restart-Computer: das Script kann beenden und die
    # Custom Script Extension ihren Status melden, bevor die VM neu startet.
    & shutdown.exe /r /t $RebootDelaySeconds /c "Post-Deployment: Neustart zur Uebernahme der Spracheinstellungen"
    Assert-NativeSuccess -Context "shutdown.exe" | Out-Null
} else {
    Write-Warn "Automatischer Neustart deaktiviert - bitte manuell neu starten" 4
}
Write-Sep

# Die Custom Script Extension darf das ARM-Deployment nicht zum Scheitern
# bringen. Teilfehler sind im Logfile und in der Zusammenfassung dokumentiert.
exit 0
