﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Cleanup/Rollback fuer das AVD-Deployment - entfernt die vom Runner erzeugten Pool-Objekte.
.DESCRIPTION
    Liest dieselbe avd-config.json wie der Runner und entfernt gezielt nur die pro Host Pool
    angelegten Objekte und Einstellungen:
      - Session Hosts (falls vorhanden, in der Ziel-RG sessionhost.targetResourceGroup bzw. Pool-RG),
        Private Endpoints (Feed/Connection), App Group,
        Workspace, Host Pool, NSG (inkl. Subnet-Bindung), PE-Subnet, Pool-Resource-Group
      - sowie der vom Deployment ergaenzte Address Space im Local Network Gateway (nur dieser eine Eintrag, symmetrisch zum Deployment)
    BEWUSST ERHALTEN bleiben die zentralen/geteilten Services:
      - DNS Private Zones und deren VNet-Links
      - Log Analytics Workspace
      - der geteilte Global-Endpoint 'PE-AVD-global' (inkl. dessen Subnet/Pool-RG, falls er dort liegt)
      - ein evtl. eigener Key Vault (Passwort-Secrets) sowie eine abweichende Session-Host-Ziel-RG (koennen geteilt/vorbestehend sein)
    Hinweis: Die DNS-Zone-Group eines PE (und damit dessen A-Records in der Zone) ist ein Kind-Objekt
    des PE und wird beim PE-Delete automatisch mit entfernt - daher keine separate Record-Loeschung.
    Fuer einen KOMPLETTEN Abriss (letztes/einziges AVD im Sub) entfernt '-RemoveGlobal' auch den
    geteilten Global-Endpoint (Vorsicht: bricht Feed-Discovery fuer ALLE anderen AVD-Ressourcen).
    Azure CLI in PowerShell (keine Az-Module). Best-effort: nicht vorhandene Objekte werden
    uebersprungen, ein einzelner Fehler bricht das Cleanup nicht ab.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-06-17
    Version     : 1.4.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\AVD-Cleanup.ps1 -ConfigFile .\avd-config_HostPoolAO2_2026-06-29.json
.EXAMPLE
    .\AVD-Cleanup.ps1 -ConfigFile .\avd-config_HostPoolAO2_2026-06-29.json -WhatIf
.EXAMPLE
    .\AVD-Cleanup.ps1 -ConfigFile .\avd-config_HostPoolAO2_2026-06-29.json -Force
.EXAMPLE
    .\AVD-Cleanup.ps1 -ConfigFile .\avd-config_HostPoolAO2_2026-06-29.json -RemoveGlobal
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$ConfigFile,
    [switch]$WhatIf,       # Nur anzeigen was entfernt wuerde, nichts ausfuehren
    [switch]$Force,        # Sicherheitsabfrage ueberspringen
    [switch]$RemoveGlobal  # NUR fuer kompletten Abriss: auch den geteilten Global-Endpoint entfernen
)

# UTF-8 Ausgabe (fuer Symbole/Emoji in der Konsole)
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

# ============================================================
#  LOGGING / AUSGABE
# ============================================================
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logFile = "$PSScriptRoot\AVD-Cleanup_$timestamp.log"
$failed  = @()   # Objekte, die nicht entfernt werden konnten
$kept    = @()   # bewusst erhaltene Objekte

function Write-Log {
    param([string]$Message,[ValidateSet("INFO","WARN","ERROR","OK","STEP")][string]$Level="INFO")
    $ts = Get-Date -Format "HH:mm:ss"
    switch ($Level) {
        "OK"    { $sym = "✅"; $col = "Green" }
        "ERROR" { $sym = "❌"; $col = "Red" }
        "WARN"  { $sym = "⚠️ "; $col = "Yellow" }
        "STEP"  { $sym = "🔄"; $col = "Cyan" }
        default { $sym = "ℹ️ "; $col = "Cyan" }
    }
    Write-Host "[$ts] $sym $Message" -ForegroundColor $col
    Add-Content -Path $logFile -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [$Level] $Message"
}
function Write-Divider { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section { param([string]$T); Write-Host ""; Write-Divider; Write-Host "[ $T ]" -ForegroundColor White; Write-Divider }

# Entfernt eine Ressource. "Not found" gilt als Erfolg (idempotent). Bricht NICHT ab.
function Remove-Az {
    param([string]$Desc,[scriptblock]$Cmd)
    if ($WhatIf) { Write-Log "[WhatIf] Wuerde entfernen: $Desc" "INFO"; return }
    Write-Log "Entferne: $Desc" "STEP"
    $out = & $Cmd 2>&1
    if ($LASTEXITCODE -ne 0) {
        $msg = ($out | Out-String).Trim()
        if ($msg -match "(?i)not ?found|could not be found|ResourceNotFound|does not exist|was not found|wurde nicht gefunden") {
            Write-Log "Bereits entfernt / nicht vorhanden: $Desc" "OK"
        } else {
            Write-Log "Konnte nicht entfernen: $Desc" "WARN"
            foreach ($ln in ($msg -split "`r?`n")) { if ($ln.Trim()) { Write-Host "    $($ln.Trim())" -ForegroundColor DarkYellow } }
            Add-Content -Path $logFile -Value "[Fehler] $Desc :: $msg"
            $script:failed += $Desc
        }
    } else { Write-Log "Entfernt: $Desc" "OK" }
}

Write-Section "AVD CLEANUP / ROLLBACK"
Write-Log "Logfile: $logFile" "INFO"

# ============================================================
#  PRE-CHECK
# ============================================================
Write-Section "PRE-CHECK"

# 1) Azure CLI vorhanden?
Write-Log "Pruefe Azure CLI..." "INFO"
$azVersion = az version 2>$null | ConvertFrom-Json -ErrorAction SilentlyContinue
if (-not $azVersion) { Write-Log "Azure CLI nicht gefunden. Bitte installieren: https://aka.ms/installazurecli" "ERROR"; exit 1 }
$azCli = $azVersion.'azure-cli'
Write-Log "Azure CLI gefunden: $azCli" "OK"

# 2) Azure CLI aktuell?
$azMin = "2.50.0"
try {
    if ([version]$azCli -lt [version]$azMin) { Write-Log "Aeltere CLI-Version ($azCli < $azMin). 'az upgrade' empfohlen." "WARN" }
    else { Write-Log "CLI-Version ist aktuell genug." "OK" }
} catch { Write-Log "Versionsvergleich nicht moeglich - Hinweis: 'az upgrade'." "WARN" }

# 3) Config laden
if (-not (Test-Path $ConfigFile)) { Write-Log "Config-Datei '$ConfigFile' nicht gefunden." "ERROR"; exit 1 }
try {
    $c = Get-Content $ConfigFile -Raw | ConvertFrom-Json
    Write-Log "Config geladen: $ConfigFile" "OK"
} catch { Write-Log "Config-Datei ist kein gueltiges JSON: $($_.Exception.Message)" "ERROR"; exit 1 }

# Logfile auf Host-Pool-Namen umstellen
if ($c.hostpool -and $c.hostpool.name) {
    $newLog = "$PSScriptRoot\AVD-Cleanup_$($c.hostpool.name)_$timestamp.log"
    if (Test-Path $logFile) { Move-Item -Path $logFile -Destination $newLog -Force -ErrorAction SilentlyContinue }
    $logFile = $newLog
}

# 4) Login vorhanden?
$account = az account show 2>$null | ConvertFrom-Json
if (-not $account) { Write-Log "Kein Azure-Login - starte 'az login'..." "WARN"; az login | Out-Null; $account = az account show 2>$null | ConvertFrom-Json }
if (-not $account) { Write-Log "Login fehlgeschlagen." "ERROR"; exit 1 }
Write-Log "Login vorhanden: $($account.user.name) / $($account.name)" "OK"

# 5) Extension (fuer hostpool/workspace/appgroup delete)
if (-not (az extension list --query "[?name=='desktopvirtualization']" 2>$null | ConvertFrom-Json)) {
    Write-Log "Installiere Extension 'desktopvirtualization'..." "INFO"
    az extension add --name desktopvirtualization 2>$null | Out-Null
}
if ($c.phases.sessionhost) {
    if (-not (az extension list --query "[?name=='stack-hci-vm']" 2>$null | ConvertFrom-Json)) {
        Write-Log "Installiere Extension 'stack-hci-vm'..." "INFO"
        az extension add --name stack-hci-vm 2>$null | Out-Null
    }
}

# ============================================================
#  VARIABLEN / NAMEN (identisch zum Runner hergeleitet)
# ============================================================
$rg       = $c.general.resourceGroup
$vnet     = $c.general.vnet
$vnetRg   = $c.general.vnetResourceGroup
$rgDns    = $c.dns.rgDns

if (-not $rg)   { Write-Log "general.resourceGroup (Pool-RG) fehlt in der Config." "ERROR"; exit 1 }
if (-not $vnetRg) { $vnetRg = $rg }

$hpName  = $c.hostpool.name
$wsName  = $c.workspace.name
$agName  = $c.appgroup.name
$snName  = $c.subnet.name
$nsgName = "nsg-$snName"
$peFeed  = "PE-AVD-$wsName-feed"
$peConn  = "PE-AVD-$hpName"
$peGlob  = "PE-AVD-global"

# Ziel-RG der Session Hosts (identisch zum Runner): sessionhost.targetResourceGroup, sonst Pool-RG.
# (Feld fehlt in aelteren Configs -> Fallback Pool-RG.)
$shRg = $rg
if ($c.sessionhost -and $c.sessionhost.PSObject.Properties['targetResourceGroup'] -and $c.sessionhost.targetResourceGroup) {
    $shRg = $c.sessionhost.targetResourceGroup
}
$shRgSeparate = ($shRg -ne $rg)   # liegt die Session-Host-RG ausserhalb der Pool-RG?

# Liegt der geteilte Global-Endpoint in DIESER Pool-RG? Dann RG + Subnet schonen.
$globalHere = [bool] (az network private-endpoint show --resource-group $rg --name $peGlob 2>$null | ConvertFrom-Json)

# Wurde ein VORHANDENES Subnet genutzt? Dann darf es NICHT geloescht werden.
# (Feld fehlt in aelteren Configs -> Standard $false = wurde neu erstellt)
$snUseExisting = $false
if ($null -ne $c.subnet.PSObject.Properties['useExisting']) { $snUseExisting = [bool]$c.subnet.useExisting }

# ============================================================
#  UEBERSICHT + SICHERHEITSABFRAGE
# ============================================================
Write-Section "ZU ENTFERNEN"
Write-Log "Pool Resource Group : $rg" "INFO"
Write-Log "Host Pool           : $hpName" "INFO"
Write-Log "Workspace           : $wsName" "INFO"
Write-Log "App Group           : $agName" "INFO"
if ($snUseExisting) {
    Write-Log "NSG                 : -  (vorhandenes Subnet: NSG bleibt unberuehrt)" "INFO"
} else {
    Write-Log "NSG                 : $nsgName  (im Pool-RG)" "INFO"
}
Write-Log "Private Endpoints   : $peFeed , $peConn" "INFO"
if ($snUseExisting) {
    Write-Log "PE-Subnet           : $snName  (VORHANDEN - bleibt erhalten)" "INFO"
} else {
    Write-Log "PE-Subnet           : $snName  (im VNet '$vnet' / RG '$vnetRg')" "INFO"
}
if ($c.phases.sessionhost -and $c.sessionhost -and $c.sessionhost.prefix) {
    $shLastNum = [int]$c.sessionhost.countStart + [int]$c.sessionhost.count - 1
    $shFirst = "$($c.sessionhost.prefix)-$((("$($c.sessionhost.countStart)")).PadLeft([int]$c.sessionhost.padding,'0'))"
    $shLast  = "$($c.sessionhost.prefix)-$((("$shLastNum")).PadLeft([int]$c.sessionhost.padding,'0'))"
    Write-Log "Session Hosts       : $shFirst .. $shLast  (Ziel-RG '$shRg', Azure Local)" "INFO"
}

Write-Section "BLEIBT ERHALTEN (zentral/geteilt)"
Write-Log "DNS Zones           : $($c.dns.zoneFeed) , $($c.dns.zoneGlobal)  (+ VNet-Links)" "OK"
Write-Log "Log Analytics       : $($c.loganalytics.name)  (RG '$($c.loganalytics.resourceGroup)')" "OK"
if ($snUseExisting) {
    Write-Log "PE-Subnet           : $snName  (vorhandenes Subnet - wird NICHT geloescht)" "OK"
}
if ($c.phases.sessionhost -and $shRgSeparate) {
    Write-Log "Session-Host-RG     : $shRg  (abweichende Ziel-RG - bleibt erhalten, nur die VMs werden entfernt)" "OK"
}
if ($RemoveGlobal) {
    Write-Log "Global-Endpoint     : $peGlob  -> WIRD ENTFERNT (-RemoveGlobal, kompletter Abriss!)" "WARN"
    Write-Log "    ACHTUNG: bricht Feed-Discovery fuer ALLE anderen AVD im Sub - nur beim letzten Deployment nutzen!" "WARN"
} else {
    Write-Log "Global-Endpoint     : $peGlob  (geteilt, bleibt erhalten - '-RemoveGlobal' fuer kompletten Abriss)" "OK"
    if ($globalHere) {
        Write-Log "ACHTUNG: '$peGlob' liegt in dieser Pool-RG '$rg'." "WARN"
        Write-Log "    -> PE-Subnet '$snName' und Pool-RG '$rg' werden daher NICHT geloescht." "WARN"
    }
}

if ($WhatIf) { Write-Host ""; Write-Log "WhatIf-Modus: es wird NICHTS entfernt." "WARN" }

if (-not $WhatIf -and -not $Force) {
    Write-Host ""
    Write-Host "Dies entfernt die oben gelisteten Objekte unwiderruflich." -ForegroundColor Yellow
    $confirm = Read-Host "Zum Bestaetigen den Host-Pool-Namen exakt eingeben ('$hpName')"
    if ($confirm -ne $hpName) { Write-Log "Abbruch durch Benutzer (keine Bestaetigung)." "WARN"; exit 0 }
}

# ============================================================
#  PHASE 6: SESSION HOSTS (falls vorhanden)
# ============================================================
if ($c.phases.sessionhost -and $c.sessionhost -and $c.sessionhost.prefix) {
    Write-Section "SESSION HOSTS"
    Write-Log "Session-Host-Ziel-RG: $shRg" "INFO"
    $names = @()
    for ($n = $c.sessionhost.countStart; $n -lt ($c.sessionhost.countStart + $c.sessionhost.count); $n++) {
        $names += "$($c.sessionhost.prefix)-$($n.ToString().PadLeft($c.sessionhost.padding,'0'))"
    }
    foreach ($vmName in $names) {
        if (az stack-hci-vm show --resource-group $shRg --name $vmName 2>$null | ConvertFrom-Json) {
            # Das VM-Delete entfernt auch die zugehoerigen run-command-Objekte (DomainJoin/InstallAVDAgent).
            Remove-Az "Session Host VM '$vmName' (RG '$shRg')" { az stack-hci-vm delete --resource-group $shRg --name $vmName --yes --output none }
        } else { Write-Log "VM '$vmName' nicht vorhanden in RG '$shRg' - uebersprungen." "OK" }
    }
    if ($shRgSeparate) {
        Write-Log "Abweichende Ziel-RG '$shRg' bleibt erhalten (kann geteilt/vorbestehend sein) - nur die VMs wurden entfernt." "WARN"
        $kept += "Session-Host-RG '$shRg' (abweichende Ziel-RG - nur VMs entfernt)"
    }
    Write-Log "Hinweis: Arc-Maschine/Gast-OS auf Azure Local ggf. separat bereinigen." "INFO"
}

# ============================================================
#  PRIVATE ENDPOINTS (Feed + Connection; Global bleibt!)
# ============================================================
Write-Section "PRIVATE ENDPOINTS"
Remove-Az "Private Endpoint '$peConn'" { az network private-endpoint delete --resource-group $rg --name $peConn --output none }
Remove-Az "Private Endpoint '$peFeed'" { az network private-endpoint delete --resource-group $rg --name $peFeed --output none }
if ($RemoveGlobal) {
    if ($globalHere) {
        Remove-Az "Global-Endpoint '$peGlob' (kompletter Abriss)" { az network private-endpoint delete --resource-group $rg --name $peGlob --output none }
        $globalHere = $false   # blockiert Subnet/Pool-RG damit nicht mehr
    } else {
        Write-Log "Global-Endpoint '$peGlob' liegt nicht in dieser Pool-RG - hier nichts zu entfernen." "INFO"
    }
} else {
    Write-Log "Global-Endpoint '$peGlob' bleibt unangetastet (DNS-Records der geloeschten PEs verschwinden mit der Zone-Group)." "OK"
}

# ============================================================
#  AVD-OBJEKTE (App Group, Workspace, Host Pool)
# ============================================================
Write-Section "AVD-OBJEKTE"
Remove-Az "App Group '$agName'"  { az desktopvirtualization applicationgroup delete --resource-group $rg --name $agName --yes --output none }
Remove-Az "Workspace '$wsName'"  { az desktopvirtualization workspace delete --resource-group $rg --name $wsName --yes --output none }
Remove-Az "Host Pool '$hpName'"  { az desktopvirtualization hostpool delete --resource-group $rg --name $hpName --force --yes --output none }

# ============================================================
#  NSG (Bindung loesen, dann loeschen)
# ============================================================
Write-Section "NSG-HAERTUNG ZURUECKNEHMEN"
if ($snUseExisting) {
    Write-Log "Vorhandenes Subnet -> NSG-Zuordnung wird NICHT geloest und keine NSG geloescht (fremde NSG bleibt unangetastet)." "WARN"
    $kept += "NSG-Zuordnung am vorhandenen Subnet '$snName'"
} else {
    if (az network vnet subnet show --resource-group $vnetRg --vnet-name $vnet --name $snName 2>$null | ConvertFrom-Json) {
        Remove-Az "NSG-Bindung von Subnet '$snName' loesen" { az network vnet subnet update --resource-group $vnetRg --vnet-name $vnet --name $snName --remove networkSecurityGroup --output none }
    }
    Remove-Az "NSG '$nsgName'" { az network nsg delete --resource-group $rg --name $nsgName --output none }
}

# ============================================================
#  LOCAL NETWORK GATEWAY (Zusatz-Subnet zurueckbauen)
# ============================================================
# Symmetrisch zum Deployment: nur der vom Deployment ergaenzte Address Space wird entfernt,
# und nur wenn der Auto-Eintrag genutzt wurde. Das LNG selbst bleibt unangetastet.
if ($c.PSObject.Properties['localGateway'] -and $c.localGateway.needsExtraSubnet -and $c.localGateway.extraSubnet `
    -and $c.localGateway.PSObject.Properties['autoUpdate'] -and $c.localGateway.autoUpdate `
    -and $c.localGateway.gatewayName -and $c.localGateway.gatewayResourceGroup) {
    Write-Section "LOCAL NETWORK GATEWAY"
    $lngName = $c.localGateway.gatewayName
    $lngRg   = $c.localGateway.gatewayResourceGroup
    $lngDel  = "$($c.localGateway.extraSubnet)".Trim()
    $lng = az network local-gateway show --resource-group $lngRg --name $lngName 2>$null | ConvertFrom-Json
    if (-not $lng) {
        Write-Log "Local Network Gateway '$lngName' (RG '$lngRg') nicht gefunden - nichts zurueckzubauen." "OK"
    } else {
        $existing = @($lng.localNetworkAddressSpace.addressPrefixes)
        if ($existing -notcontains $lngDel) {
            Write-Log "Address Space '$lngDel' ist nicht (mehr) im Gateway '$lngName' - keine Aenderung." "OK"
        } else {
            $remain = @($existing | Where-Object { $_ -ne $lngDel })
            if ($remain.Count -eq 0) {
                Write-Log "Address Space '$lngDel' waere der letzte Eintrag im Gateway '$lngName' - wird zur Sicherheit NICHT entfernt (LNG braucht mind. einen Address Space)." "WARN"
                $kept += "Address Space '$lngDel' im Local Network Gateway '$lngName' (letzter Eintrag - manuell pruefen)"
            } else {
                Write-Log "ACHTUNG: Local Network Gateway '$lngName' ist VPN-kritisch (geteilt)." "WARN"
                Remove-Az "Address Space '$lngDel' aus Gateway '$lngName' entfernen" {
                    az network local-gateway update --resource-group $lngRg --name $lngName --local-address-prefixes $remain --output none
                }
            }
        }
    }
}

# ============================================================
#  PE-SUBNET (nur wenn der Global-Endpoint NICHT hier liegt)
# ============================================================
# ============================================================
#  PE-SUBNET (nur loeschen, wenn neu erstellt UND Global-Endpoint nicht hier liegt)
# ============================================================
Write-Section "PE-SUBNET"
if ($snUseExisting) {
    Write-Log "PE-Subnet '$snName' bleibt erhalten (vorhandenes Subnet, useExisting=true)." "WARN"
    $kept += "PE-Subnet '$snName' (vorhandenes Subnet)"
} elseif ($globalHere) {
    Write-Log "PE-Subnet '$snName' bleibt erhalten (geteilter Global-Endpoint nutzt es)." "WARN"
    $kept += "PE-Subnet '$snName' (wegen Global-Endpoint)"
} else {
    Remove-Az "PE-Subnet '$snName'" { az network vnet subnet delete --resource-group $vnetRg --vnet-name $vnet --name $snName --output none }
}

# ============================================================
#  POOL-RESOURCE-GROUP (nur wenn der Global-Endpoint NICHT hier liegt)
# ============================================================
Write-Section "POOL-RESOURCE-GROUP"
if ($globalHere) {
    Write-Log "Pool-RG '$rg' bleibt erhalten (enthaelt den geteilten Global-Endpoint)." "WARN"
    $kept += "Pool-RG '$rg' (wegen Global-Endpoint)"
} else {
    if (az group exists --name $rg 2>$null | Select-String -Quiet "true") {
        Remove-Az "Pool-RG '$rg'" { az group delete --name $rg --yes --output none }
    } else { Write-Log "Pool-RG '$rg' nicht vorhanden - uebersprungen." "OK" }
}

# ============================================================
#  ABSCHLUSS
# ============================================================
Write-Section "ABSCHLUSS"
if ($WhatIf) {
    Write-Log "WhatIf-Lauf beendet - es wurde nichts veraendert." "OK"
} else {
    Write-Log "Cleanup abgeschlossen." "OK"
}
Write-Log "Erhalten: DNS-Zonen (+Links), Log Analytics, Global-Endpoint." "INFO"
if ($kept.Count -gt 0) { foreach ($k in $kept) { Write-Log "    Zusaetzlich erhalten: $k" "INFO" } }
if ($failed.Count -gt 0) {
    Write-Host ""
    Write-Divider
    Write-Host "[ NICHT ENTFERNT - BITTE PRUEFEN ]" -ForegroundColor Yellow
    Write-Divider
    $n = 1
    foreach ($f in $failed) { Write-Host "  $n. $f" -ForegroundColor Yellow; $n++ }
    Write-Host ""
}
Write-Log "Log: $logFile" "INFO"
