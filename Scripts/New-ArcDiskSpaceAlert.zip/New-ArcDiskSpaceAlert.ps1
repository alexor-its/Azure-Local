﻿#Requires -Version 5.1
<#
.SYNOPSIS
    SCHRITT 5 von 6 - Erstellt EINE E-Mail-Alert-Regel fuer mehrere Laufwerke
    aller Arc Windows Server. Server und Laufwerk erscheinen dynamisch im
    Mail-Betreff.
.DESCRIPTION
    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten (dieses Script)
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung
      Test-ArcDiskSpaceAlert.ps1  - Diagnose: warum kommt keine Mail

    AENDERUNG IN 5.9.1 - REGEL KORREKT, ABER KEINE MAIL
      Die Regel wurde in 5.9.0 fehlerfrei mit der regionalen Action Group
      angelegt - trotzdem kam keine Mail. Drei Ursachen, drei Korrekturen:

      (1) STATEFUL-FALLE (Hauptursache)
          Im AutoResolve-Modus ist die Regel STATEFUL: pro Instanz genau
          EINE Mail beim Uebergang auf 'Fired'. Instanzen, die BEREITS VOR
          der 5.9.0-Korrektur gefeuert haben - als die Action Group noch
          falsch verdrahtet war - stehen seither offen auf 'Fired'. Fuer
          eine offene Instanz verschickt Azure keine weitere Mail, egal
          wie oft die Regel per PUT neu geschrieben wird. Ein Laufwerk,
          das dauerhaft unter 15 % liegt, meldet sich also NIE, solange
          seine alte Instanz offen ist.
          Neu: Nach dem PUT prueft das Script die offenen Fired-Alarme
          der Regel. Stehen welche offen und $ResetAlertState = $true,
          wird die Regel kurz deaktiviert und reaktiviert. Das Deaktivieren
          loest die offenen Instanzen auf (dokumentiertes Verhalten
          stateful Regeln); bei der naechsten Auswertung feuern sie neu -
          diesmal MIT Mail an die korrekte Action Group.

      (2) ZUSTELLUNG WURDE NIE GEPRUEFT
          Bisher wurde nur der Receiver-Status gelesen. Neu: Stufe 6
          verschickt ueber die createNotifications-API eine ECHTE
          Testbenachrichtigung vom Typ 'logalertv2' ($TestActionGroup).
          Kommt die Test-Mail nicht an, liegt es an der Zustellung, nicht
          an der Regel: Absender (azure-noreply@microsoft.com u. a.) im
          Spamfilter freischalten, und NEUE Adressen muessen einmalig per
          One-Time-Passcode bestaetigt werden (Microsoft-Mail, 30 Minuten
          gueltig, gilt danach tenantweit). Nach dem Loeschen/Neuanlegen
          der Action Group in 5.8.x/5.9.0 leicht untergegangen.

      (3) BOM IM REGEL-BODY
          Der PUT-Body wurde mit 'Out-File -Encoding utf8' geschrieben -
          unter Windows PowerShell 5.1 MIT BOM. Genau das Problem, das
          KORREKTUR (7) fuer den PATCH laengst geloest hatte; unter 5.1
          scheiterte der PUT daran. Ausserdem wurde die Temp-Datei
          geloescht, BEVOR die Fehlermeldung auf sie verwies, und der
          Pfad lief ueber $env:TEMP statt GetTempPath().
          Neu: Hilfsfunktion Invoke-AzRestBody schreibt ALLE REST-Bodies
          als UTF-8 OHNE BOM und behaelt die Datei bei Fehlern fuer die
          Diagnose ($script:LastAzBodyFile). Set-AlertEmailSubject war
          seit 5.9.0 toter Code und ist entfernt.

    AENDERUNG IN 5.9.0 - ANLAGE PER 'az rest', REGIONALE ACTION GROUP
      In 5.8.1 hiess es hier, regionale Action Groups seien mit Log-Alerts
      nicht moeglich. Das war falsch. Die Einschraenkung liegt allein an der
      API-Version, die 'az monitor scheduled-query create' intern verwendet.
      New-ArcDisconnectAlert-ARG.ps1 macht es seit laengerem vor.
      - Die Regel wird per 'az rest --method put' auf $RuleApiVersion
        (2023-12-01) angelegt statt ueber das CLI-Kommando.
      - $ActionGroupLocation steht wieder auf "germanywestcentral".
      - Der Regelkoerper steht als JSON im Script: criteria.allOf mit
        metricMeasureColumn, resourceIdColumn und dimensions als Array.
        Die Dimensionsreihenfolge ist damit explizit statt aus einem
        Condition-String abgeleitet.
      - Betreff und Custom Properties gehen im selben PUT mit. Der
        nachgelagerte PATCH ueber Set-AlertEmailSubject entfaellt.
      - autoMitigate und muteActionsDuration schliessen sich weiterhin aus.
      - Die Endkontrolle liest ueber denselben API-Pfad, ueber den
        geschrieben wurde, und zeigt Dimensionen und Betreff mit an.

    AENDERUNG IN 5.8.3 - BEISPIELAUFLOESUNG IN DER ZUSAMMENFASSUNG
      Zwei Fehler, beide nur in der Anzeige - die Regel war nicht betroffen.
      - Der Zugriff auf die Probelauf-Spalten lief noch auf die alten Namen
        Laufwerk/Groesse/Frei. Seit 5.7.0 heissen sie Drive/Size/Free, der
        Zugriff lieferte still Leerstrings. Neu ueber Get-Spalte, das bei
        fehlender oder leerer Spalte den generischen Platzhalter behaelt.
      - .Replace() wirft eine Ausnahme, wenn oldValue leer ist. Get-DimToken
        liefert genau das fuer eine nicht aktive Dimension. Ersetzt wird
        jetzt ueber Expand-Token, das leere Tokens ueberspringt.
      - Betreff und Custom Properties nutzen dieselbe Ersetzungsliste, statt
        die Aufrufe doppelt zu fuehren.

    AENDERUNG IN 5.8.2 - FEHLERHAFTER AUFRUF VON Assert-AzSuccess
      In 5.8.0 wurde Assert-AzSuccess mit einem Text als erstem Argument
      aufgerufen. Die Signatur ist aber
        param([int]$ExitCode, [string]$ErrorText, [string]$Context)
      - PowerShell brach die Umwandlung nach [int] ab. Der Aufruf war
      ausserdem ueberfluessig: Invoke-AzQuiet prueft den Exitcode bereits
      und setzt $script:LastAzError. Die Erfolgskontrolle laeuft jetzt
      darueber. Der Rueckgabewert taugt dafuer nicht, weil 'delete' keine
      Ausgabe liefert und die Funktion dann auch bei Erfolg $null gibt.

    AENDERUNG IN 5.8.1 - RUECKNAHME DER REGIONALEN ACTION GROUP
      Eine Action Group in 'germanywestcentral' wird zwar angelegt, aber die
      Alert-Regel kann sie nicht referenzieren:
        "Referenced Action Group ... is in location 'germanywestcentral'.
         This api version only supports global Action Groups."
      Die Einschraenkung liegt bei der scheduledQueryRules-API. Ein Weg,
      Log-Alerts mit regionalen Action Groups zu verbinden, ist nicht belegt.
      - $ActionGroupLocation steht wieder auf "Global".
      - Die Vertraeglichkeit wird jetzt VOR der ersten Aenderung geprueft.
        In 5.8.0 wurde die Action Group zuerst umgebaut und erst danach die
        Regel angelegt - schlug die fehl, blieb ein Zwischenzustand zurueck.
      - Der Abgleichmechanismus bleibt erhalten: liegt die Action Group in
        einer anderen Region als $ActionGroupLocation, wird sie neu angelegt.
        Damit raeumt derselbe Lauf einen bestehenden Zwischenzustand auf.

    AENDERUNG IN 5.8.0 - ACTION GROUP IN GERMANY WEST CENTRAL
      - Ohne --location legt Azure eine Action Group in "Global" an. Neu:
        $ActionGroupLocation, Standard "germanywestcentral".
      - Die Region einer bestehenden Action Group ist NICHT aenderbar; ein
        PUT mit abweichender Location wird abgelehnt. Das Script erkennt die
        Abweichung, loescht die Action Group und legt sie in der Zielregion
        neu an ($RecreateActionGroupOnLocationChange). Die Ressourcen-ID
        bleibt dabei identisch, weil Name und Resource Group gleich bleiben -
        die Alert-Regel verweist weiterhin korrekt darauf.
      - Die Zusammenfassung zeigt die Region der Action Group.

      HINWEIS: $Location (Region der ALERT-REGEL, aktuell westeurope) ist
      davon unberuehrt und bleibt unveraendert.

    AENDERUNG IN 5.7.0 - DIMENSIONSINDIZES UND WERTE IN DER MAIL
      - Im Betreff stand bei 'volume size' die resourceId. Ursache: feste
        Indizes auf dimensions[]. Azure sortiert die Dimensionen offenbar
        alphabetisch nach Spaltenname, nicht in der Reihenfolge der
        Condition-Klausel - und "resource id resourceId" macht resourceId
        zu einer weiteren Dimension. Die Indizes werden jetzt aus der
        sortierten Namensliste BERECHNET.
        Ohne Zusatzdimensionen: [0] Computer [1] Drive [2] resourceId
        [3] Size. $DimensionOrder = "Condition" schaltet auf die alte
        Annahme zurueck, falls Azure das Verhalten aendert.
      - Betreff und Custom Property 'Free space' zeigen wieder Prozentwert
        und Plattengroesse. Beides ohne instabile Dimensionen: der Prozent-
        wert kommt aus metricValue, die Groesse aus der stabilen Dimension
        'Size'.
      - Die Zusammenfassung listet die verwendete Index-Zuordnung auf.

    AENDERUNG IN 5.6.0 - MAILINHALTE DURCHGAENGIG ENGLISCH
      Betroffen ist ausschliesslich, was beim Empfaenger ankommt. Die
      Konsolenausgabe des Scripts bleibt deutsch.
      - Anzeigename, Description, Betreff und Custom Properties auf Englisch.
      - Dimensionsnamen sind Spaltennamen der Query und erscheinen so im
        Abschnitt 'Dimensions' der Mail: Groesse/Prozent/Frei heissen jetzt
        Size/Percent/Free, 'unbekannt' heisst 'unknown'.
      - $SubjectConditionMode steht auf "Token" (Fired / Resolved von Azure).
        Alternative "Fixed" nutzt $SubjectFixedState als festen Text.

    AENDERUNG IN 5.5.0 - RUECKNAHME DER DIMENSIONEN AUS 5.3.0 / 5.4.0
      Die Dimensionen 'Prozent' und 'Frei' haben FALSCHE ENTWARNUNGEN
      erzeugt: Wechselt der gerundete Prozentwert von 6 auf 7, ist das fuer
      Azure eine andere Alert-Instanz; die alte wird aufgeloest und
      verschickt eine Resolved-Mail, obwohl das Laufwerk unveraendert unter
      dem Schwellwert liegt.
      - $FreeSpaceDimension steht wieder auf $false. Dimensionen sind
        Computer, Laufwerk und Groesse - alle drei stabil.
      - Der Betreff enthaelt im AutoResolve-Modus keinen Messwert mehr.
        ${...metricValue} ist beim Aufloesen leer, dadurch stand dort ein
        nacktes ' % frei'.
      - Custom Property 'Frei' entfaellt im AutoResolve-Modus aus demselben
        Grund, statt leer zu erscheinen.
      - Das Script warnt jetzt, wenn Dimensionen und AutoResolve kombiniert
        werden.

      GRENZE DES PRODUKTS: Ein AKTUELLER Messwert in der Entwarnungs-Mail ist
      mit Azure Log Alerts nicht erreichbar. Wer Werte in jeder Mail braucht,
      nutzt $NotificationMode = 'Suppress' - dort gibt es nur Alarm-Mails.

    AENDERUNG IN 5.4.0 - WERTE AUCH IN DER ENTWARNUNGS-MAIL
      - Im Betreff der Resolved-Mail blieb '% frei' leer. Ursache:
        ${...metricValue} existiert nur in der Alarm-Meldung; beim Aufloesen
        ist die Bedingung nicht erfuellt und es gibt keinen Messwert.
        Neu: 'Prozent' ist eine eigene Dimension. Dimensionen gehoeren zur
        Alert-Instanz und stehen in BEIDEN Mails. Zusaetzliche
        Instanz-Wechsel entstehen nicht, weil 'Prozent' sich exakt dann
        aendert wie das bereits vorhandene 'Frei'.
      - Custom Property 'Frei' liest ebenfalls aus der Dimension.

      WICHTIG: Die Werte in der Entwarnungs-Mail sind die vom Zeitpunkt der
      AUSLOESUNG. Einen aktuellen Messwert liefert Azure beim Aufloesen
      grundsaetzlich nicht.

    AENDERUNG IN 5.3.0 - CUSTOM PROPERTY 'FREI' MIT PROZENT UND GB
      - 'Frei Prozent' heisst jetzt 'Frei' und zeigt beides: "6 % (129 GB)".
      - $FreeSpaceDimension steht jetzt standardmaessig auf $true. Die
        GB-Zahl wird aus dem gerundeten Prozentwert und der Plattengroesse
        berechnet, NICHT aus FreeSpaceMB. Dadurch aendert sich der
        Dimensionswert nur beim Wechsel des ganzen Prozentwerts statt jede
        Minute - der Mailsturm bleibt aus, und Prozent und GB koennen nicht
        auseinanderlaufen.
      - 'Restkapazitaet' entfaellt, der Wert steckt jetzt in 'Frei'.

    AENDERUNG IN 5.2.1 - ZUSAMMENFASSUNG SPIEGELT DIE ECHTE KONFIGURATION
      - Der Beispiel-Betreff war ein fest einprogrammierter Text
        ("mxkkr8 D: - unter 15 % frei (Fired, 0.92 % frei)") und blieb bei
        jeder Aenderung der Betreffvorlage unveraendert stehen. Jetzt wird er
        aus $EmailSubjectTemplate mit Werten aus dem Probelauf erzeugt.
      - Zusammenfassung zeigt zusaetzlich die Custom Properties und die
        aktiven Dimensionen der Regel.

    AENDERUNG IN 5.2.0 - DARSTELLUNG DER ALARM-MAIL
      - Betreff: 'Fired' durch 'Alarmiert' ersetzt ($SubjectConditionMode).
        In der Klammer steht jetzt der Restplatz statt des Rohwerts.
      - Metric value ganzzahlig: FreePercent wird in der Query gerundet.
        Verschiebt die Ausloeseschwelle um bis zu 0,5 Prozentpunkte.
      - Query liest zusaetzlich FreeSpaceMB, damit Plattengroesse und
        Restkapazitaet ueberhaupt im Alarm-Payload stehen.
      - Neue Dimension 'Groesse' (Plattengroesse). Unkritisch, weil sie sich
        nur beim Vergroessern aendert.
      - Optionale Dimension 'Frei' ueber $FreeSpaceDimension. Standard aus,
        weil jede Wertaenderung eine neue Alert-Instanz und damit zusaetzliche
        Mails erzeugt.
      - Custom Properties: Server, Laufwerk, Groesse, Frei,
        Schwellwert, ueberwachte Laufwerke.
      - Description neu formuliert.

      NICHT AENDERBAR (Azure-Vorlage, kein Einfluss ueber die API):
      - Die Kopfzeile im Mailtext "Alert '<Regelname>' was fired". Der
        Regelname ist pro REGEL fest; ein Servername kann dort nicht stehen,
        weil eine Regel alle Server abdeckt. Server und Laufwerk stehen im
        Betreff und in den Custom Properties.
      - Die Bezeichnung 'Metric name: Minimum' und der Text 'was fired' im
        Mailkoerper.

    AENDERUNG IN 5.1.0 - MOMENTANWERT STATT ZEITRAUM-MITTELWERT
    -------------------------------------------------------------------------
    (9) DIAGNOSE-QUERIES MITTELTEN UEBER DIE LOOKBACK-SPANNE
        Betroffen waren die Ermittlung der Laufwerksgroessen (Stufe 2) und
        die Bestandsabfrage der Abdeckungspruefung (Stufe 3). Beide nutzten
        avgif bzw. avg ueber 'ago(2h)'. Wurde ein Volume innerhalb dieser
        Spanne vergroessert oder bereinigt, entstand ein Mischwert.
        Folge in Stufe 2: die daraus dividierte Gesamtgroesse traf die
        getaggte Disk-Ressource nicht mehr innerhalb $SizeToleranceGB - die
        Ausnahme fiel still weg.
        Folge in Stufe 3: die Abdeckungspruefung meldete Laufwerke als knapp,
        die es nicht mehr waren.
        Neu: beide lesen per arg_max den juengsten Datensatz. Die Groesse
        kommt aus dem Tag vm.azm.ms/diskSizeMB, die Division ist nur noch
        Rueckfallebene.

        Die ALERT-QUERY selbst bleibt unveraendert bei avg ueber bin().
        Das ist kein Versehen: die API verlangt TimeGenerated bei mehr als
        einer Auswertungsperiode, und gemittelt wird dort nur ueber
        $WindowSize. Die Daempfung ist gewollt.

    (10) VERALTETE MESSWERTE WAREN UNSICHTBAR
        Ein Server, der keine Daten mehr liefert, behaelt seinen letzten
        Wert. Der sieht wie ein gueltiger Status aus, kann aber weder Alarm
        ausloesen noch entwarnen. Stufe 3 meldet jetzt jedes Laufwerk, dessen
        Messwert aelter als $MaxDataAgeMinutes ist.

    AENDERUNGEN IN 5.0.0 - ACHT KORREKTUREN AUS DER FEHLERANALYSE
    -------------------------------------------------------------------------
    Anlass: Die Regel lief, aber es kamen keine Mails, obwohl mehrere Server
    unter dem Schwellwert lagen. Ursachenanalyse ergab acht Punkte.

    (1) MASCHINEN-TAGS WURDEN CASE-SENSITIV VERGLICHEN
        Alt:  tostring(tags['Monitoring']) != 'VirtualServer'
        In Resource Graph ist sowohl der TAG-NAME in tags['...'] als auch der
        Vergleich mit != case-sensitiv. Ein Tag 'monitoring' oder ein Wert
        'Windows Server 2022' liess die Maschine durchfallen - sie landete auf
        der Ausschlussliste, die fest in die Alert-Query geschrieben wird.
        Im Extremfall wurde der komplette Bestand ausgeschlossen und die Query
        lieferte nie eine Zeile.
        Neu: tags wird als JSON-String komplett auf Kleinschreibung gezogen
        (todynamic(tolower(tostring(tags)))), Namen UND Werte werden dadurch
        case-insensitiv verglichen.

    (2) MASSENAUSSCHLUSS WURDE NICHT BEMERKT
        Neu: Stufe 1 ermittelt zusaetzlich die Gesamtzahl der Arc-Maschinen
        und bricht ab, wenn der Ausschlussanteil $MaxExclusionRatio
        ueberschreitet. Das verhindert genau den Fall aus (1).

    (3) 'MIN 2 VON 2 PERIODEN' WAR ZU SCHARF
        bin() schneidet auf absolute Uhrzeitgrenzen, das Lookback-Fenster
        (windowSize x numberOfEvaluationPeriods) haengt dagegen am
        Auswertungszeitpunkt. Randbins sind deshalb angeschnitten. Bei
        '2 von 2' muss JEDER Punkt verletzen - ein duenner Randbin kippt die
        Bedingung still.
        Neu: $MinFailingPeriods = 1. Die Daempfung bleibt erhalten (es wird
        weiterhin ueber zwei Perioden geschaut), aber der Bin-Versatz kann
        den Alarm nicht mehr verschlucken.

    (4) KQL-VERGLEICHE WAREN CASE-SENSITIV
        'where Laufwerk in (...)'      -> in~
        'where _ResourceId has ...' -> contains
        has arbeitet termbasiert; der Operand '/microsoft.hybridcompute/
        machines/' enthaelt / und . als Termtrenner und ist damit kein
        sauberer Term.

    (5) STILLE FILTER WAREN NICHT SICHTBAR
        Neu: Stufe 3 listet vor der Anlage auf, welche Laufwerksbuchstaben im
        Workspace vorkommen, aber nicht in $Drives stehen, und welche Server
        durch $ExcludeNamePatterns wegfallen.

    (6) DIE QUERY WURDE NIE GEGENGEPRUEFT
        Neu: Stufe 3b fuehrt die fertige Query einmal gegen den Workspace aus.
        Liefert sie null Zeilen, bricht das Script ab, statt eine blinde Regel
        anzulegen.

    (7) PATCH-BODY MIT BOM UND VERLUST DER CUSTOM PROPERTIES
        Set-Content -Encoding UTF8 schreibt unter Windows PowerShell 5.1 ein
        BOM; 'az rest --body @datei' stolpert darueber. Ausserdem ersetzt das
        PATCH properties.actions komplett - die bei der Anlage gesetzten
        customProperties gingen dabei verloren.
        Neu: UTF8 ohne BOM ueber [System.IO.File]::WriteAllText, Temp-Pfad
        ueber [System.IO.Path]::GetTempPath() (laeuft auch unter PS 7 auf
        Linux), und customProperties werden im PATCH mitgeschickt.

    (8) POWERSHELL-KOMPATIBILITAET
        Neu: $PowerShellMode, Versionspruefung im Pre-Check, Symbole zur
        Laufzeit ueber ConvertFromUtf32, Quellcode reines ASCII,
        Assert-AzSuccess nach externen Aufrufen, Invoke-AzQuiet als Wrapper.
        Funktion Ensure-Extension in Confirm-AzExtension umbenannt
        (genehmigtes Verb).

    HINWEIS ZUM STATEFUL-VERHALTEN (keine Aenderung, nur Klarstellung)
    -------------------------------------------------------------------------
    Bei $NotificationMode = 'AutoResolve' ist die Regel STATEFUL. Pro
    Instanz (Server + Laufwerk) geht genau EINE Mail raus. Solange der Alarm
    offen ist, kommt keine weitere - auch wenn der Platz weiter schrumpft.
    Erst nach der Aufloesung kann dieselbe Instanz erneut feuern. Wer bei
    anhaltender Knappheit wiederkehrende Mails will, braucht 'Suppress' mit
    einer $MuteActionsDuration als Wiederholungsintervall.

    EINE REGEL FUER ALLE LAUFWERKE
    -------------------------------------------------------------------------
    Dimension-Splitting auf 'Computer' UND 'Laufwerk' erzeugt je Kombination
    aus Server und Laufwerk eine eigene Alert-Instanz. Getrennte Regeln je
    Laufwerk sind deshalb nicht noetig - solange derselbe Schwellwert gilt.

    Braucht ihr je Laufwerk unterschiedliche Grenzen (z. B. C: 15 %, D: 5 %),
    fuehrt kein Weg an getrennten Regeln vorbei: eine Scheduled Query Rule
    kennt genau einen Schwellwert.

    WARUM TAGS NICHT DIREKT WIRKEN
    -------------------------------------------------------------------------
    Eine Log Search Alert Rule fragt Log Analytics ab. Dort gibt es KEINE
    Azure-Tags. Ein Cross-Query gegen Resource Graph ist in einer Alert-Regel
    nicht moeglich. Das Script loest beides deshalb ZUR ANLAGEZEIT auf und
    schreibt die Ausnahmen fest in die Query.

    WICHTIG: Das ist eine MOMENTAUFNAHME. Neue Disk-Tags oder neue Server
    ohne Tags wirken sich erst nach einem erneuten Lauf dieses Scripts aus.

    ACTION GROUP UND EMPFAENGER
    -------------------------------------------------------------------------
    'az monitor action-group create' fuehrt ein PUT aus - die Ressource wird
    komplett durch das ersetzt, was im Aufruf steht. Alles im Portal manuell
    Ergaenzte ist danach weg. $EmailRecipients ist die alleinige Quelle der
    Wahrheit. Die Action Group wird NICHT vorher geloescht, damit es kein
    Zeitfenster gibt, in dem ein feuernder Alarm ins Leere laeuft.

    DOKUMENTIERTE GRENZEN VON AZURE MONITOR
    -------------------------------------------------------------------------
      Dimensionen je Regel   max. 6            -> wir nutzen 2
      Regel-Eigenschaften    max. 64 KB        -> wird geprueft, Warnung ab 48
      Beschreibung           max. 4096 Zeichen -> wird geprueft
      Stateful-Regel         max. 300 Alarme je Auswertung, Azure kappt still
      E-Mail                 max. 100/Stunde je Adresse, 100/5 Min je Regel
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 18.08.2026
    Version     : 5.9.1
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\New-ArcDiskSpaceAlert.ps1
.EXAMPLE
    # Vorschau - zeigt Query, Condition, Ausnahmen und Betreff
    $WhatIfMode = $true; .\New-ArcDiskSpaceAlert.ps1
#>

$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

# --- PowerShell-Modus ---
# "Compat" laeuft unter Windows PowerShell 5.1 und PowerShell 7.x.
# "Seven"  bricht unter 5.1 ab.
$PowerShellMode         = "Compat"

# --- Azure-Kontext ---
$SubscriptionId         = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local
$WorkspaceName          = "law-LDK-VirtualServer"
$WorkspaceResourceGroup = "rg-arcmgmt"
$AlertResourceGroup     = "rg-ArcMonitoringMgmt"
$Location               = "westeurope"

# --- Action Group / Empfaenger ---
# Array statt Hashtable: Anzeigenamen duerfen sich wiederholen, Schluessel
# einer Hashtable muessten eindeutig sein.
$ActionGroupName        = "ag-arc-diskspace"
$ActionGroupShortName   = "ArcDisk"                    # max. 12 Zeichen

# Region der Action Group. Bestimmt, wo die Benachrichtigungsdaten
# verarbeitet und gespeichert werden - relevant fuer Datenhaltung in
# Deutschland.
#
# Regional funktioniert NUR zusammen mit der Anlage per 'az rest' und
# $RuleApiVersion. 'az monitor scheduled-query create' nutzt intern eine
# aeltere API-Version und lehnt die Referenz ab:
#   "This api version only supports global Action Groups."
# Seit 5.9.0 legt dieses Script die Regel per PUT an, damit ist die
# Einschraenkung weg.
$ActionGroupLocation    = "germanywestcentral"

# API-Version fuer scheduledQueryRules. Unterhalb von 2023-12-01 werden
# regionale Action Groups nicht akzeptiert.
$RuleApiVersion         = "2023-12-01"

# Die Location einer bestehenden Action Group laesst sich NICHT aendern -
# Azure lehnt das PUT ab. Auf $true loescht das Script sie bei abweichender
# Region und legt sie neu an. Die Ressourcen-ID bleibt dabei gleich (Name und
# Resource Group aendern sich nicht), die Alert-Regel zeigt also weiterhin
# korrekt darauf. Auf $false bricht das Script stattdessen ab.
$RecreateActionGroupOnLocationChange = $true
$EmailRecipients        = @(
    @{ Name = "ITAlert";   Address = "statusmails@ortha-itsolutions.de" }
    # @{ Name = "Bereitsch"; Address = "bereitschaft@example.de" }
    # @{ Name = "Helpdesk";  Address = "helpdesk@example.de" }
)

# --- Zustell-Kontrolle (NEU in 5.9.1) ---------------------------------------
# Verschickt nach der Anlage eine ECHTE Testbenachrichtigung ueber die
# Action Group (Typ 'logalertv2' - derselbe Kanal wie eine Alarm-Mail dieser
# Regel). Kommt die Test-Mail nicht an, liegt das Problem bei der ZUSTELLUNG,
# nicht bei der Regel. Limit von Azure: 2 Tests je 5 Minuten und Action Group.
$TestActionGroup        = $true
$TestApiVersion         = "2023-01-01"

# STATEFUL-FALLE (NEU in 5.9.1) - Ursache fuer 'Regel ok, aber keine Mail':
# Im AutoResolve-Modus ist die Regel stateful. Eine Instanz, die BEREITS
# gefeuert hat - etwa als die Action Group noch falsch verdrahtet war -
# steht weiter offen auf 'Fired'. Fuer eine offene Instanz verschickt Azure
# GRUNDSAETZLICH keine weitere Mail, egal wie oft die Regel neu geschrieben
# wird. Auf $true prueft das Script nach der Anlage, ob offene Fired-Alarme
# der Regel existieren, und deaktiviert/reaktiviert die Regel dann kurz:
# das Deaktivieren loest die offenen Instanzen auf, bei der naechsten
# Auswertung feuern sie neu - diesmal MIT Mail an die korrekte Action Group.
# Nebenwirkung: fuer die aufgeloesten Instanzen koennen kurz vorher
# Resolved-Mails rausgehen.
$ResetAlertState        = $true

# --- Alert-Regel ---
$RuleName               = "alert-arc-disk-below-15pct"
$RuleDisplayName        = "Arc Windows Server: volume below 15 % free"
$Severity               = 2                            # 0=schwerwiegend ... 4=info
$ThresholdPercent       = 15
$Drives                 = @("C:", "D:", "E:")
# Spalte der Query, die den Messwert traegt. Muss zum 'project' der Query
# passen - siehe STUFE 3.
$MetricColumn           = "FreePercent"

# KORREKTUR (9): Ab welchem Alter gilt ein Messwert als veraltet.
# Der AMA misst im festen 60-Sekunden-Takt, die Ingestion liegt typisch unter
# einer Minute. Alles jenseits von zehn Minuten deutet auf einen Server hin,
# der keine Daten mehr liefert - der loest dann auch keinen Alarm mehr aus.
$MaxDataAgeMinutes      = 10

# --- Darstellung in der Mail (durchgaengig Englisch) ---------------------
# "Token" : ${data.essentials.monitorCondition} - liefert Fired / Resolved.
#           Der Wert kommt von Azure und laesst sich nicht uebersetzen,
#           unterscheidet dafuer korrekt zwischen Alarm und Entwarnung.
# "Fixed" : fester Text aus $SubjectFixedState. Steht dann auch in der
#           ENTWARNUNGS-Mail - der Mailtext sagt weiterhin "was resolved".
#
# Es gibt keinen dritten Weg: die Betreffvorlage ist EIN String fuer beide
# Mailarten, Azure kennt keine Bedingungen darin.
$SubjectConditionMode   = "Token"
$SubjectFixedState      = "Low disk space"

# Freien Speicher und Prozent als eigene Dimensionen fuehren.
#
# STANDARD AUS - und das ist eine Korrektur, keine Vorsichtsmassnahme.
# Eine Alert-INSTANZ ist ueber ihre Dimensionswerte definiert. Ist der
# Prozent- oder GB-Wert eine Dimension, dann ist ein Laufwerk mit 6 % eine
# ANDERE Instanz als dasselbe Laufwerk mit 7 %. Beim Wechsel wird die alte
# Instanz aufgeloest - es kommt eine ENTWARNUNGS-MAIL, obwohl das Laufwerk
# unveraendert unter dem Schwellwert liegt. Eine falsche Entwarnung ist
# schaedlicher als eine fehlende Zahl im Betreff.
#
# Dimensionen duerfen nur STABILE Identitaet enthalten: Server, Laufwerk und
# die Plattengroesse. Veraenderliche Werte gehoeren in die Metric Measure
# Column - genau deshalb liefert Azure sie beim Aufloesen auch nicht.
#
# Auf $true nur setzen, wenn gleichzeitig $NotificationMode = 'Suppress'
# gilt. Dann gibt es keine Entwarnungs-Mails, und der Effekt entfaellt.
$FreeSpaceDimension     = $false

$EvaluationFrequency    = "PT15M"
$WindowSize             = "PT15M"
$NumberOfEvalPeriods    = 2

# KORREKTUR (3): 1 statt 2.
# Der Query-Lookback ist windowSize x numberOfEvaluationPeriods, also 30 Min.
# bin(TimeGenerated, 15m) schneidet aber auf absolute Uhrzeitgrenzen. Die
# Randbins sind deshalb angeschnitten und teils duenn besetzt. Mit '2 von 2'
# musste JEDER Punkt verletzen - ein schwacher Randbin hat den Alarm still
# verschluckt. Mit 1 bleibt die Zwei-Perioden-Sicht erhalten, ohne dass der
# Bin-Versatz die Regel unwirksam macht.
$MinFailingPeriods      = 1

# --- Benachrichtigungsmodus ---------------------------------------------
# Azure erlaubt genau EINES von beiden. Die API lehnt die Kombination ab:
#   "Auto mitigation must be disabled when action suppression is set"
#
#   'AutoResolve'  STATEFUL. Pro Instanz genau EINE Mail. Der Alarm loest
#                  sich selbst auf, sobald die Bedingung nicht mehr erfuellt
#                  ist, und es geht eine Resolved-Mail raus. Solange der
#                  Alarm offen steht, kommt KEINE weitere Mail.
#                  Nur in diesem Modus liefert ${data.essentials.monitorCondition}
#                  im Betreff etwas anderes als 'Fired'.
#
#   'Suppress'     Nach dem Feuern bleibt es fuer $MuteActionsDuration still,
#                  danach kann dieselbe Instanz erneut melden. Keine
#                  Entwarnung, dafuer wiederkehrende Erinnerungen bei
#                  anhaltender Knappheit.
$NotificationMode       = "AutoResolve"      # 'AutoResolve' oder 'Suppress'
$MuteActionsDuration    = "PT6H"             # nur bei 'Suppress' wirksam

# --- Serverauswahl ueber Maschinen-Tags ---
# Wird zur Anlagezeit gegen Resource Graph aufgeloest. Maschinen, die NICHT
# alle Tags tragen, werden namentlich aus der Query ausgeschlossen.
# Identisch zu $PolicyTagFilter in New-ArcMonitoringPolicy.ps1 halten.
# Vergleich laeuft seit 5.0.0 case-insensitiv (Tag-Name UND Wert).
$MachineTagFilter       = [ordered]@{
    "Monitoring"      = "VirtualServer"
    "OperatingSystem" = "Windows Server"
}
$ApplyMachineTagFilter  = $true

# KORREKTUR (2): Notbremse gegen Massenausschluss.
# Schliesst der Tag-Filter mehr als diesen Anteil des Bestands aus, ist mit
# hoher Wahrscheinlichkeit die Tag-Schreibweise schuld und nicht der Bestand.
# Das Script bricht dann ab, statt eine blinde Regel anzulegen.
$MaxExclusionRatio      = 0.80     # 0.0 - 1.0, oder $null zum Deaktivieren

# --- Laufwerks-Ausnahmen ueber Disk-Tags ---
# Tag auf der DISK-Ressource (Azure Local).
$DiskTagName            = "Monitoring"
$DiskTagValue           = "no-disccapacitymonitoring"
$ApplyDiskTagFilter     = $true
$SizeToleranceGB        = 1        # Toleranz beim Abgleich VHDX <-> Laufwerk

# --- Manuelle Ausnahmen (immer wirksam) ---
# Format: 'server|laufwerk', z. B. 'mxkkr8|D:'. Kurzname ohne Domaene.
$ExcludeDrives          = @()
# Ganze Server ausnehmen, unabhaengig vom Laufwerk.
$ExcludeServers         = @()
# Namensmuster (Regex), z. B. AVD-Hosts.
$ExcludeNamePatterns    = @('^avd')

# --- Betreff-Vorlage --------------------------------------------------------
# WICHTIG: einfache Anfuehrungszeichen! In doppelten wuerde PowerShell
# ${data...} als eigene Variable interpretieren und leer ersetzen.
#
# dimensions[0] = Computer, dimensions[1] = Laufwerk - in der Reihenfolge, in
# der sie in der Condition stehen. Sollte der Betreff die Werte vertauscht
# zeigen, die beiden Indizes hier tauschen.
# KORREKTUR (5.7.0): Dimensionsindizes werden BERECHNET, nicht geraten.
# Azure sortiert dimensions[] offenbar alphabetisch nach Spaltenname und
# nicht in der Reihenfolge der Condition-Klausel. Feste Indizes trafen
# deshalb die falsche Spalte - im Betreff stand die resourceId statt der
# Groesse. Die Liste unten enthaelt ALLE Dimensionen inklusive resourceId,
# die durch "resource id resourceId" ebenfalls eine wird.
#
# $DimensionOrder auf "Condition" stellen, falls Azure das Verhalten aendert.
# Die Zusammenfassung zeigt die verwendete Zuordnung - gegen die Dimensions-
# Liste in der naechsten Mail pruefbar.
$DimensionOrder = "Alphabetical"

$dimNamen = @("Computer", "Drive", "Size", "resourceId")
if ($FreeSpaceDimension) { $dimNamen += @("Percent", "Free") }

if ($DimensionOrder -eq "Alphabetical") {
    $dimSortiert = @($dimNamen | Sort-Object { $_.ToLower() })
}
else {
    $dimSortiert = $dimNamen
}

function Get-DimToken {
    param([string]$Name)
    $i = [array]::IndexOf($dimSortiert, $Name)
    if ($i -lt 0) { return "" }
    return '${data.alertContext.condition.allOf[0].dimensions[' + $i + '].value}'
}

# ACHTUNG einfache Anfuehrungszeichen - in doppelten wuerde PowerShell
# ${data...} als eigene Variable lesen und leer ersetzen.
$dimServer  = Get-DimToken "Computer"
$dimDrive   = Get-DimToken "Drive"
$dimSize    = Get-DimToken "Size"
$dimPercent = Get-DimToken "Percent"
$dimFree    = Get-DimToken "Free"
$metricVal  = '${data.alertContext.condition.allOf[0].metricValue}'

if ($SubjectConditionMode -eq "Token") {
    $zustand = '${data.essentials.monitorCondition}'
}
else {
    $zustand = $SubjectFixedState
}

# In der Klammer steht der Restplatz. Ohne $FreeSpaceDimension ist die
# absolute GB-Zahl nicht im Payload - dann Prozent und Gesamtgroesse.
# KORREKTUR (5.5.0): ${...metricValue} steht NUR in der Alarm-Meldung. Beim
# Aufloesen ist die Bedingung nicht erfuellt, es gibt keinen Messwert - das
# Token bleibt leer und im Betreff stand ein nacktes ' % frei'.
# Deshalb: Messwert nur dort in den Betreff, wo es garantiert keine
# Entwarnungs-Mail gibt.
if ($FreeSpaceDimension) {
    # Nur sinnvoll zusammen mit 'Suppress' - siehe Kommentar am Schalter.
    $klammer = "($zustand, $dimPercent / $dimFree free of $dimSize)"
}
elseif ($NotificationMode -eq "Suppress") {
    $klammer = "($zustand, $metricVal % free of $dimSize)"
}
else {
    # AutoResolve: derselbe Betreff muss fuer Alarm UND Entwarnung passen.
    $klammer = "($zustand, $metricVal % free of $dimSize)"
}

$EmailSubjectTemplate = "$dimServer $dimDrive - free space below $ThresholdPercent % $klammer"

# --- Vorschaumodus ---
$WhatIfMode             = $false

# --- Laufzeitverhalten ---
$ErrorActionPreference  = "Continue"

# =============================================================================
#  AUSGABE - Symbole zur Laufzeit erzeugen, Quellcode bleibt ASCII
# =============================================================================
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

function Write-Line  { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$SymOk  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$SymErr  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$SymWarn  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$SymInfo  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$SymRun  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

# =============================================================================
#  AZURE-CLI-HELFER
# =============================================================================
$script:LastAzError = $null

function Assert-AzSuccess {
    <#
      Externe Programme melden Fehler ueber den Exitcode, nicht ueber
      Exceptions. try/catch allein wuerde sie nicht sehen.
    #>
    param([int]$ExitCode, [string]$ErrorText, [string]$Context)
    if ($ExitCode -ne 0) {
        $script:LastAzError = "$Context (Exitcode $ExitCode): $ErrorText"
        return $false
    }
    return $true
}

function Invoke-AzQuiet {
    <#
      Ruft Azure CLI auf und liefert sauberes JSON zurueck. Trennt stdout und
      stderr, damit Python-Warnungen der CLI-Extensions das JSON nicht
      zerstoeren. Argumente als Array, damit die Kommandozeile nichts zerlegt.
    #>
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $code = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if (-not (Assert-AzSuccess -ExitCode $code -ErrorText ($err | Out-String).Trim() `
                                   -Context ("az " + (@($Arguments)[0..1] -join " ")))) {
            return $null
        }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{', '['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort erhalten: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally { Remove-Item $errFile -ErrorAction SilentlyContinue }
}

function Confirm-AzExtension {
    # KORREKTUR (8): hiess frueher Ensure-Extension - 'Ensure' ist kein
    # genehmigtes PowerShell-Verb.
    param([Parameter(Mandatory)][string]$Name)

    $exts = Invoke-AzQuiet @("extension", "list")
    if ($exts | Where-Object { $_.name -eq $Name }) { return $true }

    Write-Warn2 "Extension '$Name' fehlt - wird installiert."
    az extension add --name $Name --only-show-errors 2>$null
    if (-not (Assert-AzSuccess -ExitCode $LASTEXITCODE -ErrorText "" -Context "az extension add $Name")) {
        Write-Fail "Installation von '$Name' fehlgeschlagen."
        return $false
    }
    return $true
}

function ConvertTo-KqlTimespan {
    <#
      Wandelt eine ISO-8601-Dauer in einen KQL-Timespan:
        PT5M -> 5m, PT15M -> 15m, PT1H -> 1h, PT30S -> 30s, P1D -> 1d
      Wird gebraucht, damit die bin()-Groesse in der Query IMMER zur
      konfigurierten $WindowSize passt.
    #>
    param([Parameter(Mandatory)][string]$Iso)

    $m = [regex]::Match($Iso, '^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$')
    if (-not $m.Success) { return $null }

    if ($m.Groups[1].Success) { return "$($m.Groups[1].Value)d" }
    if ($m.Groups[2].Success) { return "$($m.Groups[2].Value)h" }
    if ($m.Groups[3].Success) { return "$($m.Groups[3].Value)m" }
    if ($m.Groups[4].Success) { return "$($m.Groups[4].Value)s" }
    return $null
}

function Get-KqlListe {
    <#
      Baut eine KQL-Liste aus Strings: 'a','b','c'
      Leere Eingabe liefert $null - der Aufrufer laesst die Zeile dann weg,
      denn 'in~ ()' waere ein Syntaxfehler.
    #>
    param([string[]]$Werte)
    $w = @($Werte | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique)
    if ($w.Count -eq 0) { return $null }
    return (($w | ForEach-Object { "'$_'" }) -join ", ")
}

function Invoke-AzRestBody {
    <#
      Fuehrt 'az rest' mit JSON-Body aus. Der Body geht ueber eine
      Temp-Datei, weil az.cmd Inline-JSON unter Windows falsch zerlegt.

      KORREKTUR (5.9.1): In 5.9.0 wurde der Regel-Body in Stufe 7 mit
      'Out-File -Encoding utf8' geschrieben - unter Windows PowerShell 5.1
      erzeugt das ein BOM, an dem 'az rest --body @datei' scheitert. Genau
      dieses Problem hatte KORREKTUR (7) fuer den frueheren PATCH bereits
      geloest, der PUT nutzte die Loesung aber nicht. Jetzt laufen ALLE
      REST-Bodies ueber diese Funktion:
        - UTF-8 OHNE BOM ueber [System.IO.File]::WriteAllText
        - Temp-Pfad ueber GetTempPath() statt $env:TEMP (laeuft auch
          unter PowerShell 7 auf Linux)
        - Bei einem Fehler bleibt die Datei fuer die Diagnose liegen,
          der Pfad steht in $script:LastAzBodyFile. In 5.9.0 wurde sie
          VOR der Fehlermeldung geloescht, die auf sie verwies.
      Erfolgskontrolle ueber $script:LastAzError - der Rueckgabewert ist
      bei Antworten ohne Body (202/204) auch im Erfolgsfall $null.
    #>
    param(
        [Parameter(Mandatory)][string]$Method,
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)]$Body
    )

    $script:LastAzBodyFile = $null
    # -InputObject statt Pipe: die Pipeline wuerde ein Array enumerieren
    # und aus '[...]' ein einzelnes Objekt machen.
    $json     = ConvertTo-Json -InputObject $Body -Depth 12
    $bodyFile = Join-Path ([System.IO.Path]::GetTempPath()) "azrest-$([guid]::NewGuid()).json"

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($bodyFile, $json, $utf8NoBom)

    $ergebnis = Invoke-AzQuiet @(
        "rest", "--method", $Method, "--url", $Url,
        "--headers", "Content-Type=application/json",
        "--body", "@$bodyFile"
    )

    if ($script:LastAzError) { $script:LastAzBodyFile = $bodyFile }
    else { Remove-Item $bodyFile -ErrorAction SilentlyContinue }

    return $ergebnis
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

# KORREKTUR (8): PowerShell-Version pruefen
Write-Run "Pruefe PowerShell-Version..."
$psVer = $PSVersionTable.PSVersion
if ($PowerShellMode -eq "Seven" -and $psVer.Major -lt 7) {
    Write-Fail "PowerShellMode 'Seven' verlangt PowerShell 7.x - gefunden $psVer."
    exit 1
}
Write-Ok "PowerShell $psVer (Modus: $PowerShellMode)"
if ($psVer.Major -ge 7 -and ($psVer.Major -gt 7 -or $psVer.Minor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Sub "PSNativeCommandUseErrorActionPreference deaktiviert."
}

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzQuiet @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - 'az monitor scheduled-query' benoetigt mindestens 2.54.0."
        Write-Sub "Aktualisierung: az upgrade"
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzQuiet @("account", "show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if (-not (Assert-AzSuccess -ExitCode $LASTEXITCODE -ErrorText "" -Context "az account set")) {
        Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1
    }
    Write-Ok "Subscription gesetzt."
}

Write-Run "Pruefe benoetigte Extensions..."
$extOk = $true
foreach ($e in @("scheduled-query", "resource-graph", "log-analytics")) {
    if (-not (Confirm-AzExtension -Name $e)) { $extOk = $false }
}
if (-not $extOk) { exit 1 }
Write-Ok "Extensions verfuegbar."

Write-Run "Pruefe Workspace '$WorkspaceName'..."
$ws = Invoke-AzQuiet @("monitor", "log-analytics", "workspace", "show",
                       "--resource-group", $WorkspaceResourceGroup,
                       "--name", $WorkspaceName, "-o", "json")
if (-not $ws) { Write-Fail "Workspace nicht erreichbar: $script:LastAzError"; exit 1 }
Write-Ok "Workspace gefunden: $($ws.name) ($($ws.location))"
$WorkspaceResourceId = $ws.id

Write-Run "Pruefe vorhandene Alert-Regeln..."
$RegelExistierteVorher = $false
$vorhandene = Invoke-AzQuiet @("monitor", "scheduled-query", "list",
                               "--resource-group", $AlertResourceGroup, "-o", "json")
if ($vorhandene) {
    $andere = @($vorhandene | Where-Object { $_.name -ne $RuleName })
    if ($andere.Count -gt 0) {
        Write-Warn2 "$($andere.Count) weitere Regel(n) in '$AlertResourceGroup':"
        foreach ($a in $andere) { Write-Sub "$($a.name)" }
        Write-Sub "Pruefen, ob eine davon dasselbe ueberwacht - sonst doppelte Mails."
    }
    if ($vorhandene | Where-Object { $_.name -eq $RuleName }) {
        # NEU (5.9.1): gemerkt fuer die Stateful-Kontrolle in Stufe 7.
        # Nur eine VORHANDENE Regel kann offene Fired-Instanzen haben.
        $RegelExistierteVorher = $true
        Write-Info2 "'$RuleName' existiert bereits und wird ueberschrieben."
    }
}
Write-Line

# =============================================================================
#  STUFE 1 - SERVER-AUSNAHMEN AUS MASCHINEN-TAGS
# =============================================================================
Write-Head "STUFE 1 - MASCHINEN-TAGS"

$tagAusnahmen = @()

if (-not $ApplyMachineTagFilter) {
    Write-Info2 "Uebersprungen (`$ApplyMachineTagFilter = `$false)."
}
else {
    $krit = ($MachineTagFilter.Keys | ForEach-Object { "$_=$($MachineTagFilter[$_])" }) -join " UND "
    Write-Run "Suche Maschinen OHNE $krit..."

    # KORREKTUR (1): case-insensitiver Vergleich.
    # tags wird als JSON-Text komplett auf Kleinschreibung gezogen. Damit sind
    # sowohl die Schluessel (tags['Monitoring'] vs. tags['monitoring']) als
    # auch die Werte ('VirtualServer' vs. 'virtualserver') unempfindlich
    # gegen Schreibweisen. Maschinen ganz ohne Tags liefern null -> tostring
    # ergibt '' -> Bedingung trifft zu -> korrekt ausgeschlossen.
    #
    # Nur einfache Anfuehrungszeichen - doppelte ueberleben az.cmd nicht.
    $bed = ($MachineTagFilter.Keys | ForEach-Object {
                $k = $_.ToLower()
                $v = ([string]$MachineTagFilter[$_]).ToLower()
                "tostring(tl['$k']) != '$v'" }) -join " or "

    $q = "resources " `
       + "| where type =~ 'microsoft.hybridcompute/machines' " `
       + "| extend tl = todynamic(tolower(tostring(tags))) " `
       + "| where $bed " `
       + "| project name, " `
       +   "Monitoring = tostring(tl['monitoring']), " `
       +   "OS = tostring(tl['operatingsystem'])"

    $res = Invoke-AzQuiet @("graph", "query", "-q", $q, "--first", "1000", "-o", "json")
    if (-not $res) {
        Write-Fail "Abfrage fehlgeschlagen: $script:LastAzError"
        exit 1
    }

    $tagAusnahmen = @($res.data | ForEach-Object { $_.name.ToLower() })

    # KORREKTUR (2): Gesamtbestand ermitteln und Ausschlussanteil bewerten.
    $qGesamt = "resources " `
             + "| where type =~ 'microsoft.hybridcompute/machines' " `
             + "| summarize Gesamt = count()"
    $resGesamt = Invoke-AzQuiet @("graph", "query", "-q", $qGesamt, "-o", "json")
    $gesamt = 0
    if ($resGesamt -and $resGesamt.data) { $gesamt = [int]$resGesamt.data[0].Gesamt }

    if ($gesamt -gt 0) {
        $anteil = $tagAusnahmen.Count / [double]$gesamt
        Write-Ok "$($tagAusnahmen.Count) von $gesamt Maschine(n) erfuellen die Tag-Bedingung nicht ($([math]::Round($anteil*100,1)) %)."
    }
    else {
        Write-Ok "$($tagAusnahmen.Count) Maschine(n) erfuellen die Tag-Bedingung nicht."
        $anteil = 0
    }
    Write-Sub "Sie werden namentlich aus der Alert-Query ausgeschlossen."

    if ($null -ne $MaxExclusionRatio -and $gesamt -gt 0 -and $anteil -gt $MaxExclusionRatio) {
        Write-Host ""
        Write-Fail "Ausschlussanteil ueber $([math]::Round($MaxExclusionRatio*100,0)) % - Anlage abgebrochen."
        Write-Sub "So gut wie der ganze Bestand faellt durch den Tag-Filter. Die Regel"
        Write-Sub "wuerde angelegt, aber nie feuern. Wahrscheinliche Ursachen:"
        Write-Sub "  - Tag-Namen oder -Werte weichen ab (`$MachineTagFilter pruefen)"
        Write-Sub "  - Schritt 0 (Set-ArcVirtualServerTag.ps1) lief noch nicht"
        Write-Sub "Kontrolle:"
        Write-Sub "  az graph query -q `"resources | where type =~ 'microsoft.hybridcompute/machines' | summarize count() by tostring(tags)`""
        Write-Sub "Bewusst gewollt? Dann `$MaxExclusionRatio auf `$null setzen."
        exit 1
    }

    # Nur die relevanten anzeigen: solche, die ueberhaupt ein Monitoring-Tag
    # tragen. Voellig untaggte Maschinen liefern ohnehin keine Daten.
    $relevant = @($res.data | Where-Object { -not [string]::IsNullOrWhiteSpace($_.Monitoring) })
    if ($relevant.Count -gt 0) {
        Write-Host ""
        Write-Info2 "Davon mit gesetztem Monitoring-Tag (potenzieller Altbestand):"
        foreach ($r in ($relevant | Sort-Object name)) {
            Write-Sub ("{0,-24} Monitoring={1}, OS={2}" -f $r.name, $r.Monitoring,
                       $(if ($r.OS) { $r.OS } else { "(leer)" }))
        }
    }
}
Write-Line

# =============================================================================
#  STUFE 2 - LAUFWERKS-AUSNAHMEN AUS DISK-TAGS
# =============================================================================
Write-Head "STUFE 2 - DISK-TAGS"

$diskAusnahmen = @()
$mehrdeutig    = @()

if (-not $ApplyDiskTagFilter) {
    Write-Info2 "Uebersprungen (`$ApplyDiskTagFilter = `$false)."
}
else {
    Write-Run "Lade Disks mit '$DiskTagName=$DiskTagValue'..."

    $q = "resources " `
       + "| where tags['$DiskTagName'] =~ '$DiskTagValue' " `
       + "| extend g = coalesce(toreal(properties.diskSizeGB), " `
       +   "toreal(properties.diskSizeBytes) / 1073741824.0, " `
       +   "toreal(properties.diskSizeMB) / 1024.0) " `
       + "| project Disk = name, " `
       +   "Server = tolower(tostring(split(name, '_')[0])), " `
       +   "GroesseGB = g"

    $res = Invoke-AzQuiet @("graph", "query", "-q", $q, "--first", "1000", "-o", "json")
    $tagDisks = if ($res -and $res.data) { @($res.data) } else { @() }

    if ($tagDisks.Count -eq 0) {
        Write-Info2 "Keine getaggten Disks gefunden."
    }
    else {
        Write-Ok "$($tagDisks.Count) getaggte Disk-Ressource(n):"
        foreach ($d in ($tagDisks | Sort-Object Server, Disk)) {
            Write-Sub ("{0,-34} Server={1,-16} {2,7:N1} GB" -f $d.Disk, $d.Server, $d.GroesseGB)
        }

        # --- Laufwerke mit Gesamtgroesse aus Log Analytics ---
        Write-Host ""
        Write-Run "Ermittle Laufwerksgroessen aus dem Workspace..."

        # KORREKTUR (9): arg_max statt avgif, Groesse aus dem Tag.
        # avgif mittelte ueber die volle Lookback-Spanne. Wurde ein Volume
        # innerhalb dieser Spanne vergroessert oder bereinigt, entstand ein
        # Mischwert - und die daraus dividierte Gesamtgroesse traf die
        # getaggte Disk-Ressource nicht mehr innerhalb $SizeToleranceGB.
        # Die Ausnahme fiel dann still weg. Jetzt zaehlt der juengste
        # Datensatz, und die Groesse kommt direkt aus dem Tag diskSizeMB;
        # die Division bleibt nur noch Rueckfallebene.
        $kql = "InsightsMetrics" `
             + " | where TimeGenerated > ago(2h)" `
             + " | where Origin == 'vm.azm.ms'" `
             + " | where Namespace == 'LogicalDisk'" `
             + " | where Name in~ ('FreeSpacePercentage','FreeSpaceMB')" `
             + " | extend Laufwerk = tostring(todynamic(Tags)['vm.azm.ms/mountId'])" `
             + " | extend TagGB = todouble(todynamic(Tags)['vm.azm.ms/diskSizeMB']) / 1024.0" `
             + " | summarize arg_max(TimeGenerated, Val, TagGB) by Computer, Laufwerk, Name" `
             + " | summarize P = anyif(Val, Name == 'FreeSpacePercentage')," `
             +   " M = anyif(Val, Name == 'FreeSpaceMB'), G = max(TagGB)" `
             +   " by Computer, Laufwerk" `
             + " | where isnotnull(P) and isnotnull(M) and P > 0" `
             + " | project Server = tolower(tostring(split(Computer, '.')[0]))," `
             +   " Laufwerk, GesamtGB = round(coalesce(iff(G > 0, G, real(null))," `
             +   " (M / 1024.0) / (P / 100.0)), 1)"

        $rows = Invoke-AzQuiet @("monitor", "log-analytics", "query",
                                 "--workspace", $ws.customerId,
                                 "--analytics-query", $kql, "-o", "json")

        if (-not $rows) {
            Write-Warn2 "Laufwerksgroessen nicht abrufbar - Disk-Tag-Filter entfaellt."
            Write-Sub "Ursache: $script:LastAzError"
            Write-Sub "Ausnahmen ggf. manuell in `$ExcludeDrives eintragen."
        }
        else {
            $rows = @($rows)
            Write-Ok "$($rows.Count) Laufwerk(e) aus dem Workspace."
            Write-Host ""

            foreach ($d in ($tagDisks | Sort-Object Server, Disk)) {
                $treffer = @($rows | Where-Object {
                    $_.Server -eq $d.Server -and
                    [math]::Abs([double]$_.GesamtGB - [double]$d.GroesseGB) -le $SizeToleranceGB
                })

                if ($treffer.Count -eq 1) {
                    $schluessel = "$($d.Server)|$($treffer[0].Laufwerk)"
                    $diskAusnahmen += $schluessel
                    Write-Host ("    {0,-34} -> {1,-12} eindeutig" -f $d.Disk, $schluessel) -ForegroundColor Green
                }
                elseif ($treffer.Count -gt 1) {
                    $kandidaten = ($treffer | ForEach-Object { $_.Laufwerk }) -join ", "
                    $mehrdeutig += [PSCustomObject]@{ Disk = $d.Disk; Server = $d.Server; Kandidaten = $kandidaten }
                    Write-Host ("    {0,-34} -> {1,-12} MEHRDEUTIG ({2})" -f `
                                $d.Disk, "?", $kandidaten) -ForegroundColor Yellow
                }
                else {
                    Write-Host ("    {0,-34} -> {1,-12} kein Treffer" -f $d.Disk, "-") -ForegroundColor DarkGray
                }
            }

            if ($mehrdeutig.Count -gt 0) {
                Write-Host ""
                Write-Warn2 "$($mehrdeutig.Count) Disk(s) nicht eindeutig zuordenbar - NICHT ausgeschlossen."
                Write-Sub "Zwei gleich grosse Laufwerke auf demselben Server. Eine geratene"
                Write-Sub "Ausnahme wuerde einen echten Alarm unterdruecken, ohne dass es"
                Write-Sub "auffaellt. Bitte manuell entscheiden und in `$ExcludeDrives eintragen:"
                foreach ($m in $mehrdeutig) {
                    Write-Sub "  $($m.Server)|<Laufwerk>   Kandidaten: $($m.Kandidaten)"
                }
            }
        }
    }
}
Write-Line

# =============================================================================
#  STUFE 3 - ABDECKUNG PRUEFEN
# =============================================================================
# KORREKTUR (5): Bisher wirkten $Drives und $ExcludeNamePatterns still. Jetzt
# wird vor der Anlage sichtbar gemacht, was dadurch aus der Ueberwachung
# faellt.
Write-Head "STUFE 3 - ABDECKUNG"

Write-Run "Ermittle vorhandene Server und Laufwerke im Workspace..."

$kqlBestand = "InsightsMetrics" `
            + " | where TimeGenerated > ago(2h)" `
            + " | where Origin == 'vm.azm.ms'" `
            + " | where Namespace == 'LogicalDisk' and Name == 'FreeSpacePercentage'" `
            + " | extend Laufwerk = tostring(todynamic(Tags)['vm.azm.ms/mountId'])" `
            + " | extend Kurz = tolower(tostring(split(Computer, '.')[0]))" `
            + " | summarize arg_max(TimeGenerated, Val) by Kurz, Laufwerk" `
            + " | project Kurz, Laufwerk, FreePercent = round(Val, 2)," `
            +   " AlterMin = datetime_diff('minute', now(), TimeGenerated)"

$bestand = Invoke-AzQuiet @("monitor", "log-analytics", "query",
                            "--workspace", $ws.customerId,
                            "--analytics-query", $kqlBestand, "-o", "json")

if (-not $bestand) {
    Write-Warn2 "Bestand nicht abrufbar - Abdeckungspruefung entfaellt."
    Write-Sub "Ursache: $script:LastAzError"
    $bestand = @()
}
else {
    $bestand = @($bestand)
    $serverAlle = @($bestand | ForEach-Object { $_.Kurz } | Select-Object -Unique)
    Write-Ok "$($bestand.Count) Laufwerk(e) auf $($serverAlle.Count) Server(n) liefern Daten."

    # KORREKTUR (9): Veraltete Messwerte sichtbar machen.
    # Eine eingefrorene Zahl sieht wie ein gueltiger Status aus. Ein Server,
    # der nicht mehr liefert, kann weder Alarm ausloesen noch entwarnen.
    $veraltet = @($bestand | Where-Object {
        $null -ne $_.AlterMin -and [int]$_.AlterMin -gt $MaxDataAgeMinutes
    } | Sort-Object { [int]$_.AlterMin } -Descending)

    if ($veraltet.Count -gt 0) {
        Write-Host ""
        Write-Warn2 "$($veraltet.Count) Laufwerk(e) mit Messwerten aelter als $MaxDataAgeMinutes Minuten:"
        foreach ($v in ($veraltet | Select-Object -First 20)) {
            Write-Sub ("{0,-18} {1,-5} {2,5} Min alt" -f $v.Kurz, $v.Laufwerk, $v.AlterMin)
        }
        if ($veraltet.Count -gt 20) {
            Write-Sub "... und $($veraltet.Count - 20) weitere."
        }
        Write-Sub "Diese Server melden nicht mehr - AMA-Status und DCR-Zuordnung pruefen."
    }
    else {
        Write-Ok "Alle Messwerte juenger als $MaxDataAgeMinutes Minuten."
    }

    # Laufwerksbuchstaben, die nicht in $Drives stehen
    $fremdeDrives = @($bestand | Where-Object { $Drives -notcontains $_.Laufwerk } |
                      Group-Object Laufwerk | Sort-Object Name)
    if ($fremdeDrives.Count -gt 0) {
        Write-Host ""
        Write-Warn2 "Nicht ueberwachte Laufwerksbuchstaben (nicht in `$Drives):"
        foreach ($g in $fremdeDrives) {
            $knapp = @($g.Group | Where-Object { [double]$_.FreePercent -lt $ThresholdPercent })
            $txt = "{0,-8} {1,4} Laufwerk(e)" -f $g.Name, $g.Count
            if ($knapp.Count -gt 0) {
                Write-Host ("    $txt  davon $($knapp.Count) unter $ThresholdPercent %") -ForegroundColor Red
            }
            else { Write-Sub $txt }
        }
        Write-Sub "Bei Bedarf in `$Drives aufnehmen."
    }

    # Server, die durch Namensmuster wegfallen
    $viaMuster = @()
    foreach ($s in $serverAlle) {
        foreach ($pat in $ExcludeNamePatterns) {
            if ($s -match $pat) { $viaMuster += $s; break }
        }
    }
    if ($viaMuster.Count -gt 0) {
        Write-Host ""
        Write-Warn2 "$($viaMuster.Count) Server fallen durch `$ExcludeNamePatterns weg:"
        Write-Sub (($viaMuster | Sort-Object) -join ", ")
    }
}
Write-Line

# =============================================================================
#  STUFE 4 - QUERY BAUEN
# =============================================================================
Write-Head "STUFE 4 - ALERT-QUERY"

$alleServerAusnahmen = @($ExcludeServers + $tagAusnahmen | ForEach-Object { $_.ToLower() })
$alleDriveAusnahmen  = @($ExcludeDrives + $diskAusnahmen | ForEach-Object { $_.ToLower() })

# Nur einfache Anfuehrungszeichen im KQL - doppelte ueberleben az.cmd nicht.
$p = New-Object System.Collections.Generic.List[string]
$p.Add("InsightsMetrics")
$p.Add("where Origin == 'vm.azm.ms'")
# KORREKTUR (5.2.0): beide Metriken lesen.
# FreeSpacePercentage liefert den Schwellwert-Messwert, FreeSpaceMB die
# absoluten MB und im Tag die Plattengroesse. Ohne die zweite Metrik gaebe es
# in der Mail keine GB-Angabe.
$p.Add("where Namespace == 'LogicalDisk' and Name in~ ('FreeSpacePercentage','FreeSpaceMB')")

# KORREKTUR (4): contains statt has.
# has sucht termbasiert; '/microsoft.hybridcompute/machines/' enthaelt / und .
# als Termtrenner und ist damit kein sauberer Term. contains prueft den
# Teilstring case-insensitiv und ist hier eindeutig.
$p.Add("where _ResourceId contains '/microsoft.hybridcompute/machines/'")

# KQL kennt KEIN '!matches regex' - die Negation laeuft ueber not().
foreach ($pat in $ExcludeNamePatterns) {
    $p.Add("where not(Computer matches regex '(?i)$pat')")
}

$p.Add("extend Drive = tostring(todynamic(Tags)['vm.azm.ms/mountId'])")
$p.Add("extend GB = todouble(todynamic(Tags)['vm.azm.ms/diskSizeMB']) / 1024.0")
$lst = Get-KqlListe -Werte $Drives
if (-not $lst) {
    Write-Fail "`$Drives ist leer - die Regel haette keinen Bezug."
    exit 1
}
# KORREKTUR (4): in~ statt in - unempfindlich gegen 'c:' vs. 'C:'.
$p.Add("where Drive in~ ($lst)")

# Kurzname als Dimension - der FQDN macht den Mail-Betreff unleserlich.
$p.Add("extend Kurz = tolower(tostring(split(Computer, '.')[0]))")

$lst = Get-KqlListe -Werte $alleServerAusnahmen
if ($lst) { $p.Add("where Kurz !in~ ($lst)") }

$lst = Get-KqlListe -Werte $alleDriveAusnahmen
if ($lst) { $p.Add("where strcat(Kurz, '|', Drive) !in~ ($lst)") }

# TimeGenerated ist PFLICHT, sobald mehr als eine Auswertungsperiode
# konfiguriert ist. Die API lehnt sonst ab mit:
#   "Number of evaluation periods must be 1 for queries that do not
#    project the 'TimeGenerated' column of type 'datetime'"
$bin = ConvertTo-KqlTimespan -Iso $WindowSize
if (-not $bin) {
    Write-Fail "`$WindowSize = '$WindowSize' ist keine gueltige ISO-8601-Dauer."
    Write-Sub "Erwartet z. B. PT5M, PT15M, PT1H."
    exit 1
}

# BEWUSST avg UND NICHT arg_max - anders als in den Diagnose-Queries oben.
# Begruendung:
#   - Die API verlangt TimeGenerated, sobald $NumberOfEvalPeriods > 1 ist.
#     arg_max liefert zwar TimeGenerated, aber keine Zeitreihe: alle Zeilen
#     lagen im selben Punkt, und die Mehrperioden-Auswertung waere sinnlos.
#   - Gemittelt wird hier nur ueber $WindowSize (aktuell $WindowSize), nicht
#     ueber einen frei waehlbaren Zeitraum. Der Lookback betraegt
#     windowSize x numberOfEvaluationPeriods, also 30 Minuten.
#   - Die Daempfung ist erwuenscht: ein einzelner Ausreisser soll keine Mail
#     ausloesen. Ein bereinigtes Laufwerk faellt nach spaetestens zwei
#     Auswertungen wieder unter die Bedingung und wird entwarnt.
# KORREKTUR (5.2.0): Prozentwert ganzzahlig.
# 'Metric value' in der Mail ist immer der Wert der Metric Measure Column.
# Formatieren laesst sich das nicht - also wird schon in der Query gerundet.
# NEBENWIRKUNG: round(...,0) verschiebt die Ausloeseschwelle um bis zu 0,5
# Prozentpunkte nach unten. Ein Laufwerk mit 15,4 % wird zu 15 und loest
# nicht aus. Fuer eine Speicherplatzwarnung ist das vertretbar; wer es exakt
# braucht, ersetzt round(...,0) durch round(...,1).
$p.Add("summarize FreePercent = round(avgif(Val, Name =~ 'FreeSpacePercentage'), 0), FreiMB = avgif(Val, Name =~ 'FreeSpaceMB'), GesamtGB = max(GB) by bin(TimeGenerated, $bin), Computer = Kurz, Drive, _ResourceId")
$p.Add("where isnotnull(FreePercent)")

# Dimensionen sind Strings. Einheit gleich mit hineinschreiben, damit sie im
# Betreff ohne weitere Bausteine lesbar ist.
$p.Add("extend Size = iff(isnotnull(GesamtGB) and GesamtGB > 0, strcat(tostring(toint(round(GesamtGB, 0))), ' GB'), 'unknown')")

if ($FreeSpaceDimension) {
    # KORREKTUR (5.4.0): Prozent zusaetzlich als DIMENSION.
    # In der Entwarnungs-Mail ist ${...metricValue} leer - die Bedingung ist
    # dort gerade nicht erfuellt, also gibt es keinen Messwert. Dimensionen
    # gehoeren dagegen zur Alert-Instanz und stehen in BEIDEN Mails.
    # Zusaetzliche Instanz-Wechsel entstehen dadurch nicht: 'Prozent' aendert
    # sich exakt dann, wenn sich auch 'Frei' aendert.
    $p.Add("extend Percent = strcat(tostring(toint(FreePercent)), ' %')")

    # BEWUSST aus FreePercent x GesamtGB und NICHT aus FreiMB:
    # FreiMB aendert sich jede Minute und wuerde als Dimension bei jeder
    # Auswertung eine neue Alert-Instanz erzeugen. Der gerundete Prozentwert
    # ist traege - und die GB-Zahl passt dadurch immer zur Prozentangabe.
    $p.Add("extend Free = iff(isnotnull(GesamtGB) and GesamtGB > 0, strcat(tostring(toint(round(GesamtGB * FreePercent / 100.0, 0))), ' GB'), 'unknown')")
    $p.Add("project TimeGenerated, Computer, Drive, Size, Percent, Free, FreePercent, resourceId = _ResourceId")
}
else {
    $p.Add("project TimeGenerated, Computer, Drive, Size, FreePercent, resourceId = _ResourceId")
}

$query = ($p -join " | ")

# Gegenpruefung: die Metric Measure Column muss in der Query vorkommen.
if ($query -notmatch [regex]::Escape($MetricColumn)) {
    Write-Fail "Spalte '$MetricColumn' kommt in der Query nicht vor."
    Write-Sub "`$MetricColumn muss zum project der Query passen."
    exit 1
}

if ($NumberOfEvalPeriods -gt 1 -and $query -notmatch "TimeGenerated") {
    Write-Fail "Bei mehr als einer Auswertungsperiode muss die Query TimeGenerated liefern."
    Write-Sub "Entweder bin(TimeGenerated, ...) in die Query aufnehmen"
    Write-Sub "oder `$NumberOfEvalPeriods auf 1 setzen."
    exit 1
}

if ($MinFailingPeriods -gt $NumberOfEvalPeriods) {
    Write-Fail "`$MinFailingPeriods ($MinFailingPeriods) ist groesser als `$NumberOfEvalPeriods ($NumberOfEvalPeriods)."
    exit 1
}
if ($MinFailingPeriods -eq $NumberOfEvalPeriods -and $NumberOfEvalPeriods -gt 1) {
    Write-Warn2 "'$MinFailingPeriods von $NumberOfEvalPeriods' verlangt, dass JEDER Punkt verletzt."
    Write-Sub "bin() schneidet auf absolute Uhrzeitgrenzen, das Lookback-Fenster haengt"
    Write-Sub "am Auswertungszeitpunkt. Angeschnittene Randbins koennen die Bedingung"
    Write-Sub "still kippen. `$MinFailingPeriods = 1 ist deutlich robuster."
}

# --- Dimension-Splitting auf Computer UND Laufwerk -----------------------------
# Je Kombination eine eigene Alert-Instanz. Die Reihenfolge hier bestimmt die
# dimensions[]-Indizes im Mail-Betreff.
#
# Der frueher hier gebaute $condition-String war die CLI-Grammatik von
# 'az monitor scheduled-query create'. Seit 5.9.0 wird die Regel per PUT
# angelegt, die Kriterien stehen als JSON in $ruleProps. Der String wurde
# entfernt statt auskommentiert - er wurde nirgends mehr gelesen und waere
# beim naechsten Umbau still veraltet.

$description = "Alerts when a volume on a Windows Server drops below " `
             + "$ThresholdPercent % free space."

# --- Dokumentierte Grenzwerte pruefen ---------------------------------
$eigenschaftenGroesse = ($query.Length + $description.Length +
                         $RuleDisplayName.Length + $EmailSubjectTemplate.Length)

if ($description.Length -gt 4096) {
    Write-Fail "Beschreibung hat $($description.Length) Zeichen - erlaubt sind 4096."
    exit 1
}

if ($eigenschaftenGroesse -gt 65536) {
    Write-Fail "Regel-Eigenschaften ca. $([math]::Round($eigenschaftenGroesse/1024,1)) KB - Grenze 64 KB."
    Write-Sub "Meist verursacht durch zu viele Ausnahmen in der Query."
    Write-Sub "Abhilfe: Ausnahmen zusammenfassen oder Server verschieben."
    exit 1
}
elseif ($eigenschaftenGroesse -gt 49152) {
    Write-Warn2 "Regel-Eigenschaften ca. $([math]::Round($eigenschaftenGroesse/1024,1)) KB - Grenze 64 KB."
    Write-Sub "Bei weiter wachsender Ausnahmeliste wird das eng."
}

Write-Sub "Regel        : $RuleName"
Write-Sub "Anzeigename  : $RuleDisplayName"
Write-Sub "Laufwerke    : $($Drives -join ', ')"
Write-Sub "Schwellwert  : < $ThresholdPercent % frei (Spalte: $MetricColumn)"
Write-Sub "Modus        : $NotificationMode"
Write-Sub "Zeitfenster  : $WindowSize (bin: $bin)"
Write-Sub "Ausloesung   : $MinFailingPeriods von $NumberOfEvalPeriods Perioden"
Write-Sub "Server-Ausnahmen : $($alleServerAusnahmen.Count)"
Write-Sub "Laufwerks-Ausnahmen : $($alleDriveAusnahmen.Count)"
if ($alleDriveAusnahmen.Count -gt 0) {
    foreach ($a in ($alleDriveAusnahmen | Sort-Object)) { Write-Sub "  $a" }
}
Write-Line

# =============================================================================
#  STUFE 5 - QUERY-PROBELAUF
# =============================================================================
# KORREKTUR (6): Die fertige Query einmal ausfuehren, bevor eine Regel darauf
# gebaut wird. Eine Regel auf einer leeren Query wird anstandslos angelegt und
# feuert nie - genau das war der Fehlerfall.
Write-Head "STUFE 5 - QUERY-PROBELAUF"

$lookbackMin = 0
$mWin = [regex]::Match($WindowSize, '^PT(?:(\d+)H)?(?:(\d+)M)?$')
if ($mWin.Success) {
    if ($mWin.Groups[1].Success) { $lookbackMin += [int]$mWin.Groups[1].Value * 60 }
    if ($mWin.Groups[2].Success) { $lookbackMin += [int]$mWin.Groups[2].Value }
}
if ($lookbackMin -eq 0) { $lookbackMin = 15 }
$lookbackMin = $lookbackMin * $NumberOfEvalPeriods

Write-Run "Fuehre die Query ueber $lookbackMin Minuten aus..."
$probe = Invoke-AzQuiet @("monitor", "log-analytics", "query",
                          "--workspace", $ws.customerId,
                          "--analytics-query", $query,
                          "--timespan", "PT$($lookbackMin)M", "-o", "json")

if ($null -eq $probe) {
    Write-Fail "Die Query liefert keine Zeilen oder ist fehlerhaft."
    Write-Sub "Ursache: $script:LastAzError"
    Write-Sub "Eine Regel auf dieser Query wuerde nie feuern - Anlage abgebrochen."
    Write-Host ""
    Write-Sub "Query zum Nachstellen im Portal:"
    Write-Host "    $query" -ForegroundColor DarkGray
    exit 1
}

$probe = @($probe)
if ($probe.Count -eq 0) {
    Write-Fail "Die Query liefert 0 Zeilen - Anlage abgebrochen."
    Write-Sub "Haeufigste Ursachen: zu viele Tag-Ausnahmen, falsche Laufwerksliste,"
    Write-Sub "oder es kommen keine InsightsMetrics-Daten im Workspace an."
    Write-Host ""
    Write-Sub "Query zum Nachstellen im Portal:"
    Write-Host "    $query" -ForegroundColor DarkGray
    exit 1
}

$serien = $probe | Group-Object -Property { "$($_.Computer)|$($_.Laufwerk)" }
Write-Ok "$($probe.Count) Zeile(n) in $($serien.Count) Serie(n)."

$unterSchwelle = @()
foreach ($g in $serien) {
    $werte = @($g.Group | ForEach-Object { [double]$_.$MetricColumn })
    $verletzt = @($werte | Where-Object { $_ -lt $ThresholdPercent })
    if ($verletzt.Count -gt 0) {
        $unterSchwelle += [PSCustomObject]@{
            Serie    = $g.Name
            Bins     = $g.Group.Count
            Verletzt = $verletzt.Count
            Min      = ($werte | Measure-Object -Minimum).Minimum
            Feuert   = ($g.Group.Count -ge $NumberOfEvalPeriods -and $verletzt.Count -ge $MinFailingPeriods)
        }
    }
}

if ($unterSchwelle.Count -eq 0) {
    Write-Info2 "Aktuell liegt keine Serie unter $ThresholdPercent %."
}
else {
    Write-Host ""
    Write-Info2 "Serien unter $ThresholdPercent % - so wuerde die Regel jetzt entscheiden:"
    Write-Host ""
    foreach ($u in ($unterSchwelle | Sort-Object Min)) {
        $farbe  = if ($u.Feuert) { "Green" } else { "Yellow" }
        $urteil = if ($u.Feuert) { "FEUERT" } else { "$($u.Verletzt)/$($u.Bins) Bins - zu wenig" }
        Write-Host ("    {0,-26} {1,8:N2} %  {2}" -f $u.Serie, $u.Min, $urteil) -ForegroundColor $farbe
    }

    $stumm = @($unterSchwelle | Where-Object { -not $_.Feuert })
    if ($stumm.Count -gt 0) {
        Write-Host ""
        Write-Warn2 "$($stumm.Count) Serie(n) unter Schwellwert wuerden NICHT feuern."
        Write-Sub "Entweder liegen zu wenige Bins vor (frisch angebundene Server) oder"
        Write-Sub "die Bedingung '$MinFailingPeriods von $NumberOfEvalPeriods' ist zu scharf."
    }
}
Write-Line

# =============================================================================
#  STUFE 6 - ACTION GROUP
# =============================================================================
Write-Head "STUFE 6 - ACTION GROUP"

if ($EmailRecipients.Count -eq 0) {
    Write-Fail "Keine Empfaenger in `$EmailRecipients."
    exit 1
}

Write-Sub "Empfaenger:"
foreach ($e in $EmailRecipients) { Write-Sub "  $($e.Name)  <$($e.Address)>" }
Write-Host ""
Write-Warn2 "'az monitor action-group create' ersetzt die Ressource vollstaendig."
Write-Sub "Im Portal ergaenzte Empfaenger, SMS oder Webhooks gehen dabei verloren."

if ($WhatIfMode) {
    Write-Line
    Write-Head "WHATIF"
    Write-Info2 "Es wird nichts angelegt."
    Write-Host ""
    Write-Sub "Query:"
    Write-Host "    $query" -ForegroundColor DarkGray
    Write-Host ""
    Write-Sub "Kriterien:"
    Write-Host ("    min '{0}' < {1}, {2} von {3} Perioden" -f `
                $MetricColumn, $ThresholdPercent, $MinFailingPeriods, $NumberOfEvalPeriods) -ForegroundColor DarkGray
    $whatIfDims = @("Computer", "Drive", "Size")
    if ($FreeSpaceDimension) { $whatIfDims += @("Percent", "Free") }
    Write-Host ("    Dimensionen: {0}" -f ($whatIfDims -join ", ")) -ForegroundColor DarkGray
    Write-Host ("    API: {0}, Action Group in {1}" -f $RuleApiVersion, $ActionGroupLocation) -ForegroundColor DarkGray
    Write-Host ""
    Write-Sub "Betreff:"
    Write-Host "    $EmailSubjectTemplate" -ForegroundColor DarkGray
    Write-Line
    exit 0
}

# --action email <Name> <Adresse> je Empfaenger
# KORREKTUR (5.8.1): Vertraeglichkeit VOR der ersten Aenderung pruefen.
# In 5.8.0 wurde die Action Group zuerst umgebaut und erst danach die Regel
# angelegt - die dann scheiterte. Ergebnis war ein Zwischenzustand:
# Action Group regional, Regel fehlt. Reihenfolge ist hier alles.
# KORREKTUR (5.9.0): Die Pruefung gilt jetzt der API-Version, nicht der
# Region. Eine regionale Action Group ist zulaessig, sobald die Regel per
# 'az rest' auf 2023-12-01 oder neuer angelegt wird.
if ("$ActionGroupLocation".Replace(" ", "").ToLower() -ne "global") {
    if ([version]($RuleApiVersion -replace "-", ".") -lt [version]"2023.12.01") {
        Write-Fail "Regionale Action Group verlangt API-Version 2023-12-01 oder neuer."
        Write-Sub "Gefordert: '$ActionGroupLocation' bei API '$RuleApiVersion'"
        Write-Sub "Es wurde NICHTS geaendert."
        exit 1
    }
    Write-Info2 "Regionale Action Group '$ActionGroupLocation' - Anlage per PUT auf API $RuleApiVersion."
}

# Region der Action Group pruefen.
# Ohne --location legt Azure die Action Group in "Global" an. Eine bestehende
# Ressource laesst sich nicht umziehen, deshalb hier der Abgleich.
$agAlt = Invoke-AzQuiet @("monitor", "action-group", "show",
                          "--resource-group", $AlertResourceGroup,
                          "--name", $ActionGroupName, "-o", "json")

if ($agAlt) {
    $istRegion  = "$($agAlt.location)".Replace(" ", "").ToLower()
    $sollRegion = "$ActionGroupLocation".Replace(" ", "").ToLower()

    if ($istRegion -ne $sollRegion) {
        Write-Warn2 "Action Group liegt in '$($agAlt.location)', gefordert ist '$ActionGroupLocation'."
        Write-Sub "Die Region einer bestehenden Action Group ist nicht aenderbar."

        if (-not $RecreateActionGroupOnLocationChange) {
            Write-Fail "Abbruch - \$RecreateActionGroupOnLocationChange steht auf \$false."
            exit 1
        }

        Write-Sub "Loesche die Action Group und lege sie in der Zielregion neu an."
        Write-Sub "Die Ressourcen-ID bleibt gleich - die Alert-Regel bleibt gueltig."
        # Invoke-AzQuiet prueft den Exitcode selbst und setzt $LastAzError.
        # Der Rueckgabewert taugt hier NICHT als Erfolgskontrolle: 'delete'
        # liefert keine Ausgabe, die Funktion gibt deshalb auch im Erfolgsfall
        # $null zurueck. Ausgewertet wird darum $script:LastAzError.
        $null = Invoke-AzQuiet @("monitor", "action-group", "delete",
                                 "--resource-group", $AlertResourceGroup,
                                 "--name", $ActionGroupName)
        if ($script:LastAzError) {
            Write-Fail "Loeschen der Action Group fehlgeschlagen."
            Write-Sub "Ursache: $script:LastAzError"
            Write-Sub "Es wurde nichts weiter geaendert."
            exit 1
        }
        Write-Ok "Action Group geloescht."
        Start-Sleep -Seconds 5
    }
    else {
        Write-Ok "Action Group bereits in '$($agAlt.location)'."
    }
}

$agArgs = @("monitor", "action-group", "create",
            "--resource-group", $AlertResourceGroup,
            "--name", $ActionGroupName,
            "--location", $ActionGroupLocation,
            "--short-name", $ActionGroupShortName)
foreach ($e in $EmailRecipients) {
    $agArgs += @("--action", "email", $e.Name, $e.Address)
}
$agArgs += @("-o", "json")

Write-Run "Lege Action Group an bzw. aktualisiere sie..."
$ag = Invoke-AzQuiet $agArgs
if (-not $ag) {
    Write-Fail "Action Group fehlgeschlagen."
    Write-Sub "Ursache: $script:LastAzError"
    exit 1
}
$ActionGroupId = $ag.id
Write-Ok "Action Group bereit: $($ag.name)"
Write-Sub "Region: $($ag.location)"
Write-Sub "Empfaenger aktiv: $(@($ag.emailReceivers).Count)"

# Status der Empfaenger pruefen. Azure deaktiviert Adressen nach Bounces oder
# Spam-Meldungen; die Regel feuert dann korrekt, es kommt nur nichts an.
$gesperrt = @($ag.emailReceivers | Where-Object { $_.status -and $_.status -ne "Enabled" })
if ($gesperrt.Count -gt 0) {
    Write-Host ""
    Write-Warn2 "$($gesperrt.Count) Empfaenger sind nicht auf 'Enabled':"
    foreach ($g in $gesperrt) {
        Write-Host ("    {0,-40} {1}" -f $g.emailAddress, $g.status) -ForegroundColor Red
    }
    Write-Sub "Azure stellt dorthin nicht zu. Im Portal reaktivieren."
}

# ---- Testbenachrichtigung: kann die Action Group ueberhaupt zustellen? ------
# NEU (5.9.1): Bisher wurde nur der Receiver-Status gelesen, nie die
# Zustellung geprueft. Die createNotifications-API verschickt eine ECHTE
# Test-Mail vom Typ 'logalertv2' - derselbe Kanal wie eine Alarm-Mail
# dieser Regel. Damit trennt sich sauber: kommt die Test-Mail an, liegt
# ein 'keine Mail'-Problem an der Regel; kommt sie nicht an, an der
# Zustellung (Spamfilter, fehlende OTP-Bestaetigung der Adresse).
if ($TestActionGroup) {
    Write-Host ""
    Write-Run "Loese eine Testbenachrichtigung ueber die Action Group aus..."

    $testEmpfaenger = @()
    foreach ($e in $EmailRecipients) {
        $testEmpfaenger += @{
            name                 = $e.Name
            emailAddress         = $e.Address
            useCommonAlertSchema = $false
        }
    }
    $testUrl = "https://management.azure.com$($ActionGroupId)" `
             + "/createNotifications?api-version=$TestApiVersion"
    $null = Invoke-AzRestBody -Method "post" -Url $testUrl -Body @{
        alertType      = "logalertv2"
        emailReceivers = $testEmpfaenger
    }

    if ($script:LastAzError) {
        Write-Warn2 "Testbenachrichtigung fehlgeschlagen (nicht kritisch, es geht weiter)."
        Write-Sub "Ursache: $script:LastAzError"
        Write-Sub "Azure-Limit: 2 Testbenachrichtigungen je 5 Minuten und Action Group."
    }
    else {
        Write-Ok "Testbenachrichtigung angefordert - der Betreff enthaelt 'Test'."
        Write-Sub "Kommt sie binnen weniger Minuten NICHT an, liegt es an der"
        Write-Sub "Zustellung, nicht an der Regel:"
        Write-Sub "- Spam/Quarantaene pruefen und diese Absender freischalten:"
        Write-Sub "    azure-noreply@microsoft.com"
        Write-Sub "    azureemail-noreply@microsoft.com"
        Write-Sub "    alerts-noreply@mail.windowsazure.com"
        Write-Sub "- NEUE Adressen brauchen eine einmalige Bestaetigung per"
        Write-Sub "  One-Time-Passcode (Microsoft-Mail, 30 Minuten gueltig, gilt"
        Write-Sub "  danach tenantweit). Nach dem Neuanlegen der Action Group in"
        Write-Sub "  5.8.x/5.9.0 leicht untergegangen - Postfach danach durchsuchen."
    }
}
Write-Line

# =============================================================================
#  STUFE 7 - ALERT-REGEL
# =============================================================================
Write-Head "STUFE 7 - ALERT-REGEL"

Write-Run "Lege Alert-Regel an..."

# KORREKTUR (5.9.0): Anlage per 'az rest' (PUT) statt 'az monitor
# scheduled-query create'.
# Grund: Die von der CLI intern verwendete API-Version akzeptiert nur globale
# Action Groups ("This api version only supports global Action Groups").
# Mit einem direkten PUT auf $RuleApiVersion faellt die Einschraenkung weg -
# derselbe Weg, den New-ArcDisconnectAlert-ARG.ps1 bereits nutzt.
# Nebeneffekt: Betreff und Custom Properties gehen jetzt im selben Aufruf mit,
# der nachgelagerte PATCH ueber Set-AlertEmailSubject entfaellt.

if ($NotificationMode -notin @("AutoResolve", "Suppress")) {
    Write-Fail "`$NotificationMode = '$NotificationMode' ist unbekannt."
    Write-Sub "Erlaubt: 'AutoResolve' oder 'Suppress'."
    exit 1
}

# --- Custom Properties -----------------------------------------------------
# Unterstuetzen dieselbe ${data...}-Ersetzung wie der Betreff und erscheinen
# im Mailtext unter 'Custom properties'. Reihenfolge = Anzeigereihenfolge.
# metricValue ist in der Entwarnungs-Mail null; Azure laesst die Zeile dann
# weg statt sie leer zu zeigen. In der Alarm-Mail steht der Wert.
if ($FreeSpaceDimension) { $freiWert = "$dimPercent free ($dimFree of $dimSize)" }
else                     { $freiWert = "$metricVal % free of $dimSize" }

$customProps = [ordered]@{
    "Server"           = $dimServer
    "Volume"           = $dimDrive
    "Volume size"      = $dimSize
    "Threshold"        = "$ThresholdPercent % free"
    "Monitored drives" = ($Drives -join ', ')
}
if ($freiWert) { $customProps.Insert(3, "Free space", $freiWert) }

# ConvertTo-Json kann kein [ordered] mit Sonderzeichen im Schluessel? Doch -
# aber eine Hashtable ist hier ausdrucksstark genug und vermeidet Ueberraschungen.
$cpHash = @{}
foreach ($k in $customProps.Keys) { $cpHash[$k] = "$($customProps[$k])" }

# --- Dimensionen -----------------------------------------------------------
# Im REST-Body sind Dimensionen ein Array von Objekten. Die Reihenfolge steht
# damit explizit im Script und muss nicht mehr aus einem Condition-String
# abgeleitet werden.
$dimObjekte = @()
foreach ($d in @("Computer", "Drive", "Size")) {
    $dimObjekte += @{ name = $d; operator = "Include"; values = @("*") }
}
if ($FreeSpaceDimension) {
    foreach ($d in @("Percent", "Free")) {
        $dimObjekte += @{ name = $d; operator = "Include"; values = @("*") }
    }
}

# --- Aktionen --------------------------------------------------------------
$alertActions = @{
    actionGroups     = @($ActionGroupId)
    customProperties = $cpHash
}
if (-not [string]::IsNullOrWhiteSpace($EmailSubjectTemplate)) {
    $alertActions["actionProperties"] = @{ "Email.Subject" = $EmailSubjectTemplate }
}

# --- Request-Body ----------------------------------------------------------
$ruleProps = @{
    displayName         = $RuleDisplayName
    description         = $description
    severity            = $Severity
    enabled             = $true
    scopes              = @($WorkspaceResourceId)
    targetResourceTypes = @("Microsoft.HybridCompute/machines")
    evaluationFrequency = $EvaluationFrequency
    windowSize          = $WindowSize
    criteria = @{
        allOf = @(
            @{
                query              = $query
                timeAggregation    = "Minimum"
                metricMeasureColumn = $MetricColumn
                operator           = "LessThan"
                threshold          = $ThresholdPercent
                resourceIdColumn   = "resourceId"
                dimensions         = $dimObjekte
                failingPeriods     = @{
                    numberOfEvaluationPeriods = $NumberOfEvalPeriods
                    minFailingPeriodsToAlert  = $MinFailingPeriods
                }
            }
        )
    }
    checkWorkspaceAlertsStorageConfigured = $false
    actions = $alertActions
}

# autoMitigate und muteActionsDuration schliessen sich aus - die API lehnt
# beide gleichzeitig ab.
if ($NotificationMode -eq "AutoResolve") {
    $ruleProps["autoMitigate"] = $true
}
else {
    $ruleProps["autoMitigate"]        = $false
    $ruleProps["muteActionsDuration"] = $MuteActionsDuration
}

$body = @{
    location   = $Location
    kind       = "LogAlert"
    properties = $ruleProps
}

$url = "https://management.azure.com/subscriptions/$SubscriptionId" `
     + "/resourceGroups/$AlertResourceGroup" `
     + "/providers/Microsoft.Insights/scheduledQueryRules/$RuleName" `
     + "?api-version=$RuleApiVersion"

# KORREKTUR (5.9.1): Body ueber Invoke-AzRestBody statt Out-File.
# 'Out-File -Encoding utf8' schrieb unter Windows PowerShell 5.1 ein BOM,
# an dem 'az rest --body @datei' scheitert - dasselbe Problem, das
# KORREKTUR (7) fuer den frueheren PATCH bereits behoben hatte. Ausserdem
# wurde die Temp-Datei geloescht, BEVOR die Fehlermeldung auf sie verwies.
Write-Run "Erstelle Alert-Regel per 'az rest' (PUT, API $RuleApiVersion)..."
$rule = Invoke-AzRestBody -Method "put" -Url $url -Body $body

if (-not $rule) {
    Write-Fail "Anlage der Alert-Regel fehlgeschlagen."
    Write-Sub "Ursache: $script:LastAzError"
    if ($script:LastAzBodyFile) { Write-Sub "Body liegt zur Diagnose in: $script:LastAzBodyFile" }
    exit 1
}
Write-Ok "Alert-Regel erstellt: $($rule.name)"
Write-Sub "Betreff : $EmailSubjectTemplate"
Write-Sub "Aktionen: $(@($rule.properties.actions.actionGroups).Count) Action Group(s)"

# ---- STATEFUL-KONTROLLE -----------------------------------------------------
# KORREKTUR (5.9.1): Instanzen, die schon VOR diesem Lauf gefeuert haben,
# stehen weiter offen auf 'Fired'. Eine stateful Regel (AutoResolve)
# verschickt fuer eine offene Instanz KEINE weitere Mail - auch nicht nach
# diesem PUT. Genau das erklaert 'Regel korrekt angelegt, aber keine Mail':
# die einzige Mail ging beim URSPRUENGLICHEN Feuern raus (bzw. verloren),
# als die Action Group noch falsch verdrahtet war. Abhilfe: Regel kurz
# deaktivieren - das loest die offenen Instanzen auf - und reaktivieren;
# bei der naechsten Auswertung feuern sie neu, diesmal mit Mail.
if ($RegelExistierteVorher -and $NotificationMode -eq "AutoResolve") {
    Write-Host ""
    Write-Run "Pruefe offene Fired-Alarme der Regel (Stateful-Falle)..."

    $ruleResId = "/subscriptions/$SubscriptionId/resourceGroups/$AlertResourceGroup" `
               + "/providers/Microsoft.Insights/scheduledQueryRules/$RuleName"
    $alertsUrl = "https://management.azure.com/subscriptions/$SubscriptionId" `
               + "/providers/Microsoft.AlertsManagement/alerts" `
               + "?api-version=2019-05-05-preview&monitorCondition=Fired&timeRange=30d"
    $alarmListe = Invoke-AzQuiet @("rest", "--method", "get", "--url", $alertsUrl)

    if (-not $alarmListe) {
        Write-Warn2 "Alarm-Bestand nicht abrufbar - Stateful-Kontrolle entfaellt."
        Write-Sub "Ursache: $script:LastAzError"
        Write-Sub "Bei Bedarf im Portal pruefen: Monitor > Alerts > Fired."
    }
    else {
        # -eq vergleicht in PowerShell case-insensitiv - passend zu
        # Ressourcen-IDs, deren Schreibweise Azure nicht garantiert.
        $offene = @($alarmListe.value | Where-Object {
            "$($_.properties.essentials.alertRule)" -eq $ruleResId
        })

        if ($offene.Count -eq 0) {
            Write-Ok "Kein offener Fired-Alarm auf dieser Regel."
            Write-Sub "Kommt trotzdem keine Mail, feuert die Regel derzeit schlicht"
            Write-Sub "nicht - der Probelauf in Stufe 5 zeigt, ob ein Laufwerk unter"
            Write-Sub "dem Schwellwert liegt."
        }
        elseif (-not $ResetAlertState) {
            Write-Warn2 "$($offene.Count) Alarm(e) stehen offen auf 'Fired':"
            foreach ($o in ($offene | Select-Object -First 10)) {
                Write-Sub ("{0}  seit {1}" -f $o.name, $o.properties.essentials.startDateTime)
            }
            Write-Sub "STATEFUL: fuer offene Instanzen kommt KEINE weitere Mail - die"
            Write-Sub "einzige ging beim urspruenglichen Feuern raus. Abhilfe:"
            Write-Sub "`$ResetAlertState = `$true setzen und erneut ausfuehren, oder die"
            Write-Sub "Regel im Portal einmal deaktivieren und wieder aktivieren."
        }
        else {
            Write-Warn2 "$($offene.Count) Alarm(e) stehen offen - Zustands-Reset (`$ResetAlertState)."
            Write-Sub "Die Regel wird kurz deaktiviert und reaktiviert. Das loest die"
            Write-Sub "offenen Instanzen auf; bei der naechsten Auswertung (spaetestens"
            Write-Sub "in $EvaluationFrequency) feuern sie neu - diesmal MIT Mail."
            Write-Sub "Nebenwirkung: Resolved-Mails fuer die aufgeloesten Instanzen."

            $null = Invoke-AzRestBody -Method "patch" -Url $url `
                                      -Body @{ properties = @{ enabled = $false } }
            if ($script:LastAzError) {
                Write-Fail "Deaktivieren fehlgeschlagen - Reset uebersprungen."
                Write-Sub "Ursache: $script:LastAzError"
            }
            else {
                Start-Sleep -Seconds 15
                $null = Invoke-AzRestBody -Method "patch" -Url $url `
                                          -Body @{ properties = @{ enabled = $true } }
                if ($script:LastAzError) {
                    Write-Fail "REAKTIVIEREN fehlgeschlagen - die Regel ist AUS!"
                    Write-Sub "Ursache: $script:LastAzError"
                    Write-Sub "Sofort manuell einschalten:"
                    Write-Sub "az monitor scheduled-query update -g $AlertResourceGroup -n $RuleName --disabled false"
                }
                else {
                    Write-Ok "Regel deaktiviert und reaktiviert - Alarmzustand zurueckgesetzt."
                }
            }
        }
    }
}

Write-Run "Pruefe den Endzustand der Regel..."
# Ueber denselben API-Pfad lesen wie geschrieben - 'az monitor
# scheduled-query show' wuerde eine andere API-Version verwenden.
$check = Invoke-AzQuiet @("rest", "--method", "get", "--url", $url)
if ($check) {
    $cp = $check.properties
    if ($cp.enabled -eq $true) { Write-Ok "enabled = true" }
    else { Write-Fail "Die Regel ist DEAKTIVIERT - sie wird nicht ausgewertet." }
    Write-Sub "provisioningState: $($cp.provisioningState)"
    Write-Sub "actionGroups     : $(@($cp.actions.actionGroups).Count)"
    Write-Sub "Dimensionen      : $((@($cp.criteria.allOf[0].dimensions).name) -join ', ')"
    Write-Sub "autoMitigate     : $($cp.autoMitigate)"
    if (@($cp.actions.actionGroups).Count -eq 0) {
        Write-Fail "Der Regel ist keine Action Group zugeordnet - es kann keine Mail geben."
    }
    if (-not $cp.actions.actionProperties.'Email.Subject') {
        Write-Warn2 "Kein eigener E-Mail-Betreff hinterlegt."
    }
}
else { Write-Warn2 "Endzustand nicht abrufbar: $script:LastAzError" }
Write-Line

# =============================================================================
#  ZUSAMMENFASSUNG
# =============================================================================
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "Regel               : $RuleName"
Write-Sub "Workspace           : $WorkspaceName"
Write-Sub "Laufwerke           : $($Drives -join ', ')"
Write-Sub "Schwellwert         : < $ThresholdPercent % frei"
Write-Sub "Auswertung          : alle $EvaluationFrequency ueber $WindowSize"
Write-Sub "Ausloesung          : $MinFailingPeriods von $NumberOfEvalPeriods Perioden"
Write-Sub "Benachrichtigung    : $NotificationMode$(if ($NotificationMode -eq 'Suppress') { " ($MuteActionsDuration)" })"
Write-Sub "Splitting           : je Server UND Laufwerk eine eigene Alert-Instanz"
Write-Sub "Empfaenger          : $(@($EmailRecipients).Count)"
Write-Sub "Server-Ausnahmen    : $($alleServerAusnahmen.Count)"
Write-Sub "Laufwerks-Ausnahmen : $($alleDriveAusnahmen.Count)"
Write-Sub "Serien im Probelauf : $($serien.Count), davon unter Schwellwert: $($unterSchwelle.Count)"
Write-Host ""
# KORREKTUR (5.2.1): Der Beispiel-Betreff war ein fest einprogrammierter
# Text und driftete bei jeder Aenderung der Vorlage stillschweigend ab.
# Jetzt wird er aus $EmailSubjectTemplate erzeugt, indem die ${data...}-
# Platzhalter ersetzt werden - er kann damit nicht mehr veralten.
# Die Beispielwerte stammen aus dem Probelauf, sofern dort etwas unter dem
# Schwellwert lag; sonst aus einer beliebigen Serie; sonst generisch.
$bspServer  = "beispielserver"
$bspDrive   = "D:"
$bspGroesse = "500 GB"
$bspFrei    = "45 GB"
$bspWert    = "$($ThresholdPercent - 5)"
$bspQuelle  = "generische Beispielwerte"

$bspZeile = $null
if ($unterSchwelle.Count -gt 0) {
    $bspZeile  = $probe | Where-Object { "$($_.Computer)|$($_.Laufwerk)" -eq $unterSchwelle[0].Serie } |
                 Select-Object -First 1
    $bspQuelle = "Werte aus dem Probelauf"
}
elseif ($probe.Count -gt 0) {
    $bspZeile  = $probe | Select-Object -First 1
    $bspQuelle = "Werte aus dem Probelauf (kein Laufwerk unter dem Schwellwert)"
}

# KORREKTUR (5.8.3): Spaltenzugriff ueber eine Hilfsfunktion.
# Die Spalten hiessen frueher Laufwerk/Groesse/Frei und heissen seit 5.7.0
# Drive/Size/Free. Der Zugriff hier lief noch auf die alten Namen und lieferte
# still Leerstrings - im Beispiel-Betreff fehlten dadurch Laufwerk und
# Groesse. Ein leerer Wert ueberschreibt jetzt keinen Platzhalter mehr.
function Get-Spalte {
    param($Zeile, [string]$Name, [string]$Fallback)
    if (-not $Zeile) { return $Fallback }
    if ($Zeile.PSObject.Properties.Name -notcontains $Name) { return $Fallback }
    $w = "$($Zeile.$Name)"
    if ([string]::IsNullOrWhiteSpace($w)) { return $Fallback }
    return $w
}

if ($bspZeile) {
    $bspServer  = Get-Spalte $bspZeile "Computer"     $bspServer
    $bspDrive   = Get-Spalte $bspZeile "Drive"        $bspDrive
    $bspWert    = Get-Spalte $bspZeile $MetricColumn  $bspWert
    $bspGroesse = Get-Spalte $bspZeile "Size"         $bspGroesse
    $bspFrei    = Get-Spalte $bspZeile "Free"         $bspFrei
}

# KORREKTUR (5.8.3): Leere Tokens ueberspringen.
# Get-DimToken liefert "" fuer eine Dimension, die gar nicht aktiv ist.
# [string]::Replace wirft bei einem leeren oldValue eine Ausnahme.
function Expand-Token {
    param([string]$Text, [string]$Token, [string]$Wert)
    if ([string]::IsNullOrEmpty($Token)) { return $Text }
    return $Text.Replace($Token, "$Wert")
}

$bspErsetzungen = @(
    @{ Token = $dimServer;  Wert = $bspServer  },
    @{ Token = $dimDrive;   Wert = $bspDrive   },
    @{ Token = $dimSize;    Wert = $bspGroesse },
    @{ Token = $dimPercent; Wert = "$bspWert %" },
    @{ Token = $dimFree;    Wert = $bspFrei    },
    @{ Token = $metricVal;  Wert = $bspWert    }
)

$beispielBetreff = $EmailSubjectTemplate
foreach ($e in $bspErsetzungen) {
    $beispielBetreff = Expand-Token $beispielBetreff $e.Token $e.Wert
}
if ($SubjectConditionMode -eq "Token") {
    $beispielBetreff = Expand-Token $beispielBetreff '${data.essentials.monitorCondition}' "Fired"
}

Write-Info2 "Beispiel-Betreff im Alarmfall ($bspQuelle):"
Write-Sub $beispielBetreff
if ($SubjectConditionMode -ne "Token") {
    Write-Sub "Hinweis: '$zustand' ist fester Text und steht auch in der Entwarnungs-Mail."
}
Write-Host ""

Write-Info2 "Custom Properties in der Mail:"
foreach ($k in $customProps.Keys) {
    $v = $customProps[$k]
    foreach ($e in $bspErsetzungen) { $v = Expand-Token $v $e.Token $e.Wert }
    Write-Sub ("{0,-14} : {1}" -f $k, $v)
}
Write-Host ""

Write-Info2 "Dimensions-Zuordnung ($DimensionOrder) - gegen die Mail pruefbar:"
for ($i = 0; $i -lt $dimSortiert.Count; $i++) {
    Write-Sub ("[{0}] {1}" -f $i, $dimSortiert[$i])
}
Write-Sub "Stimmt die Reihenfolge im Abschnitt 'Dimensions' der Mail nicht"
Write-Sub "ueberein, \$DimensionOrder auf 'Condition' stellen."
Write-Host ""

Write-Info2 "Dimensionen der Regel:"
$dimListe = @("Computer", "Drive", "Size")
if ($FreeSpaceDimension) { $dimListe += @("Percent", "Free") }
Write-Sub ($dimListe -join ", ")
if ($FreeSpaceDimension -and $NotificationMode -ne "Suppress") {
    Write-Fail "'Percent'/'Free' sind Dimensionen UND der Modus ist AutoResolve."
    Write-Sub "Jeder Wechsel des Prozentwerts loest die Instanz auf - es kommen"
    Write-Sub "ENTWARNUNGS-MAILS, obwohl das Laufwerk unter dem Schwellwert bleibt."
    Write-Sub "Empfehlung: \$FreeSpaceDimension = \$false ODER \$NotificationMode = 'Suppress'."
}
elseif ($FreeSpaceDimension) {
    Write-Warn2 "'Percent'/'Free' sind Dimensionen - zusammen mit 'Suppress' unkritisch."
}
Write-Host ""

if ($NotificationMode -eq "AutoResolve") {
    Write-Warn2 "Stateful-Verhalten:"
    Write-Sub "Pro Instanz (Server + Laufwerk) geht genau EINE Mail raus. Solange der"
    Write-Sub "Alarm offen steht, kommt keine weitere - auch wenn der Platz weiter"
    Write-Sub "schrumpft. Erst nach der Aufloesung kann dieselbe Instanz erneut feuern."
    Write-Sub "Wer wiederkehrende Erinnerungen will, braucht `$NotificationMode = 'Suppress'"
    Write-Sub "mit `$MuteActionsDuration als Wiederholungsintervall."
    Write-Host ""
}

Write-Info2 "Dokumentierte Grenzwerte im Blick behalten:"
Write-Sub "Stateful-Regel: max. 300 Alarme JE AUSWERTUNG. Bei $(@($Drives).Count) Laufwerken"
Write-Sub "  und wachsendem Serverbestand kann ein Grossereignis das erreichen -"
Write-Sub "  Azure kappt dann still."
Write-Sub "E-Mail: max. 100 Mails pro Stunde JE ADRESSE und Region, und 100"
Write-Sub "  Benachrichtigungen alle 5 Minuten je Alert-Regel."
Write-Sub "Regel-Eigenschaften: aktuell ca. $([math]::Round($eigenschaftenGroesse/1024,1)) KB von 64 KB."
Write-Host ""
Write-Warn2 "Momentaufnahme:"
Write-Sub "Tag-Ausnahmen wurden JETZT aufgeloest und fest in die Query geschrieben."
Write-Sub "Neue Disk-Tags oder neue Server ohne Maschinen-Tags wirken erst nach"
Write-Sub "einem erneuten Lauf dieses Scripts."
Write-Host ""
Write-Info2 "Kontrolle:"
Write-Sub "az monitor scheduled-query show -g $AlertResourceGroup -n $RuleName --query actions"
Write-Sub ".\Test-ArcDiskSpaceAlert.ps1"
Write-Line
