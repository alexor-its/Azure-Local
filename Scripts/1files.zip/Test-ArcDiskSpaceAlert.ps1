#Requires -Version 5.1
<#
.SYNOPSIS
    Diagnose fuer New-ArcDiskSpaceAlert.ps1 - klaert, warum keine E-Mail kommt,
    obwohl Server unter dem Schwellwert liegen.
.DESCRIPTION
    Prueft in sechs Stufen die gesamte Kette vom Datensatz bis zur Mail:

      1  Regel-Definition   enabled, provisioningState, Perioden, Dimensionen,
                            Metric Measure Column, Action Groups, Betreff
      2  Query-Test         fuehrt die IN DER REGEL gespeicherte Query aus und
                            rechnet die Auswertung nach: wie viele Bins gibt es
                            je Serie, wie viele davon verletzen den Schwellwert,
                            und wuerde 'X von Y' greifen
      3  Gegenprobe         dieselbe Metrik OHNE jeden Filter - zeigt, welche
                            Laufwerke unter dem Schwellwert liegen, aber von der
                            Regel gar nicht gesehen werden
      4  Action Group       Empfaenger und deren Status (Azure deaktiviert
                            Empfaenger nach Bounces oder Spam-Meldungen)
      5  Alarm-Historie     gefeuerte Alarme der letzten Tage zu dieser Regel
      6  Bewertung          Zusammenfassung mit konkretem Verdacht

    Das Script veraendert NICHTS. Reine Leseoperationen.

    AENDERUNG IN 1.2.0 - DREI FEHLER IM DIAGNOSE-SCRIPT SELBST
      - windowSize wurde nur im ISO-Format geparst. Liefert die CLI '0:15:00',
        ergab die Umrechnung 0 und die Query lief mit '--timespan PT0M'. Das
        Nullfenster liefert garantiert 0 Zeilen; Stufe 2 und 3 meldeten
        daraufhin einen Konfigurationsfehler, den es nicht gab.
      - Stufe 5 baute den Query-String mit '&' in die URL. az ist unter
        Windows ein Batch-Wrapper, cmd.exe trennt dort den Befehl. Jetzt
        ueber --uri-parameters.
      - Stufe 3 markierte jedes Laufwerk als BLIND, wenn Stufe 2 leer
        zurueckkam. Sichtbarkeit wird jetzt nur bewertet, wenn es etwas zu
        bewerten gibt. Ausnahmelisten stehen im Query-Text und bleiben auch
        ohne Ergebniszeilen pruefbar.

    AENDERUNG IN 1.1.0 - ABGLEICH MIT New-ArcDiskSpaceAlert.ps1 5.1.0
      - Stufe 3 las den Mittelwert ueber zwei Stunden (avg). Ein kurz zuvor
        bereinigtes oder vergroessertes Laufwerk erschien dadurch weiter als
        betroffen. Jetzt arg_max, also der juengste Datensatz - identisch zur
        Logik im Anlage-Script und im Workbook.
      - Stufe 3 zeigt zusaetzlich das Alter jedes Messwerts. Ein Server, der
        nicht mehr liefert, behaelt seinen letzten Wert; der sieht wie ein
        gueltiger Status aus, loest aber weder Alarm aus noch entwarnt er.
      - Neuer Parameter $MaxDataAgeMinutes, passend zum Anlage-Script.

    HINWEIS ZU $ExpectedDrives
      Diese Liste ist eine KOPIE aus New-ArcDiskSpaceAlert.ps1 und wird nicht
      automatisch abgeglichen. Wird $Drives dort geaendert, muss sie hier
      nachgezogen werden - sonst meldet Stufe 3 falsche Gruende.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 25.08.2026
    Version     : 1.2.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Test-ArcDiskSpaceAlert.ps1
#>

# =============================================================================
#  KONFIGURATION
# =============================================================================

$PowerShellMode         = "Compat"          # "Compat" (5.1 + 7.x) oder "Seven"

$SubscriptionId         = "33207861-9482-4afb-9786-eba3a0265bef"
$WorkspaceName          = "law-LDK-VirtualServer"
$WorkspaceResourceGroup = "rg-arcmgmt"
$AlertResourceGroup     = "rg-ArcMonitoringMgmt"
$RuleName               = "alert-arc-disk-below-15pct"
$ActionGroupName        = "ag-arc-diskspace"

# Erwartungswerte aus dem Anlage-Script - dienen dem Soll-Ist-Abgleich.
$ExpectedThreshold      = 15
$ExpectedDrives         = @("C:", "D:", "E:")

# Ab welchem Alter gilt ein Messwert als veraltet. Muss zu
# $MaxDataAgeMinutes in New-ArcDiskSpaceAlert.ps1 passen.
$MaxDataAgeMinutes      = 10

# Ersatz-Lookback, falls windowSize der Regel nicht lesbar ist.
$FallbackLookbackMinutes = 30

# Zeitraum fuer die Alarm-Historie in Tagen.
$AlertHistoryDays       = 7

$env:PYTHONWARNINGS     = "ignore"
$ErrorActionPreference  = "Continue"

# =============================================================================
#  AUSGABE
# =============================================================================
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

function Write-Line  { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$SymOk  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$SymErr  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$SymWarn  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$SymInfo  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$SymRun  $(Get-Date -f '[HH:mm:ss]') $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

# Sammelt Verdachtsmomente fuer die Schlussbewertung.
$script:Befunde = New-Object System.Collections.Generic.List[string]
function Add-Befund { param($M) $script:Befunde.Add($M) | Out-Null }

# =============================================================================
#  AZURE-CLI-HELFER
# =============================================================================
$script:LastAzError = $null

function Assert-AzSuccess {
    <#
      Externe Programme melden Fehler ueber den Exitcode, nicht ueber
      Exceptions. try/catch allein wuerde sie nicht sehen.
    #>
    param([int]$ExitCode, [string]$ErrorText, [string]$Context)
    if ($ExitCode -ne 0) {
        $script:LastAzError = "$Context (Exitcode $ExitCode): $ErrorText"
        return $false
    }
    return $true
}

function Invoke-AzQuiet {
    <#
      Ruft az auf, trennt stdout von stderr und liefert das geparste JSON.
      Argumente als Array, damit die Windows-Kommandozeile nichts zerlegt.
    #>
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $errFile = [System.IO.Path]::GetTempFileName()
    try {
        $raw  = & az @Arguments 2>$errFile
        $code = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if (-not (Assert-AzSuccess -ExitCode $code -ErrorText ($err | Out-String).Trim() `
                                   -Context ("az " + ($Arguments[0..1] -join " ")))) {
            return $null
        }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{', '['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally { Remove-Item $errFile -ErrorAction SilentlyContinue }
}

function ConvertFrom-Iso8601Minutes {
    # KORREKTUR (1.2.0): Die Azure CLI liefert windowSize je nach Version als
    # ISO-8601 ('PT15M') ODER im TimeSpan-Format ('0:15:00'). Beim zweiten Fall
    # scheiterte die Regex still und gab 0 zurueck. Daraus wurde '--timespan
    # PT0M' - ein Nullfenster, das garantiert keine Zeile liefert. Die Stufen 2
    # und 3 meldeten daraufhin, die Regel sehe keine Daten. Ein Diagnosefehler,
    # der wie ein Konfigurationsfehler aussah.
    param([string]$Iso)
    if ([string]::IsNullOrWhiteSpace($Iso)) { return 0 }

    # Variante TimeSpan: 0:15:00 oder 1.02:00:00
    if ($Iso -match '^\d+[:.]') {
        $ts = [TimeSpan]::Zero
        if ([TimeSpan]::TryParse($Iso, [ref]$ts)) {
            return [int][math]::Ceiling($ts.TotalMinutes)
        }
    }

    $m = [regex]::Match($Iso, '^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$')
    if (-not $m.Success) { return 0 }
    $min = 0
    if ($m.Groups[1].Success) { $min += [int]$m.Groups[1].Value * 1440 }
    if ($m.Groups[2].Success) { $min += [int]$m.Groups[2].Value * 60 }
    if ($m.Groups[3].Success) { $min += [int]$m.Groups[3].Value }
    if ($m.Groups[4].Success) { $min += [math]::Ceiling([int]$m.Groups[4].Value / 60.0) }
    return $min
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe PowerShell-Version..."
$psVer = $PSVersionTable.PSVersion
if ($PowerShellMode -eq "Seven" -and $psVer.Major -lt 7) {
    Write-Fail "PowerShellMode 'Seven' verlangt PowerShell 7.x - gefunden $psVer."
    exit 1
}
Write-Ok "PowerShell $psVer (Modus: $PowerShellMode)"
if ($psVer.Major -ge 7 -and ($psVer.Major -gt 7 -or $psVer.Minor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Sub "PSNativeCommandUseErrorActionPreference deaktiviert."
}

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzQuiet @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - 'az monitor scheduled-query' braucht mindestens 2.54.0."
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzQuiet @("account", "show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Wechsle Subscription auf $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if (-not (Assert-AzSuccess -ExitCode $LASTEXITCODE -ErrorText "" -Context "az account set")) {
        Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1
    }
}
Write-Sub "Subscription: $SubscriptionId"

Write-Run "Lade Workspace..."
$ws = Invoke-AzQuiet @("monitor", "log-analytics", "workspace", "show",
                       "--resource-group", $WorkspaceResourceGroup,
                       "--name", $WorkspaceName, "-o", "json")
if (-not $ws) { Write-Fail "Workspace nicht erreichbar: $script:LastAzError"; exit 1 }
Write-Ok "Workspace: $($ws.name) / $($ws.customerId)"
Write-Line

# =============================================================================
#  STUFE 1 - REGEL-DEFINITION
# =============================================================================
Write-Head "STUFE 1 - REGEL-DEFINITION"

$rule = Invoke-AzQuiet @("monitor", "scheduled-query", "show",
                         "--resource-group", $AlertResourceGroup,
                         "--name", $RuleName, "-o", "json")
if (-not $rule) {
    Write-Fail "Regel '$RuleName' nicht gefunden."
    Write-Sub "Ursache: $script:LastAzError"
    Write-Sub "Das Anlage-Script ist vermutlich vorher mit exit 1 ausgestiegen."
    exit 1
}
Write-Ok "Regel gefunden."

$crit = $rule.criteria.allOf[0]

if ($rule.enabled -eq $true) { Write-Ok "enabled            : true" }
else { Write-Fail "enabled            : $($rule.enabled)"; Add-Befund "Die Regel ist DEAKTIVIERT." }

Write-Sub "provisioningState  : $($rule.provisioningState)"
if ($rule.provisioningState -and $rule.provisioningState -ne "Succeeded") {
    Add-Befund "provisioningState ist '$($rule.provisioningState)' - die Regel wird nicht ausgewertet."
}

Write-Sub "evaluationFrequency: $($rule.evaluationFrequency)"
Write-Sub "windowSize         : $($rule.windowSize)"
Write-Sub "autoMitigate       : $($rule.autoMitigate)"
Write-Sub "muteActionsDuration: $($rule.muteActionsDuration)"
Write-Sub "operator           : $($crit.operator)  threshold: $($crit.threshold)"
Write-Sub "timeAggregation    : $($crit.timeAggregation)"
Write-Sub "metricMeasureColumn: $($crit.metricMeasureColumn)"
Write-Sub "resourceIdColumn   : $($crit.resourceIdColumn)"

$evalPeriods = [int]$crit.failingPeriods.numberOfEvaluationPeriods
$minFailing  = [int]$crit.failingPeriods.minFailingPeriodsToAlert
Write-Sub "failingPeriods     : $minFailing von $evalPeriods"

$dims = @($crit.dimensions | ForEach-Object { "$($_.name) $($_.operator) $($_.values -join ',')" })
Write-Sub "dimensions         : $($dims -join '  |  ')"

$ags = @($rule.actions.actionGroups)
if ($ags.Count -eq 0) {
    Write-Fail "actionGroups       : KEINE"
    Add-Befund "Der Regel ist keine Action Group zugeordnet - es kann keine Mail geben."
}
else {
    Write-Ok "actionGroups       : $($ags.Count)"
    foreach ($a in $ags) { Write-Sub "  $($a.Split('/')[-1])" }
}

$subj = $null
if ($rule.actions.actionProperties) { $subj = $rule.actions.actionProperties.'Email.Subject' }
if ($subj) { Write-Sub "Email.Subject      : gesetzt" }
else       { Write-Warn2 "Email.Subject nicht gesetzt - Standardbetreff. Kein Grund fuer fehlende Mails." }

# --- Soll-Ist-Abgleich ---
if ([double]$crit.threshold -ne [double]$ExpectedThreshold) {
    Write-Warn2 "Schwellwert in der Regel ist $($crit.threshold), erwartet war $ExpectedThreshold."
    Add-Befund "Schwellwert weicht ab: Regel $($crit.threshold), erwartet $ExpectedThreshold."
}

# --- Periodenlogik bewerten ---
$winMin  = ConvertFrom-Iso8601Minutes -Iso $rule.windowSize
$lookMin = $winMin * $evalPeriods
Write-Host ""
Write-Info2 "Query-Lookback = windowSize x numberOfEvaluationPeriods = $lookMin Minuten."
if ($minFailing -ge $evalPeriods -and $evalPeriods -gt 1) {
    Write-Warn2 "'$minFailing von $evalPeriods' verlangt, dass JEDER Punkt verletzt."
    Write-Sub "bin() schneidet auf absolute Uhrzeitgrenzen, das Lookback-Fenster haengt"
    Write-Sub "am Auswertungszeitpunkt. Angeschnittene Randbins koennen die Bedingung"
    Write-Sub "still kippen. minFailingPeriodsToAlert = 1 waere robuster."
    Add-Befund "failingPeriods '$minFailing von $evalPeriods' ist anfaellig fuer Bin-Versatz."
}
Write-Line

# =============================================================================
#  STUFE 2 - QUERY-TEST
# =============================================================================
Write-Head "STUFE 2 - QUERY-TEST"

$ruleQuery = $crit.query
if ([string]::IsNullOrWhiteSpace($ruleQuery)) {
    Write-Fail "Die Regel enthaelt keine Query."
    exit 1
}

Write-Info2 "Query aus der Regel:"
Write-Host "    $ruleQuery" -ForegroundColor DarkGray
Write-Host ""

# KORREKTUR (1.2.0): Nullfenster abfangen.
# Ein '--timespan PT0M' liefert garantiert 0 Zeilen und erzeugt damit einen
# Befund, der nichts mit der Regel zu tun hat.
if ($lookMin -le 0) {
    Write-Warn2 "Lookback konnte nicht aus windowSize ermittelt werden."
    Write-Sub "Gelesener Wert: '$($rule.windowSize)'"
    Write-Sub "Ersatzweise $FallbackLookbackMinutes Minuten - der Soll-Ist-Abgleich"
    Write-Sub "der Periodenlogik ist damit nicht aussagekraeftig."
    $lookMin = $FallbackLookbackMinutes
    Add-Befund "windowSize der Regel war nicht lesbar - Lookback ersatzweise $FallbackLookbackMinutes Min."
}

$timespan = "PT$($lookMin)M"
Write-Run "Fuehre die Query ueber $timespan aus..."

$rows = Invoke-AzQuiet @("monitor", "log-analytics", "query",
                         "--workspace", $ws.customerId,
                         "--analytics-query", $ruleQuery,
                         "--timespan", $timespan, "-o", "json")

if ($null -eq $rows) {
    Write-Fail "Query fehlgeschlagen oder ohne Ergebnis."
    Write-Sub "Ursache: $script:LastAzError"
    Add-Befund "Die Query der Regel liefert keine Zeilen - deshalb kann nichts feuern."
    $rows = @()
}
else {
    $rows = @($rows)
    if ($rows.Count -eq 0) {
        Write-Fail "0 Zeilen. Die Regel sieht ueberhaupt keine Daten."
        Add-Befund "Die Query der Regel liefert 0 Zeilen - meist durch die fest eingebauten Ausnahmen."
    }
    else {
        Write-Ok "$($rows.Count) Zeile(n)."
    }
}

$serienUnterSchwelle = @()

if ($rows.Count -gt 0) {
    $metricCol = $crit.metricMeasureColumn
    $gruppen = $rows | Group-Object -Property { "$($_.Computer)|$($_.Drive)" }

    Write-Sub "Serien (Computer|Drive): $($gruppen.Count)"
    Write-Host ""
    Write-Info2 "Nachrechnung der Auswertung (Schwellwert $($crit.threshold), '$minFailing von $evalPeriods'):"
    Write-Host ""
    Write-Host ("    {0,-26} {1,6} {2,10} {3,9}  {4}" -f "Serie", "Bins", "Verletzt", "Min %", "Urteil")
    Write-Host ("    " + ("-" * 68)) -ForegroundColor DarkGray

    foreach ($g in ($gruppen | Sort-Object Name)) {
        $werte = @($g.Group | ForEach-Object { [double]$_.$metricCol })
        $unter = @($werte | Where-Object { $_ -lt [double]$crit.threshold })
        $minW  = ($werte | Measure-Object -Minimum).Minimum

        $wuerdeFeuern = ($g.Group.Count -ge $evalPeriods) -and ($unter.Count -ge $minFailing)
        $urteil = if ($wuerdeFeuern) { "FEUERT" }
                  elseif ($unter.Count -gt 0 -and $g.Group.Count -lt $evalPeriods) { "zu wenig Bins" }
                  elseif ($unter.Count -gt 0) { "zu wenig Verletzungen" }
                  else { "-" }

        $farbe = if ($wuerdeFeuern) { "Green" }
                 elseif ($unter.Count -gt 0) { "Yellow" }
                 else { "DarkGray" }

        if ($unter.Count -gt 0) {
            $serienUnterSchwelle += [PSCustomObject]@{
                Serie = $g.Name; Bins = $g.Group.Count; Verletzt = $unter.Count
                Min = $minW; Feuert = $wuerdeFeuern
            }
        }

        Write-Host ("    {0,-26} {1,6} {2,10} {3,9:N2}  {4}" -f `
                    $g.Name, $g.Group.Count, $unter.Count, $minW, $urteil) -ForegroundColor $farbe
    }

    Write-Host ""
    $feuernde = @($serienUnterSchwelle | Where-Object { $_.Feuert })
    $knapp    = @($serienUnterSchwelle | Where-Object { -not $_.Feuert })

    if ($feuernde.Count -gt 0) {
        Write-Ok "$($feuernde.Count) Serie(n) erfuellen die Alarmbedingung JETZT."
        Write-Sub "Die Auswertung ist also nicht die Ursache - weiter bei Stufe 4 und 5."
    }
    if ($knapp.Count -gt 0) {
        Write-Warn2 "$($knapp.Count) Serie(n) liegen unter dem Schwellwert, erfuellen '$minFailing von $evalPeriods' aber nicht."
        Add-Befund "$($knapp.Count) Serie(n) unter Schwellwert scheitern an der Periodenbedingung."
    }
    if ($serienUnterSchwelle.Count -eq 0) {
        Write-Info2 "Keine Serie unter dem Schwellwert - im Sichtbereich der Regel ist alles in Ordnung."
    }
}
Write-Line

# =============================================================================
#  STUFE 3 - GEGENPROBE OHNE FILTER
# =============================================================================
Write-Head "STUFE 3 - GEGENPROBE OHNE FILTER"

Write-Run "Frage alle Laufwerke unter $ExpectedThreshold % ab - ohne jede Ausnahme..."

# KORREKTUR (1.1.0): arg_max statt avg.
# avg mittelte ueber die vollen zwei Stunden. Ein Laufwerk, das vor einer
# Stunde bereinigt wurde, erschien dadurch weiter als betroffen - und dieses
# Script haette einen Alarm bestaetigt, den es nicht mehr gibt. Ein
# Diagnosewerkzeug, das die Fehldiagnose stuetzt, ist schlimmer als keines.
$roh = "InsightsMetrics" `
     + " | where Origin == 'vm.azm.ms'" `
     + " | where Namespace == 'LogicalDisk' and Name == 'FreeSpacePercentage'" `
     + " | extend Drive = tostring(todynamic(Tags)['vm.azm.ms/mountId'])" `
     + " | extend Kurz = tolower(tostring(split(Computer, '.')[0]))" `
     + " | summarize arg_max(TimeGenerated, Val) by Kurz, Drive" `
     + " | project Kurz, Drive, FreePercent = round(Val, 2)," `
     +   " AlterMin = datetime_diff('minute', now(), TimeGenerated)" `
     + " | where FreePercent < $ExpectedThreshold" `
     + " | order by FreePercent asc"

$rohRows = Invoke-AzQuiet @("monitor", "log-analytics", "query",
                            "--workspace", $ws.customerId,
                            "--analytics-query", $roh,
                            "--timespan", "PT2H", "-o", "json")

if ($null -eq $rohRows) {
    Write-Warn2 "Gegenprobe fehlgeschlagen: $script:LastAzError"
}
else {
    $rohRows = @($rohRows)
    if ($rohRows.Count -eq 0) {
        Write-Info2 "Auch ohne Filter liegt kein Laufwerk unter $ExpectedThreshold %."
        Write-Sub "Dann stimmt die Ausgangsbeobachtung nicht mehr, oder die Daten sind aelter als 2 Stunden."
        Add-Befund "Ohne Filter findet sich aktuell kein Laufwerk unter dem Schwellwert."
    }
    else {
        Write-Ok "$($rohRows.Count) Laufwerk(e) unter $ExpectedThreshold %:"
        Write-Host ""

        # KORREKTUR (1.2.0): Sichtbarkeit nur bewerten, wenn die Regel-Query
        # ueberhaupt Zeilen geliefert hat. Lief sie ins Leere, waere JEDES
        # Laufwerk 'BLIND' - eine Aussage ueber das Diagnose-Script, nicht
        # ueber die Regel.
        $sichtbar = @{}
        foreach ($r in $rows) { $sichtbar["$($r.Computer)|$($r.Drive)"] = $true }
        $bewertbar = ($rows.Count -gt 0)

        if (-not $bewertbar) {
            Write-Warn2 "Die Regel-Query lieferte keine Zeilen - Sichtbarkeit nicht bewertbar."
            Write-Sub "Die folgende Liste zeigt nur die Ist-Werte. Ob die Regel sie sieht,"
            Write-Sub "laesst sich erst nach einem erfolgreichen Lauf von Stufe 2 sagen."
            Write-Host ""
        }

        $blind = 0
        foreach ($r in $rohRows) {
            $key = "$($r.Kurz)|$($r.Drive)"
            $gesehen = $sichtbar.ContainsKey($key)

            # Warum nicht gesehen? Ausnahmelisten stehen im Query-Text und
            # lassen sich auch ohne Ergebniszeilen sicher pruefen.
            $grund = ""
            if (-not $gesehen) {
                if ($bewertbar) { $blind++ }
                if ($ExpectedDrives -notcontains $r.Drive) { $grund = "Laufwerk nicht in `$Drives" }
                elseif ($ruleQuery -match [regex]::Escape("'$($r.Kurz)'")) { $grund = "Server steht in der Ausnahmeliste" }
                elseif ($ruleQuery -match [regex]::Escape("'$key'")) { $grund = "Laufwerk steht in der Ausnahmeliste" }
                else { $grund = "durch Namensmuster oder _ResourceId-Filter entfernt" }
            }

            $farbe = if ($gesehen) { "Green" } elseif ($bewertbar) { "Red" } else { "Gray" }
            $marke = if ($gesehen) { "sichtbar" } elseif ($bewertbar) { "BLIND" } else { "unklar" }
            if (-not $bewertbar -and $grund -match "Ausnahmeliste") { $marke = "BLIND" }

            # Alter mitfuehren: ein eingefrorener Wert sieht wie ein gueltiger
            # Status aus, kann aber weder Alarm ausloesen noch entwarnen.
            $alterTxt = ""
            if ($null -ne $r.AlterMin) {
                $alterTxt = "{0,4} Min" -f [int]$r.AlterMin
                if ([int]$r.AlterMin -gt $MaxDataAgeMinutes) {
                    $alterTxt += " VERALTET"
                    $farbe = "Yellow"
                    if (-not $gesehen) { $grund = "Messwert veraltet - Server liefert nicht mehr" }
                }
            }

            Write-Host ("    {0,-26} {1,8:N2} %  {2,-9} {3,-14} {4}" -f $key, $r.FreePercent, $marke, $alterTxt, $grund) -ForegroundColor $farbe
        }

        if ($blind -gt 0 -and $bewertbar) {
            Write-Host ""
            Write-Fail "$blind von $($rohRows.Count) betroffenen Laufwerken sind fuer die Regel unsichtbar."
            Add-Befund "$blind betroffene Laufwerk(e) werden von der Query ausgefiltert - das ist die wahrscheinlichste Ursache."
        }
    }
}
Write-Line

# =============================================================================
#  STUFE 4 - ACTION GROUP
# =============================================================================
Write-Head "STUFE 4 - ACTION GROUP"

$ag = Invoke-AzQuiet @("monitor", "action-group", "show",
                       "--resource-group", $AlertResourceGroup,
                       "--name", $ActionGroupName, "-o", "json")
if (-not $ag) {
    Write-Fail "Action Group '$ActionGroupName' nicht gefunden: $script:LastAzError"
    Add-Befund "Action Group nicht auffindbar."
}
else {
    if ($ag.enabled -eq $true) { Write-Ok "Action Group aktiv." }
    else { Write-Fail "Action Group ist DEAKTIVIERT."; Add-Befund "Die Action Group ist deaktiviert." }

    $recv = @($ag.emailReceivers)
    if ($recv.Count -eq 0) {
        Write-Fail "Keine E-Mail-Empfaenger hinterlegt."
        Add-Befund "Die Action Group hat keine E-Mail-Empfaenger."
    }
    else {
        Write-Ok "$($recv.Count) E-Mail-Empfaenger:"
        foreach ($r in $recv) {
            $st = if ($r.status) { $r.status } else { "(kein Status)" }
            if ($st -eq "Enabled") {
                Write-Host ("    {0,-14} {1,-40} {2}" -f $r.name, $r.emailAddress, $st) -ForegroundColor Green
            }
            else {
                Write-Host ("    {0,-14} {1,-40} {2}" -f $r.name, $r.emailAddress, $st) -ForegroundColor Red
                Add-Befund "Empfaenger '$($r.emailAddress)' hat Status '$st' - Azure stellt dorthin nicht zu."
            }
        }
        Write-Host ""
        Write-Info2 "Absender der Alarmmails: azure-noreply@microsoft.com"
        Write-Sub "Bei Stille trotz gefeuertem Alarm: Quarantaene, Spamfilter und"
        Write-Sub "Transportregeln der Empfaengerdomaene pruefen."
    }
}
Write-Line

# =============================================================================
#  STUFE 5 - ALARM-HISTORIE
# =============================================================================
Write-Head "STUFE 5 - ALARM-HISTORIE"

# KORREKTUR (1.2.0): Query-String ueber --uri-parameters statt ueber '&'.
# az ist unter Windows ein Batch-Wrapper. cmd.exe interpretiert das '&' in der
# URL als Befehlstrenner und versucht 'timeRange' als eigenes Kommando zu
# starten - daher die Meldung "'timeRange' is not recognized as an internal or
# external command". --uri-parameters umgeht das Problem, weil kein '&' mehr
# im Argument steht.
$url = "https://management.azure.com/subscriptions/$SubscriptionId" `
     + "/providers/Microsoft.AlertsManagement/alerts"
$zeitraum = $(if ($AlertHistoryDays -le 1) { "1d" } else { "7d" })

Write-Run "Lade gefeuerte Alarme der letzten $AlertHistoryDays Tage..."
$alerts = Invoke-AzQuiet @("rest", "--method", "get", "--url", $url,
                           "--uri-parameters",
                           "api-version=2019-05-05-preview",
                           "timeRange=$zeitraum")

if (-not $alerts) {
    Write-Warn2 "Alarm-Historie nicht abrufbar: $script:LastAzError"
    Write-Sub "Alternativ im Portal: Monitor - Alerts - Filter auf '$RuleName'."
}
else {
    $meine = @($alerts.value | Where-Object {
        $_.properties.essentials.alertRule -eq $RuleName
    })

    if ($meine.Count -eq 0) {
        Write-Fail "Kein einziger Alarm dieser Regel in den letzten $AlertHistoryDays Tagen."
        Add-Befund "Die Regel hat nie gefeuert - das Problem liegt VOR der Benachrichtigung (Query oder Perioden)."
    }
    else {
        Write-Ok "$($meine.Count) Alarm(e) gefunden:"
        Write-Host ""
        foreach ($a in ($meine | Sort-Object { $_.properties.essentials.startDateTime } -Descending | Select-Object -First 20)) {
            $e = $a.properties.essentials
            $farbe = if ($e.monitorCondition -eq "Fired") { "Yellow" } else { "DarkGray" }
            Write-Host ("    {0}  {1,-9} {2,-9} {3}" -f `
                        ([datetime]$e.startDateTime).ToString("dd.MM. HH:mm"),
                        $e.monitorCondition, $e.alertState, $e.targetResourceName) -ForegroundColor $farbe
        }

        $offen = @($meine | Where-Object { $_.properties.essentials.monitorCondition -eq "Fired" })
        if ($offen.Count -gt 0) {
            Write-Host ""
            Write-Warn2 "$($offen.Count) Alarm(e) stehen noch auf 'Fired'."
            Write-Sub "Bei autoMitigate = true ist die Regel STATEFUL: pro Instanz geht genau"
            Write-Sub "EINE Mail raus. Solange der Alarm offen ist, kommt keine weitere -"
            Write-Sub "auch wenn der Platz weiter schrumpft."
            Add-Befund "$($offen.Count) Alarm(e) sind bereits offen - deshalb kommen keine neuen Mails (stateful)."
        }
    }
}
Write-Line

# =============================================================================
#  BEWERTUNG
# =============================================================================
Write-Head "BEWERTUNG"

if ($script:Befunde.Count -eq 0) {
    Write-Ok "Keine Auffaelligkeit gefunden."
    Write-Sub "Wenn trotzdem keine Mail ankommt, liegt es am Mailweg der Empfaengerdomaene."
}
else {
    Write-Warn2 "$($script:Befunde.Count) Befund(e):"
    Write-Host ""
    $i = 1
    foreach ($b in $script:Befunde) {
        Write-Host ("    {0}. {1}" -f $i, $b) -ForegroundColor Yellow
        $i++
    }
}

Write-Host ""
Write-Info2 "Weitere Kontrollen von Hand:"
Write-Sub "az monitor scheduled-query show -g $AlertResourceGroup -n $RuleName --query criteria.allOf[0].query -o tsv"
Write-Sub "az monitor action-group show -g $AlertResourceGroup -n $ActionGroupName --query emailReceivers"
Write-Sub "Portal: Monitor - Alerts - Alert rules - '$RuleName' - History"
Write-Line
