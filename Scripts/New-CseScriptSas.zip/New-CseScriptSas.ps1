﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Erzeugt ein SAS-Token fuer den Script-Container der Custom Script Extension
    und gibt die fertigen Download-URLs zum Einfuegen in den Deployment-Wizard aus.
.DESCRIPTION
    Der Storage Account ldkpostdeploymentscripts erlaubt keinen anonymen
    Blob-Zugriff. Die Custom Script Extension bricht deshalb beim Download mit
    HTTP 409 "Public access is not permitted on this storage account" ab.

    Das Script:
      1. Prueft Azure CLI, CLI-Version und Login
      2. Ermittelt die Resource Group des Storage Accounts
      3. Zeigt die aktuelle Public-Access-Konfiguration an
      4. Liest einen Account Key und erzeugt ein Read-only SAS-Token
         auf Container-Ebene (gilt damit fuer alle Scripts im Container)
      5. Verifiziert das Token per HTTP-HEAD gegen jedes Script
      6. Gibt Token und vollstaendige URLs aus

    Das ausgegebene Token wird im Wizard ab Version 3.2.0 im Feld
    "SAS-Token" unter der Script-Auswahl eingetragen. Es wird dort im
    localStorage gespeichert und automatisch an alle Preset-URLs angehaengt,
    die einen privaten Storage Account nutzen.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 28.08.2026
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\New-CseScriptSas.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - alle Parameter fest im Script hinterlegt
# =============================================================================
$PowerShellMode        = "Compat"      # "Compat" = 5.1 + 7.x | "Seven" = nur 7.x

$SubscriptionId        = "33207861-9482-4afb-9786-eba3a0265bef"
$StorageAccountName    = "ldkpostdeploymentscripts"
$ContainerName         = "scripts"
$ResourceGroupName     = ""            # leer = automatisch ermitteln

# Scripts, fuer die URLs ausgegeben werden sollen
$BlobNames = @(
    "Setup-DeOnly-WS.ps1",
    "Setup-DeOnly-AVD.ps1"
)

# SAS-Parameter
$SasPermissions        = "rl"          # r = read, l = list
$SasExpiry             = "2036-12-31T23:59:59Z"
$SasHttpsOnly          = $true
$VerifyWithHttpHead    = $true         # Token nach Erzeugung testen

$MinAzVersion          = "2.60.0"

# =============================================================================
# [ INITIALISIERUNG ]
# =============================================================================
$ErrorActionPreference = "Continue"

try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

# Symbole zur Laufzeit erzeugen - Quellcode bleibt reines ASCII
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

function Write-Line {
    param([string]$Text, [string]$Color = "White", [int]$Indent = 0)
    Write-Host ((" " * $Indent) + $Text) -ForegroundColor $Color
}
function Write-Sep     { Write-Line ("=" * 60) "White" }
function Write-Section { param([string]$Name) Write-Sep; Write-Line ("[ " + $Name + " ]") "White"; }
function Get-Stamp     { return "[" + (Get-Date -Format "HH:mm:ss") + "] " }
function Write-Ok      { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymOk   + "  " + $Text) "Green"  $Indent }
function Write-Err     { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymErr  + "  " + $Text) "Red"    $Indent }
function Write-Warn    { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymWarn + "  " + $Text) "Yellow" $Indent }
function Write-Info    { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymInfo + "  " + $Text) "Cyan"   $Indent }
function Write-Run     { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymRun  + "  " + $Text) "Cyan"   $Indent }

# az meldet Fehler ueber den Exit Code, nicht ueber Exceptions
function Assert-AzSuccess {
    param([string]$Context, [switch]$Fatal)
    if ($LASTEXITCODE -eq 0) {
        Write-Ok ($Context + " erfolgreich") 4
        return $true
    }
    Write-Err ($Context + " fehlgeschlagen (ExitCode " + $LASTEXITCODE + ")") 4
    if ($Fatal) {
        Write-Err "Abbruch." 4
        Write-Sep
        exit 1
    }
    return $false
}

# Wrapper fuer az-Aufrufe, deren stderr-Ausgaben unterdrueckt werden sollen
function Invoke-AzQuiet {
    param([string[]]$AzArguments)
    $errFile = Join-Path $env:TEMP ("az-err-" + [guid]::NewGuid().ToString() + ".txt")
    try {
        $azOutput = & az @AzArguments 2> $errFile
        return $azOutput
    } finally {
        Remove-Item -Path $errFile -Force -ErrorAction SilentlyContinue
    }
}

function Compare-Version {
    param([string]$Left, [string]$Right)
    $a = $Left  -split "\."
    $b = $Right -split "\."
    for ($i = 0; $i -lt 3; $i++) {
        $x = 0; $y = 0
        if ($i -lt $a.Count) { [void][int]::TryParse($a[$i], [ref]$x) }
        if ($i -lt $b.Count) { [void][int]::TryParse($b[$i], [ref]$y) }
        if ($x -ne $y) { if ($x -gt $y) { return 1 } else { return -1 } }
    }
    return 0
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Sep
Write-Line "[ NEW-CSE-SCRIPT-SAS 1.0.0 ]" "White"
Write-Section "PRE-CHECK"

# PowerShell
$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
Write-Info ("PowerShell : " + $PSVersionTable.PSVersion.ToString())
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) {
    Write-Err "PowerShellMode 'Seven' erfordert PowerShell 7.x - Abbruch."
    exit 1
}
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
}
Write-Ok ("Modus      : " + $PowerShellMode) 4

# Azure CLI vorhanden
Write-Run "Pruefe Azure CLI..." 
$azCommand = Get-Command az -ErrorAction SilentlyContinue
if ($null -eq $azCommand) {
    Write-Err "Azure CLI nicht gefunden." 4
    Write-Info "Installation: https://aka.ms/installazurecliwindows" 4
    Write-Sep
    exit 1
}

# Azure CLI Version
$azVersionRaw = Invoke-AzQuiet -AzArguments @("version", "-o", "json")
Assert-AzSuccess -Context "az version" -Fatal | Out-Null
$azVersion = "0.0.0"
try {
    $azVersionObj = ($azVersionRaw | Out-String) | ConvertFrom-Json
    $azVersion = [string]$azVersionObj."azure-cli"
} catch {
    Write-Warn "Version konnte nicht ausgelesen werden" 4
}
Write-Ok ("Azure CLI gefunden: " + $azVersion) 4
if ((Compare-Version -Left $azVersion -Right $MinAzVersion) -lt 0) {
    Write-Warn ("Neuere Version empfohlen (mindestens " + $MinAzVersion + ")") 4
    Write-Info "Update: az upgrade" 8
} else {
    Write-Ok "Version ist aktuell genug" 4
}

# Azure Login
Write-Run "Pruefe Azure Login..."
$accountRaw = Invoke-AzQuiet -AzArguments @("account", "show", "-o", "json")
if ($LASTEXITCODE -ne 0) {
    Write-Warn "Kein aktiver Login - starte az login" 4
    & az login --only-show-errors -o none
    Assert-AzSuccess -Context "az login" -Fatal | Out-Null
    $accountRaw = Invoke-AzQuiet -AzArguments @("account", "show", "-o", "json")
    Assert-AzSuccess -Context "az account show" -Fatal | Out-Null
}
$accountObj = ($accountRaw | Out-String) | ConvertFrom-Json
Write-Ok ("Login vorhanden: " + $accountObj.user.name) 4

# Subscription setzen
if ($accountObj.id -ne $SubscriptionId) {
    Write-Run ("Wechsle Subscription auf " + $SubscriptionId) 4
    & az account set --subscription $SubscriptionId --only-show-errors
    Assert-AzSuccess -Context "az account set" -Fatal | Out-Null
} else {
    Write-Ok ("Subscription: " + $accountObj.name) 4
}

# =============================================================================
# [ STORAGE ACCOUNT ]
# =============================================================================
Write-Section "STORAGE ACCOUNT"

if ([string]::IsNullOrWhiteSpace($ResourceGroupName)) {
    Write-Run ("Ermittle Resource Group von " + $StorageAccountName + "...") 4
    $rgRaw = Invoke-AzQuiet -AzArguments @(
        "storage", "account", "list",
        "--query", ("[?name=='" + $StorageAccountName + "'].resourceGroup"),
        "-o", "tsv"
    )
    Assert-AzSuccess -Context "az storage account list" -Fatal | Out-Null
    $ResourceGroupName = ($rgRaw | Out-String).Trim()
    if ([string]::IsNullOrWhiteSpace($ResourceGroupName)) {
        Write-Err ("Storage Account '" + $StorageAccountName + "' nicht gefunden.") 4
        Write-Sep
        exit 1
    }
}
Write-Ok ("Resource Group: " + $ResourceGroupName) 4

# Public-Access-Konfiguration anzeigen
$publicRaw = Invoke-AzQuiet -AzArguments @(
    "storage", "account", "show",
    "--name", $StorageAccountName,
    "--resource-group", $ResourceGroupName,
    "--query", "{pub:allowBlobPublicAccess,net:publicNetworkAccess}",
    "-o", "json"
)
if ($LASTEXITCODE -eq 0) {
    try {
        $publicObj = ($publicRaw | Out-String) | ConvertFrom-Json
        Write-Info ("allowBlobPublicAccess : " + $publicObj.pub) 4
        Write-Info ("publicNetworkAccess   : " + $publicObj.net) 4
        if ($publicObj.pub -eq $false) {
            Write-Info "Anonymer Zugriff ist deaktiviert - SAS-Token ist erforderlich" 4
        }
    } catch { }
}

# Account Key lesen
Write-Run "Lese Account Key..." 4
$keyRaw = Invoke-AzQuiet -AzArguments @(
    "storage", "account", "keys", "list",
    "--account-name", $StorageAccountName,
    "--resource-group", $ResourceGroupName,
    "--query", "[0].value",
    "-o", "tsv"
)
Assert-AzSuccess -Context "az storage account keys list" -Fatal | Out-Null
$accountKey = ($keyRaw | Out-String).Trim()
if ([string]::IsNullOrWhiteSpace($accountKey)) {
    Write-Err "Kein Account Key erhalten - fehlen Berechtigungen?" 4
    Write-Sep
    exit 1
}
Write-Ok "Account Key gelesen" 8

# =============================================================================
# [ SAS-TOKEN ]
# =============================================================================
Write-Section "SAS-TOKEN"

Write-Run ("Erzeuge Container-SAS fuer '" + $ContainerName + "'...") 4
Write-Info ("Rechte  : " + $SasPermissions) 8
Write-Info ("Gueltig : bis " + $SasExpiry) 8

$sasArgs = @(
    "storage", "container", "generate-sas",
    "--account-name", $StorageAccountName,
    "--account-key",  $accountKey,
    "--name",         $ContainerName,
    "--permissions",  $SasPermissions,
    "--expiry",       $SasExpiry,
    "-o", "tsv"
)
if ($SasHttpsOnly) { $sasArgs += "--https-only" }

$sasRaw = Invoke-AzQuiet -AzArguments $sasArgs
Assert-AzSuccess -Context "az storage container generate-sas" -Fatal | Out-Null

$sasToken = ($sasRaw | Out-String).Trim().Trim('"')
if ([string]::IsNullOrWhiteSpace($sasToken)) {
    Write-Err "Leeres SAS-Token erhalten." 4
    Write-Sep
    exit 1
}
if ($sasToken.StartsWith("?")) { $sasToken = $sasToken.Substring(1) }
Write-Ok "SAS-Token erzeugt" 8

# =============================================================================
# [ VERIFIKATION ]
# =============================================================================
$baseUrl  = "https://" + $StorageAccountName + ".blob.core.windows.net/" + $ContainerName + "/"
$allValid = $true

if ($VerifyWithHttpHead) {
    Write-Section "VERIFIKATION"
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
    foreach ($blobName in $BlobNames) {
        $testUrl = $baseUrl + $blobName + "?" + $sasToken
        try {
            $response = Invoke-WebRequest -Uri $testUrl -Method Head -UseBasicParsing -TimeoutSec 30
            Write-Ok ($blobName + " -> HTTP " + [int]$response.StatusCode) 4
        } catch {
            $allValid = $false
            $statusCode = "?"
            if ($null -ne $_.Exception.Response) { $statusCode = [int]$_.Exception.Response.StatusCode }
            Write-Err ($blobName + " -> HTTP " + $statusCode) 4
            if ($statusCode -eq 404) {
                Write-Warn "Datei fehlt im Container oder Name weicht ab (Gross-/Kleinschreibung beachten)" 8
            }
        }
    }
}

# =============================================================================
# [ ERGEBNIS ]
# =============================================================================
Write-Section "ERGEBNIS"
Write-Info "SAS-Token fuer das Wizard-Feld 'SAS-Token':" 4
Write-Host ""
Write-Host $sasToken -ForegroundColor Green
Write-Host ""
Write-Info "Vollstaendige URLs (falls direkt benoetigt):" 4
foreach ($blobName in $BlobNames) {
    Write-Host ("    " + $baseUrl + $blobName + "?" + $sasToken) -ForegroundColor Cyan
}
Write-Host ""

if ($allValid) {
    Write-Ok "Alle Scripts sind mit diesem Token erreichbar" 4
} else {
    Write-Warn "Mindestens ein Script war nicht erreichbar - bitte Namen im Container pruefen" 4
}

Write-Info "Weiteres Vorgehen:" 4
Write-Info "1. Wizard oeffnen, Schritt 'Custom Script Extension'" 8
Write-Info "2. Token in das Feld 'SAS-Token' einfuegen" 8
Write-Info "3. Der Token wird gespeichert und an alle Preset-URLs angehaengt" 8
Write-Sep

exit 0
