﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Installs the German (de-DE) language pack on Windows 11 Enterprise multi-session
    and sets German as default display language, locale, keyboard and region.
.DESCRIPTION
    Designed to run as Custom Script Extension (SYSTEM context, non-interactive)
    on a VM created from the Windows 11 25H2 multi-session marketplace image.

    Flow (identical to the Microsoft Custom Image Template scripts
    InstallLanguagePacks.ps1 and SetDefaultLang.ps1, Azure/RDS-Templates):
      1. Pre-check (PowerShell, admin, OS, module, WSUS policy, pending reboot)
      2. Disable LanguageComponentsInstaller tasks (sharing violation workaround)
      3. Install-Language de-DE from Windows Update (retry up to 5 times)
      4. Set-SystemPreferredUILanguage, Set-WinSystemLocale, Set-Culture,
         Set-WinUserLanguageList, Set-WinHomeLocation, Geo for default user
      5. Copy-UserInternationalSettingsToSystem -WelcomeScreen -NewUser
      6. Re-enable tasks, optional delayed restart

    Requirements: direct access to Windows Update (no WSUS/Intune block for
    language packs). Windows Update should be current before running this
    script, otherwise Install-Language may end with "partially installed".

    Save this file as UTF-8 with BOM. Source code is ASCII only; symbols are
    generated at runtime.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 2026-09-01
    Version     : 1.0.1
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
    Sources:
      https://learn.microsoft.com/azure/virtual-desktop/windows-11-language-packs
      https://learn.microsoft.com/powershell/module/languagepackmanagement/install-language
      https://github.com/Azure/RDS-Templates/tree/master/CustomImageTemplateScripts/CustomImageTemplateScripts_2024-03-27
      https://learn.microsoft.com/troubleshoot/azure/virtual-desktop/troubleshoot-custom-image-templates
.EXAMPLE
    .\Set-AvdLanguageDeDE.ps1
#>

# =========================================================================
# PARAMETER (im Script hinterlegt, nicht per Aufruf)
# =========================================================================
$PowerShellMode        = "Compat"      # "Compat" = 5.1 + 7.x | "Seven" = bricht unter 5.1 ab
$TargetLanguage        = "de-DE"       # Zielsprache (BCP-47)
$MaxInstallAttempts    = 5             # Retry wie im Microsoft-Script
$ProtectLanguagePacks  = $true         # LPRemove-Task deaktivieren + Cleanup-Sperre (AVD-Doku)
$RestartAfterFinish    = $true         # verzoegerter Neustart nach Abschluss
$RestartDelaySeconds   = 60            # Verzoegerung, damit die Extension vorher Erfolg melden kann
$LogFile               = "C:\Windows\Temp\Set-AvdLanguage-$TargetLanguage.log"

# =========================================================================
# GRUNDEINSTELLUNGEN
# =========================================================================
$ErrorActionPreference = "Continue"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

$Script:ExitCode = 0

# =========================================================================
# HILFSFUNKTIONEN
# =========================================================================
function Write-Line {
    param(
        [string]$Symbol,
        [string]$Message,
        [string]$Color = "White",
        [int]$Indent = 0
    )
    $stamp  = (Get-Date).ToString("HH:mm:ss")
    $prefix = " " * $Indent
    Write-Host ("[{0}] {1}{2}  {3}" -f $stamp, $prefix, $Symbol, $Message) -ForegroundColor $Color
}
function Write-Ok   { param([string]$Message, [int]$Indent = 0) Write-Line -Symbol $SymOk   -Message $Message -Color Green  -Indent $Indent }
function Write-Err  { param([string]$Message, [int]$Indent = 0) Write-Line -Symbol $SymErr  -Message $Message -Color Red    -Indent $Indent }
function Write-Warn { param([string]$Message, [int]$Indent = 0) Write-Line -Symbol $SymWarn -Message $Message -Color Yellow -Indent $Indent }
function Write-Info { param([string]$Message, [int]$Indent = 0) Write-Line -Symbol $SymInfo -Message $Message -Color Cyan   -Indent $Indent }
function Write-Run  { param([string]$Message, [int]$Indent = 0) Write-Line -Symbol $SymRun  -Message $Message -Color Cyan   -Indent $Indent }
function Write-Separator { Write-Host ("=" * 60) -ForegroundColor White }
function Write-Section   { param([string]$Name) Write-Host "[ $Name ]" -ForegroundColor White }

function Assert-AzSuccess {
    # Prueft $LASTEXITCODE nach externen Programmaufrufen (shutdown.exe usw.)
    param([string]$Action)
    if ($LASTEXITCODE -ne 0) {
        Write-Err "$Action fehlgeschlagen (ExitCode $LASTEXITCODE)" -Indent 4
        return $false
    }
    return $true
}

function Invoke-AzQuiet {
    # Wrapper fuer externe Programme, stderr wird unterdrueckt; Argumente als Array
    param(
        [string]$FilePath,
        [string[]]$ArgumentList
    )
    $output = & $FilePath @ArgumentList 2>$null
    return $output
}

function Set-TaskState {
    param([string]$TaskPath, [string]$TaskName, [switch]$Enable)
    $task = Get-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue
    if ($null -eq $task) {
        Write-Warn "Task nicht gefunden: $TaskPath$TaskName" -Indent 4
        return
    }
    if ($Enable) {
        Enable-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue | Out-Null
        Write-Ok "Task aktiviert: $TaskName" -Indent 4
    } else {
        Disable-ScheduledTask -TaskPath $TaskPath -TaskName $TaskName -ErrorAction SilentlyContinue | Out-Null
        Write-Ok "Task deaktiviert: $TaskName" -Indent 4
    }
}

function Test-PendingReboot {
    $keys = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending",
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"
    )
    foreach ($k in $keys) {
        if (Test-Path -Path $k) { return $true }
    }
    return $false
}

# =========================================================================
# LOGGING
# =========================================================================
try { Start-Transcript -Path $LogFile -Append -ErrorAction Stop | Out-Null } catch { }

Write-Separator
Write-Section "PRE-CHECK"

# --- PowerShell-Version -------------------------------------------------
$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
Write-Info "PowerShell $($PSVersionTable.PSVersion) / Modus: $PowerShellMode"
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) {
    Write-Err "Modus 'Seven' erfordert PowerShell 7.x - Abbruch"
    try { Stop-Transcript | Out-Null } catch { }
    exit 1
}
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) {
    Set-Variable -Name PSNativeCommandUseErrorActionPreference -Value $false -Scope Global
    Write-Info "PSNativeCommandUseErrorActionPreference = false gesetzt" -Indent 4
}

# --- Admin / SYSTEM -----------------------------------------------------
$identity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Err "Keine Administratorrechte - Abbruch"
    try { Stop-Transcript | Out-Null } catch { }
    exit 1
}
Write-Ok "Ausfuehrung als: $($identity.Name)"

# --- Betriebssystem -----------------------------------------------------
$os  = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction SilentlyContinue
$cv  = Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -ErrorAction SilentlyContinue
$displayVersion = $cv.DisplayVersion
$build = $cv.CurrentBuild
$editionId = $cv.EditionID
Write-Info "OS: $($os.Caption) | Version $displayVersion | Build $build | Edition $editionId"
# Hinweis: Enterprise multi-session meldet in WMI ProductType 3 (Server), ist aber ein Client-OS.
# Deshalb keine Pruefung auf ProductType, sondern auf die Caption.
if ($os.Caption -notmatch "Windows 11") {
    Write-Err "Erwartet wurde Windows 11 - gefunden: $($os.Caption) - Abbruch"
    try { Stop-Transcript | Out-Null } catch { }
    exit 1
}
Write-Ok "Windows 11 erkannt (ProductType $($os.ProductType) wird bei multi-session ignoriert)"

# --- Modul LanguagePackManagement --------------------------------------
$lpm = Get-Module -ListAvailable -Name LanguagePackManagement -ErrorAction SilentlyContinue
if ($null -eq $lpm) {
    Write-Err "Modul LanguagePackManagement nicht vorhanden - Abbruch"
    try { Stop-Transcript | Out-Null } catch { }
    exit 1
}
Import-Module LanguagePackManagement -ErrorAction SilentlyContinue
Import-Module International -ErrorAction SilentlyContinue
Write-Ok "Modul LanguagePackManagement gefunden"

# --- WSUS-Policy (Fehler 0x800F0954) ------------------------------------
$au = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -ErrorAction SilentlyContinue
if ($null -ne $au -and $au.UseWUServer -eq 1) {
    Write-Warn "UseWUServer=1 gesetzt (WSUS). Install-Language kann mit 0x800F0954 scheitern."
} else {
    Write-Ok "Keine WSUS-Bindung erkannt (UseWUServer)"
}

# --- Pending Reboot -----------------------------------------------------
if (Test-PendingReboot) {
    Write-Warn "Neustart ausstehend. Community-Berichte: Install-Language endet dann oft mit 'partially installed'."
} else {
    Write-Ok "Kein ausstehender Neustart"
}

# --- Bereits installiert? -----------------------------------------------
$alreadyInstalled = $false
try {
    $installed = Get-InstalledLanguage -ErrorAction Stop
    foreach ($lang in $installed) {
        if ($lang.LanguageId -eq $TargetLanguage -and ($lang.LanguagePacks -contains "LpCab")) {
            $alreadyInstalled = $true
        }
    }
    $ids = ($installed | ForEach-Object { $_.LanguageId }) -join ", "
    Write-Info "Installierte Sprachen: $ids"
} catch {
    Write-Warn "Get-InstalledLanguage nicht auswertbar: $($_.Exception.Message)"
}
if ($alreadyInstalled) {
    Write-Ok "$TargetLanguage ist bereits installiert - Installation wird uebersprungen"
}
Write-Separator

# =========================================================================
# INSTALLATION
# =========================================================================
Write-Section "SPRACHPAKET INSTALLIEREN"
$installOk = $alreadyInstalled

# Tasks deaktivieren (Microsoft-Workaround: ERROR_SHARING_VIOLATION)
Write-Run "Deaktiviere LanguageComponentsInstaller-Tasks..."
Set-TaskState -TaskPath "\Microsoft\Windows\LanguageComponentsInstaller\" -TaskName "Installation"
Set-TaskState -TaskPath "\Microsoft\Windows\LanguageComponentsInstaller\" -TaskName "ReconcileLanguageResources"

if ($ProtectLanguagePacks) {
    Write-Run "Schutz gegen Language-Pack-Cleanup (AVD-Doku)..."
    Set-TaskState -TaskPath "\Microsoft\Windows\MUI\" -TaskName "LPRemove"
    $polPath = "HKLM:\SOFTWARE\Policies\Microsoft\Control Panel\International"
    if (-not (Test-Path $polPath)) { New-Item -Path $polPath -Force | Out-Null }
    New-ItemProperty -Path $polPath -Name "BlockCleanupOfUnusedPreinstalledLangPacks" -Value 1 -PropertyType DWord -Force | Out-Null
    Write-Ok "BlockCleanupOfUnusedPreinstalledLangPacks = 1" -Indent 4
}

if (-not $alreadyInstalled) {
    for ($i = 1; $i -le $MaxInstallAttempts; $i++) {
        try {
            Write-Run "Install-Language $TargetLanguage - Versuch $i von $MaxInstallAttempts (kann 20-45 Minuten dauern)"
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            Install-Language -Language $TargetLanguage -ErrorAction Stop | Out-Null
            $sw.Stop()
            Write-Ok "Sprachpaket $TargetLanguage installiert ($([int]$sw.Elapsed.TotalMinutes) min)" -Indent 4
            $installOk = $true
            break
        } catch {
            Write-Warn "Versuch $i fehlgeschlagen: $($_.Exception.Message)" -Indent 4
        }
    }
}

if (-not $installOk) {
    Write-Err "Sprachpaket konnte nicht installiert werden - Konfiguration wird uebersprungen"
    $Script:ExitCode = 1
}
Write-Separator

# =========================================================================
# STANDARDSPRACHE SETZEN (Ablauf wie Microsoft SetDefaultLang.ps1)
# =========================================================================
if ($installOk) {
    Write-Section "STANDARDSPRACHE SETZEN"

    $regionCode = $TargetLanguage.Split("-")[1]
    $geoId = (New-Object System.Globalization.RegionInfo($regionCode)).GeoId
    Write-Info "Region: $regionCode / GeoId $geoId"

    try {
        Write-Run "Set-SystemPreferredUILanguage $TargetLanguage"
        Set-SystemPreferredUILanguage -Language $TargetLanguage -ErrorAction Stop
        Write-Ok "System Preferred UI Language gesetzt" -Indent 4
    } catch { Write-Err "Set-SystemPreferredUILanguage: $($_.Exception.Message)" -Indent 4; $Script:ExitCode = 1 }

    try {
        Write-Run "Set-WinSystemLocale $TargetLanguage"
        Set-WinSystemLocale -SystemLocale $TargetLanguage -ErrorAction Stop
        Write-Ok "System Locale gesetzt" -Indent 4
    } catch { Write-Err "Set-WinSystemLocale: $($_.Exception.Message)" -Indent 4; $Script:ExitCode = 1 }

    try {
        Write-Run "Set-Culture $TargetLanguage"
        Set-Culture -CultureInfo $TargetLanguage -ErrorAction Stop
        Write-Ok "Culture (Formate) gesetzt" -Indent 4
    } catch { Write-Err "Set-Culture: $($_.Exception.Message)" -Indent 4; $Script:ExitCode = 1 }

    try {
        Write-Run "Sprachliste: $TargetLanguage an erste Stelle, vorhandene Sprachen bleiben"
        $newList = New-WinUserLanguageList -Language $TargetLanguage
        $oldList = Get-WinUserLanguageList
        foreach ($entry in $oldList) {
            if ($entry.LanguageTag -ne $TargetLanguage) { $newList.Add($entry.LanguageTag) }
        }
        Set-WinUserLanguageList -LanguageList $newList -Force -ErrorAction Stop
        $tags = ($newList | ForEach-Object { $_.LanguageTag }) -join ", "
        Write-Ok "Sprachliste: $tags" -Indent 4
    } catch { Write-Err "Set-WinUserLanguageList: $($_.Exception.Message)" -Indent 4; $Script:ExitCode = 1 }

    try {
        Write-Run "Region setzen (GeoId $geoId)"
        # DeviceRegion entfernen (DMA-Compliance, wie im Microsoft-Script)
        Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Control Panel\DeviceRegion" -Name "DeviceRegion" -Force -ErrorAction SilentlyContinue
        $geoPath = "Registry::HKEY_USERS\.DEFAULT\Control Panel\International\Geo"
        if (-not (Test-Path $geoPath)) { New-Item -Path $geoPath -Force | Out-Null }
        New-ItemProperty -Path $geoPath -Name "Nation" -Value "$geoId" -PropertyType String -Force | Out-Null
        Set-WinHomeLocation -GeoId $geoId -ErrorAction Stop
        Write-Ok "Home Location und Default-User Geo gesetzt" -Indent 4
    } catch { Write-Err "Region: $($_.Exception.Message)" -Indent 4; $Script:ExitCode = 1 }

    try {
        Write-Run "Copy-UserInternationalSettingsToSystem (Welcome Screen + neue Benutzer)"
        Copy-UserInternationalSettingsToSystem -WelcomeScreen $true -NewUser $true -ErrorAction Stop
        Write-Ok "Einstellungen auf System, Welcome Screen und Default User kopiert" -Indent 4
    } catch { Write-Err "Copy-UserInternationalSettingsToSystem: $($_.Exception.Message)" -Indent 4; $Script:ExitCode = 1 }

    Write-Separator
}

# =========================================================================
# AUFRAEUMEN + VERIFIKATION
# =========================================================================
Write-Section "ABSCHLUSS"
Write-Run "Aktiviere LanguageComponentsInstaller-Tasks..."
Set-TaskState -TaskPath "\Microsoft\Windows\LanguageComponentsInstaller\" -TaskName "Installation" -Enable
Set-TaskState -TaskPath "\Microsoft\Windows\LanguageComponentsInstaller\" -TaskName "ReconcileLanguageResources" -Enable

try {
    $verify = Get-InstalledLanguage -ErrorAction Stop | Where-Object { $_.LanguageId -eq $TargetLanguage }
    if ($null -ne $verify) {
        Write-Ok "Verifikation: $TargetLanguage | Packs: $($verify.LanguagePacks -join ',') | Features: $($verify.LanguageFeatures -join ',')"
    } else {
        Write-Err "Verifikation: $TargetLanguage nicht in Get-InstalledLanguage"
        $Script:ExitCode = 1
    }
    $pref = Get-SystemPreferredUILanguage -ErrorAction SilentlyContinue
    Write-Info "System Preferred UI Language: $pref"
} catch {
    Write-Warn "Verifikation nicht moeglich: $($_.Exception.Message)"
}

Write-Info "Log: $LogFile"

if ($Script:ExitCode -eq 0) {
    Write-Ok "Fertig. Neustart erforderlich, damit die Anzeigesprache wirksam wird."
    if ($RestartAfterFinish) {
        Write-Run "Verzoegerter Neustart in $RestartDelaySeconds Sekunden..."
        Invoke-AzQuiet -FilePath "shutdown.exe" -ArgumentList @("/r", "/t", "$RestartDelaySeconds", "/c", "Language pack $TargetLanguage installed - restart", "/f") | Out-Null
        if (Assert-AzSuccess -Action "shutdown.exe") {
            Write-Ok "Neustart geplant" -Indent 4
        }
    }
} else {
    Write-Err "Abgeschlossen mit Fehlern (ExitCode $($Script:ExitCode)). Kein automatischer Neustart."
}
Write-Separator

try { Stop-Transcript | Out-Null } catch { }
exit $Script:ExitCode
