﻿#Requires -Version 5.1
<#
.SYNOPSIS
    Konfiguriert eine en-US deployte Windows 11 Enterprise multi-session VM
    (AVD-Sitzungshost) auf deutsche Sprache, Region, Tastatur und Zeitzone.
.DESCRIPTION
    Post-Deployment-Script fuer Windows 11 Enterprise multi-session
    (Azure Virtual Desktop auf Azure / Azure Local, Azure Arc Custom Script
    Extension). Abgeleitet von Setup-DeOnly-WS.ps1 3.0.0 (Windows Server 2025).

    Ablauf:
      1. Offline-Datentraeger online schalten
      2. RAW-Datentraeger initialisieren und formatieren
      3. Sprachpaket de-DE offline via DISM:
         3b  CABs und LCU-MSUs aus dem Blob-Container laden
         3c  Client-Language-Pack-CAB per /Add-Package, fuenf Feature-
             Capabilities per /Add-Capability /Source /LimitAccess,
             danach das LCU-MSU per /Add-Package (bringt die neuen de-DE-
             Komponenten vom RTM-Stand 26100.1 auf den Build des Systems)
         3e  harte Verifikation (MUI-Registrierung, Features, dism /get-intl)
      4. Systemsprache, Locale, Tastatur, Region; Uebernahme auf Default User
         und SYSTEM mit Pruefung der Hives und Minimal-Fallback
      5. Zeitzone des Hosts
      6. WinRM
      7. Installationsverzeichnis
      8. AVD-Sitzungshost: Zeitzonen-Umleitung (RDP) fuer Benutzersitzungen
      9. Platzhalter fuer eigene Anwendungsinstallation
     10. Warten auf Abschluss des Servicing (TiWorker.exe), dann Neustart

    Warum DISM offline statt Install-Language (Messungen 01.09.2026, 25H2
    multi-session Marketplace-Image, Build 26200.9168):
      - Install-Language (Windows Update) scheiterte reproduzierbar, auch
        interaktiv: CBS 0x800705b9 ERROR_XML_PARSE_ERROR beim LCU-Overlay
        durch UpdateAgentLCU (Metadaten KB5043080/KB5121003, CXmlCursor).
        Download und Staging liefen 48 min sauber durch, Execute crashte.
      - DISM /Add-Package mit dem Client-Language-Pack-CAB der LOF-ISO
        (26100.1) lief in ca. 2,5 min durch, MUI-Key sofort registriert.
        Die fuenf Feature-Capabilities aus lokaler Quelle in je ca. 10 s.
      - Das LP-CAB liefert RTM-Stand 26100.1; das LCU-MSU (gleiches KB wie
        auf dem Image, z. B. KB5121003) zieht die neuen de-DE-Komponenten
        auf den Systemstand. Genau das macht Windows online automatisch -
        und genau dieser Automatismus ist der Teil, der crasht. Offline
        ersetzt ihn deterministisch. Checkpoint-MSUs (KB5043080) muessen
        nur im selben Ordner liegen, DISM zieht sie automatisch heran.
      - MSU-Pflege: Das MSU muss zum IMAGE passen, nicht zum Kalender.
        Bei Wechsel auf eine neuere Marketplace-Image-Version das MSU im
        Blob-Container tauschen. Die CABs bleiben fuer 24H2/25H2 konstant.
        Ist das MSU aelter als das Image, meldet DISM "not applicable" -
        de-DE bliebe dann auf RTM-Stand (Warnung im Log).
      - Bekanntes Risiko (Q&A 06/2025): de-DE als Default auf multi-session,
        danach AVD-Agent "Access to the named pipe is denied" und FSLogix-
        Fehler, ohne dokumentierte Loesung. Nach dem ersten Lauf RDAgent
        und FSLogix pruefen.

    Unterschiede zur Server-Variante:
      - SKU-Pruefung auf Windows 11 Enterprise multi-session (EditionID
        ServerRdsh / OperatingSystemSKU 175). Multi-session meldet sich in
        WMI als ProductType 3 (Server) und nicht als Client.
      - Sprachpaket offline via DISM aus dem Blob-Container statt
        Install-Language (Begruendung oben). 64-Bit-PowerShell wird im
        Pre-Check geprueft (32-Bit-dism.exe verweigert Online-Servicing).
      - Kein IE ESC (auf Client-SKUs nicht vorhanden). Stattdessen Schritt 8:
        Zeitzonen-Umleitung, damit jede Benutzersitzung die Zeitzone des
        Clients erhaelt (Standard fuer AVD-Sitzungshosts).
      - Default-User-Hive und SYSTEM-Konto sind bei Multi-Session zentral:
        jeder neue Benutzer (FSLogix-Profil) erbt daraus seine Sprache.

    Rahmenbedingungen:
      - Gemessen: LP-CAB ca. 2,5 min, Capabilities je ca. 10 s. Offen ist
        die Laufzeit des LCU-MSU (erwartet 20-40 min) und TiWorker danach.
      - Die Custom Script Extension bricht nach 90 min ab; das Script haelt
        ein Gesamtbudget von 85 min ein und beendet sich immer mit Exit 0.
      - Das deutsche Paket von Windows Update ist "teilweise lokalisiert" mit
        Fallback en-US. en-US kann und darf nicht entfernt werden.
      - intl.cpl liefert ExitCode 1 bei korrektem Ergebnis; massgeblich ist
        die Pruefung der Hives.
      - Windows entfernt "unbenutzte" Sprachpakete nach dem Neustart wieder
        (LPRemove / Pre-staged app cleanup). Die Tasks werden in Schritt 3a
        deaktiviert und die Policy BlockCleanupOfUnusedPreinstalledLangPacks
        gesetzt - bei AVD-Images zwingend, sonst ist de-DE nach dem ersten
        Neustart wieder weg.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 01.09.2026
    Version     : 1.2.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Zielplattform : Windows 11 Enterprise multi-session 24H2/25H2 (26100+)
    Basis         : Setup-DeOnly-WS.ps1 3.0.0 (Struktur, intl.cpl, Hives)
    Quelle        : Blob-Container langpacks/W11EntMS (6 CABs der LOF-ISO
                    26100.1.240331-1435 + LCU-MSUs aus dem Update Catalog)
    Referenz      : learn.microsoft.com/azure/virtual-desktop/windows-11-language-packs
    Logfile       : C:\Windows\Temp\cse-setup-avd.log (Zeitstempel UTC)
    Offen         : Laufzeit LCU-MSU, erster Lauf als SYSTEM ueber die CSE,
                    RDAgent/FSLogix nach dem Neustart
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Setup-DeOnly-AVD.ps1
#>

# =============================================================================
# [ KONFIGURATION ] - alle Parameter fest im Script hinterlegt
# =============================================================================
$PowerShellMode          = "Compat"      # "Compat" = 5.1 + 7.x | "Seven" = nur 7.x

# Sprache und Region
$LanguageTag             = "de-DE"
$GeoId                   = 94            # 94 = Deutschland
$InputLocaleAdd          = "0407:00000407"
$InputLocaleRemove       = "0409:00000409"
$KeyboardLayoutId        = "00000407"
$TimeZoneId              = "W. Europe Standard Time"

# Sprachpaket-Quelle: Blob-Container mit CABs (LOF-ISO) und LCU-MSUs
$LangSourceBaseUrl       = "https://ldkpostdeploymentscripts.blob.core.windows.net/langpacks/W11EntMS"
$LangSourceSasToken      = ""            # SAS-Token OHNE fuehrendes '?'; hier eintragen
$LanguagePackCab         = "Microsoft-Windows-Client-Language-Pack_x64_de-de.cab"
$LanguageFeatureCabs     = @(
    "Microsoft-Windows-LanguageFeatures-Basic-de-de-Package~31bf3856ad364e35~amd64~~.cab",
    "Microsoft-Windows-LanguageFeatures-Handwriting-de-de-Package~31bf3856ad364e35~amd64~~.cab",
    "Microsoft-Windows-LanguageFeatures-OCR-de-de-Package~31bf3856ad364e35~amd64~~.cab",
    "Microsoft-Windows-LanguageFeatures-Speech-de-de-Package~31bf3856ad364e35~amd64~~.cab",
    "Microsoft-Windows-LanguageFeatures-TextToSpeech-de-de-Package~31bf3856ad364e35~amd64~~.cab"
)
$LanguageCapabilities    = @("Language.Basic", "Language.Handwriting", "Language.OCR", "Language.Speech", "Language.TextToSpeech")
# LCU-MSUs: exakte Blob-Dateinamen eintragen (Ziel-LCU + Checkpoint-MSUs aus
# demselben Update-Catalog-Eintrag). Das Ziel-MSU wird ueber $LcuTargetPattern
# erkannt; Checkpoints muessen nur mit im Ordner liegen.
$LcuMsuFiles             = @(
    "windows11.0-kb5043080-x64_HASH-HIER-EINTRAGEN.msu",
    "windows11.0-kb5121003-x64_HASH-HIER-EINTRAGEN.msu"
)
$LcuTargetPattern        = "kb5121003"   # identifiziert das Ziel-MSU; beim Image-Wechsel anpassen
$LangLocalPath           = "C:\Windows\Temp\langpacks"
$DownloadTimeoutSeconds  = 900           # je Datei (LCU-MSU ist mehrere GB)
$DismTimeoutSeconds      = 1800          # Obergrenze LP-CAB / Capability (Messung: 150s / 10s)
$DismLcuTimeoutSeconds   = 3600          # Obergrenze LCU-MSU (kein Kill; Messung offen)
$KeepLanguageSources     = $false        # $true = Downloads nach Erfolg behalten

# Systemkonfiguration
$InstallPath             = "C:\Tools"
$EnableTimeZoneRedirection = $true       # RDP-Zeitzonen-Umleitung fuer Benutzersitzungen (AVD-Standard)
$EnableWinRMRemoting     = $true
$AutoReboot              = $true
$RebootDelaySeconds      = 120
$ServicingWaitSeconds    = 1800          # Max. Wartezeit auf TiWorker.exe vor dem Neustart

# Custom Script Extension (Microsoft.Compute/CustomScriptExtension 1.10): 90 min Limit
$TotalBudgetSeconds      = 5100          # 85 min Gesamtlaufzeit
$ServicingReserveSeconds = 900           # Reserve fuer Schritt 10 innerhalb des Budgets

$LogFile                 = "C:\Windows\Temp\cse-setup-avd.log"

# =============================================================================
# [ INITIALISIERUNG ]
# =============================================================================
$ErrorActionPreference = "Continue"
# Fortschrittsanzeigen (z. B. von Invoke-WebRequest) unterdruecken -
# sie bleiben in Windows Terminal als Bildschirm-Artefakt stehen.
$ProgressPreference    = "SilentlyContinue"

try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

# Symbole zur Laufzeit erzeugen - Quellcode bleibt reines ASCII
$SymOk   = [System.Char]::ConvertFromUtf32(0x2705)
$SymErr  = [System.Char]::ConvertFromUtf32(0x274C)
$SymWarn = [System.Char]::ConvertFromUtf32(0x26A0) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymInfo = [System.Char]::ConvertFromUtf32(0x2139) + [System.Char]::ConvertFromUtf32(0xFE0F)
$SymRun  = [System.Char]::ConvertFromUtf32(0x1F504)

$Script:Summary = @()
$Script:StartUtc = [DateTime]::UtcNow

function Write-Line {
    param([string]$Text, [string]$Color = "White", [int]$Indent = 0)
    $pad = " " * $Indent
    Write-Host ($pad + $Text) -ForegroundColor $Color
    try { Add-Content -Path $LogFile -Value ($pad + $Text) -Encoding UTF8 } catch { }
}
function Write-Sep     { Write-Line ("=" * 60) "White" }
function Write-Section { param([string]$Name) Write-Sep; Write-Line ("[ " + $Name + " ]") "White"; }
# Zeitstempel in UTC: Set-TimeZone in Schritt 5 aendert sonst die Lokalzeit
# und erzeugt im Log einen scheinbaren Zeitsprung.
function Get-Stamp     { return "[" + [DateTime]::UtcNow.ToString("HH:mm:ss") + "] " }
function Write-Ok      { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymOk   + "  " + $Text) "Green"  $Indent }
function Write-Err     { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymErr  + "  " + $Text) "Red"    $Indent }
function Write-Warn    { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymWarn + "  " + $Text) "Yellow" $Indent }
function Write-Info    { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymInfo + "  " + $Text) "Cyan"   $Indent }
function Write-Run     { param([string]$Text, [int]$Indent = 0) Write-Line ((Get-Stamp) + $SymRun  + "  " + $Text) "Cyan"   $Indent }

# Mehrzeilige Rohausgaben (DISM, CBS, Get-InstalledLanguage) eingerueckt loggen
function Write-LogBlock {
    param([string]$Title, [string[]]$Lines, [int]$Indent = 8, [int]$MaxLines = 40)
    Write-Info $Title $Indent
    $count = 0
    foreach ($lineItem in $Lines) {
        if ([string]::IsNullOrWhiteSpace($lineItem)) { continue }
        if ($count -ge $MaxLines) { Write-Line "... (gekuerzt)" "White" ($Indent + 4); break }
        Write-Line ($lineItem.TrimEnd()) "White" ($Indent + 4)
        $count++
    }
    if ($count -eq 0) { Write-Line "(keine Ausgabe)" "White" ($Indent + 4) }
}

$Script:BudgetDeadline = $Script:StartUtc.AddSeconds($TotalBudgetSeconds)
function Get-RemainingBudgetSeconds {
    $rest = ($Script:BudgetDeadline - [DateTime]::UtcNow).TotalSeconds
    if ($rest -lt 0) { return 0 }
    return [int]$rest
}

function Get-ElapsedText {
    $span = [DateTime]::UtcNow - $Script:StartUtc
    # [int] rundet kaufmaennisch (0.99 h -> 1) - daher Floor
    return ("{0:00}:{1:00}:{2:00}" -f [math]::Floor($span.TotalHours), $span.Minutes, $span.Seconds)
}

# Externe Programme immer ueber den Exit Code pruefen, nie ueber try/catch allein
function Assert-NativeSuccess {
    param(
        [string]$Context,
        [int]$ExitCode = $LASTEXITCODE,
        [int[]]$AllowedCodes = @(0)
    )
    if ($AllowedCodes -contains $ExitCode) {
        Write-Ok ($Context + " erfolgreich (ExitCode " + $ExitCode + ")") 4
        return $true
    }
    Write-Warn ($Context + " fehlgeschlagen (ExitCode " + $ExitCode + ")") 4
    return $false
}

# Auszug aus CBS.log / dism.log fuer die Fehlerdiagnose
function Get-ServicingLogExcerpt {
    param([string]$Path, [int]$TailLines = 3000, [int]$MaxHits = 20)
    if (-not (Test-Path $Path)) { return @("Logdatei nicht vorhanden: " + $Path) }
    try {
        $tail = Get-Content -Path $Path -Tail $TailLines -ErrorAction Stop
        $hits = @($tail | Where-Object { $_ -match "(, Error|Failed|Error:|0x8[0-9A-Fa-f]{7})" } | Select-Object -Last $MaxHits)
        if ($hits.Count -eq 0) { return @("Keine Fehlerzeilen in den letzten " + $TailLines + " Zeilen von " + $Path) }
        return $hits
    } catch {
        return @("Lesen fehlgeschlagen: " + $_.Exception.Message)
    }
}

# Wartet, bis der Windows Modules Installer Worker (TiWorker.exe) beendet ist.
# Ein Prozess-Kill von dism.exe / Install-Language beendet diese Arbeit nicht.
function Wait-ServicingIdle {
    param([int]$MaxSeconds = 1800, [int]$PollSeconds = 30, [int]$Indent = 4)
    $waited = 0
    $active = @(Get-Process -Name "TiWorker" -ErrorAction SilentlyContinue)
    if ($active.Count -eq 0) {
        Write-Ok "Kein aktives Servicing (TiWorker.exe nicht aktiv)" $Indent
        return $true
    }
    Write-Run ("TiWorker.exe aktiv - warte auf Abschluss (max " + $MaxSeconds + "s)...") $Indent
    while ($waited -lt $MaxSeconds) {
        Start-Sleep -Seconds $PollSeconds
        $waited += $PollSeconds
        $active = @(Get-Process -Name "TiWorker" -ErrorAction SilentlyContinue)
        if ($active.Count -eq 0) {
            Write-Ok ("Servicing abgeschlossen nach " + $waited + "s") ($Indent + 4)
            return $true
        }
        if (($waited % 300) -eq 0) { Write-Run ("TiWorker.exe laeuft noch (" + $waited + "s)...") ($Indent + 4) }
    }
    Write-Warn ("TiWorker.exe nach " + $MaxSeconds + "s weiterhin aktiv") ($Indent + 4)
    return $false
}

# Wrapper fuer dism.exe: Argumente als Array, Ausgabe in Datei, Obergrenze OHNE
# Kill (ein Kill stoppt die CBS-Operation nicht). ExitCode 0 und 3010 (Neustart
# erforderlich) gelten als Erfolg.
function Invoke-DismQuiet {
    param(
        [string[]]$DismArguments,
        [int]$TimeoutSeconds = 1800,
        [string]$Context = "DISM",
        [int]$Indent = 4
    )
    $runId   = [guid]::NewGuid().ToString()
    $outFile = Join-Path $env:TEMP ("dism-out-" + $runId + ".txt")
    $errFile = Join-Path $env:TEMP ("dism-err-" + $runId + ".txt")
    try {
        $procItem = Start-Process -FilePath "dism.exe" -ArgumentList $DismArguments `
            -NoNewWindow -PassThru -RedirectStandardOutput $outFile -RedirectStandardError $errFile
        if (-not $procItem.WaitForExit($TimeoutSeconds * 1000)) {
            Write-Warn ($Context + ": Obergrenze " + $TimeoutSeconds + "s erreicht - Prozess laeuft weiter, Script geht weiter") $Indent
            return $false
        }
        $exitCode = $procItem.ExitCode
        if ($exitCode -eq 0)    { Write-Ok ($Context + " erfolgreich (ExitCode 0)") $Indent; return $true }
        if ($exitCode -eq 3010) { Write-Ok ($Context + " erfolgreich, Neustart erforderlich (ExitCode 3010)") $Indent; return $true }
        Write-Warn ($Context + " fehlgeschlagen (ExitCode " + $exitCode + " / 0x" + $exitCode.ToString("X8") + ")") $Indent
        $outLines = @()
        try { $outLines = @(Get-Content -Path $outFile -ErrorAction Stop | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Last 12) } catch { }
        Write-LogBlock ($Context + " Ausgabe") $outLines ($Indent + 4) 12
        return $false
    } catch {
        Write-Err ($Context + ": Start fehlgeschlagen - " + $_.Exception.Message) $Indent
        return $false
    } finally {
        Remove-Item -Path $outFile -Force -ErrorAction SilentlyContinue
        Remove-Item -Path $errFile -Force -ErrorAction SilentlyContinue
    }
}

# Download aus dem Blob-Container mit SAS; Erfolg = Datei vorhanden und > 0 Byte
function Get-LanguageSourceFile {
    param([string]$FileName, [int]$Indent = 8)
    $uri = $LangSourceBaseUrl + "/" + $FileName
    if (-not [string]::IsNullOrWhiteSpace($LangSourceSasToken)) { $uri = $uri + "?" + $LangSourceSasToken }
    $target = Join-Path $LangLocalPath $FileName
    if (Test-Path $target) {
        $existing = Get-Item $target
        if ($existing.Length -gt 0) {
            Write-Ok ($FileName + " bereits vorhanden (" + [math]::Round($existing.Length / 1MB, 1) + " MB)") $Indent
            return $true
        }
        Remove-Item $target -Force -ErrorAction SilentlyContinue
    }
    try {
        Invoke-WebRequest -Uri $uri -OutFile $target -UseBasicParsing -TimeoutSec $DownloadTimeoutSeconds -ErrorAction Stop
        $fileItem = Get-Item $target -ErrorAction Stop
        if ($fileItem.Length -le 0) {
            Write-Err ($FileName + ": 0 Byte geladen") $Indent
            return $false
        }
        Write-Ok ($FileName + " geladen (" + [math]::Round($fileItem.Length / 1MB, 1) + " MB)") $Indent
        return $true
    } catch {
        Write-Err ($FileName + ": Download fehlgeschlagen - " + $_.Exception.Message) $Indent
        return $false
    }
}

# --- SKU-Erkennung ----------------------------------------------------------
# Windows 11 Enterprise multi-session meldet sich in Win32_OperatingSystem als
# ProductType 3 (Server), OperatingSystemSKU 175, EditionID "ServerRdsh".
# Die Caption enthaelt "multi-session".
function Test-MultiSessionSku {
    param($OsItem)
    $editionId = ""
    try {
        $editionId = [string](Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name "EditionID" -ErrorAction Stop).EditionID
    } catch { }
    $bySku     = ([int]$OsItem.OperatingSystemSKU -eq 175)
    $byEdition = ($editionId -eq "ServerRdsh")
    $byCaption = ([string]$OsItem.Caption -match "multi-session")
    $resultItem = New-Object PSObject -Property @{
        IsMultiSession = ($bySku -or $byEdition -or $byCaption)
        EditionId      = $editionId
        Sku            = [int]$OsItem.OperatingSystemSKU
        ProductType    = [int]$OsItem.ProductType
    }
    return $resultItem
}

# --- Sprachpaket-Pruefungen -------------------------------------------------
# Ein vollstaendiges UI-Sprachpaket (MUI) registriert sich unter
# HKLM\SYSTEM\CurrentControlSet\Control\MUI\UILanguages\<Tag>.
# Get-InstalledLanguage allein reicht nicht: dort erscheint eine Sprache auch,
# wenn nur Features (FOD) vorhanden sind.
function Test-MuiLanguageRegistered {
    param([string]$Tag)
    return (Test-Path ("HKLM:\SYSTEM\CurrentControlSet\Control\MUI\UILanguages\" + $Tag))
}

function Test-LanguagePackManagementAvailable {
    $modItem = @(Get-Module -ListAvailable -Name LanguagePackManagement -ErrorAction SilentlyContinue)
    return ($modItem.Count -gt 0)
}

function Get-InstalledLanguageText {
    try {
        Import-Module LanguagePackManagement -ErrorAction Stop
        $textOut = Get-InstalledLanguage -ErrorAction Stop | Format-Table -AutoSize | Out-String -Width 200
        return @($textOut -split "`r?`n")
    } catch {
        return @("Get-InstalledLanguage fehlgeschlagen: " + $_.Exception.Message)
    }
}

function Test-InstalledLanguageListed {
    param([string]$Tag)
    try {
        Import-Module LanguagePackManagement -ErrorAction Stop
        $found = @(Get-InstalledLanguage -ErrorAction Stop | Where-Object { $_.LanguageId -eq $Tag })
        return ($found.Count -gt 0)
    } catch {
        return $false
    }
}

# --- Default-User-Hive lesen / schreiben -----------------------------------
$DefaultUserHiveName = "DefUserTmp"
$DefaultUserHivePath = "C:\Users\Default\NTUSER.DAT"

function Get-IntlFromHive {
    param([string]$HiveRoot)   # z. B. "HKEY_USERS\.DEFAULT" oder "HKEY_USERS\DefUserTmp"
    $resultItem = New-Object PSObject -Property @{
        LocaleName = ""; PreferredUILanguages = ""; Preload1 = ""
    }
    try {
        $intlItem = Get-ItemProperty -Path ("Registry::" + $HiveRoot + "\Control Panel\International") -ErrorAction SilentlyContinue
        if ($null -ne $intlItem) { $resultItem.LocaleName = [string]$intlItem.LocaleName }
        $deskItem = Get-ItemProperty -Path ("Registry::" + $HiveRoot + "\Control Panel\Desktop") -ErrorAction SilentlyContinue
        if ($null -ne $deskItem -and $null -ne $deskItem.PreferredUILanguages) {
            $resultItem.PreferredUILanguages = [string]::Join(",", [string[]]$deskItem.PreferredUILanguages)
        }
        $preItem = Get-ItemProperty -Path ("Registry::" + $HiveRoot + "\Keyboard Layout\Preload") -ErrorAction SilentlyContinue
        if ($null -ne $preItem) { $resultItem.Preload1 = [string]$preItem.'1' }
    } catch { }
    return $resultItem
}

function Set-IntlInHive {
    param([string]$HiveRoot, [string]$Tag, [string]$LayoutId)
    $intlPath = "Registry::" + $HiveRoot + "\Control Panel\International"
    $deskPath = "Registry::" + $HiveRoot + "\Control Panel\Desktop"
    $prePath  = "Registry::" + $HiveRoot + "\Keyboard Layout\Preload"
    foreach ($pathItem in @($intlPath, $deskPath, $prePath)) {
        if (-not (Test-Path $pathItem)) { New-Item -Path $pathItem -Force | Out-Null }
    }
    New-ItemProperty -Path $intlPath -Name "LocaleName"           -Value $Tag           -PropertyType String      -Force | Out-Null
    New-ItemProperty -Path $deskPath -Name "PreferredUILanguages" -Value @($Tag)        -PropertyType MultiString -Force | Out-Null
    New-ItemProperty -Path $prePath  -Name "1"                    -Value $LayoutId      -PropertyType String      -Force | Out-Null
    # weitere Preload-Eintraege (z. B. 2 = 00000409) entfernen
    $preItem = Get-ItemProperty -Path $prePath -ErrorAction SilentlyContinue
    if ($null -ne $preItem) {
        foreach ($propName in ($preItem.PSObject.Properties | Where-Object { $_.Name -match "^\d+$" -and $_.Name -ne "1" } | ForEach-Object { $_.Name })) {
            Remove-ItemProperty -Path $prePath -Name $propName -Force -ErrorAction SilentlyContinue
        }
    }
}

function Mount-DefaultUserHive {
    if (Test-Path ("Registry::HKEY_USERS\" + $DefaultUserHiveName)) { return $true }
    & reg.exe load ("HKU\" + $DefaultUserHiveName) $DefaultUserHivePath 2>&1 | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Dismount-DefaultUserHive {
    [gc]::Collect()
    [gc]::WaitForPendingFinalizers()
    Start-Sleep -Milliseconds 500
    & reg.exe unload ("HKU\" + $DefaultUserHiveName) 2>&1 | Out-Null
    return ($LASTEXITCODE -eq 0)
}

function Test-IntlResult {
    param($IntlItem, [string]$Tag, [string]$LayoutId)
    return (($IntlItem.LocaleName -eq $Tag) -and
            ($IntlItem.PreferredUILanguages -eq $Tag) -and
            ($IntlItem.Preload1 -eq $LayoutId))
}

function Write-IntlResult {
    param([string]$Label, $IntlItem, [int]$Indent = 8)
    Write-Info ($Label + ": LocaleName=" + $IntlItem.LocaleName + ", PreferredUILanguages=" + $IntlItem.PreferredUILanguages + ", Preload\1=" + $IntlItem.Preload1) $Indent
}

# =============================================================================
# [ PRE-CHECK ]
# =============================================================================
Write-Sep
Write-Line "[ SETUP-DEONLY-AVD 1.2.0 - WINDOWS 11 MULTI-SESSION ]" "White"
Write-Section "PRE-CHECK"
Write-Info "Zeitstempel im Log in UTC"

$psMajor = $PSVersionTable.PSVersion.Major
$psMinor = $PSVersionTable.PSVersion.Minor
Write-Info ("PowerShell : " + $PSVersionTable.PSVersion.ToString())
if ($PowerShellMode -eq "Seven" -and $psMajor -lt 7) {
    Write-Err "PowerShellMode 'Seven' erfordert PowerShell 7.x - Abbruch."
    exit 0
}
if ($psMajor -gt 7 -or ($psMajor -eq 7 -and $psMinor -ge 3)) {
    $PSNativeCommandUseErrorActionPreference = $false
    Write-Info "PSNativeCommandUseErrorActionPreference deaktiviert" 4
}
Write-Ok ("Modus      : " + $PowerShellMode) 4

$osInfo = Get-CimInstance -ClassName Win32_OperatingSystem
$osBuild = 0
try { $osBuild = [int]$osInfo.BuildNumber } catch { }
Write-Info ("Computer   : " + $env:COMPUTERNAME)
Write-Info ("Benutzer   : " + $env:USERDOMAIN + "\" + $env:USERNAME)
Write-Info ("OS         : " + $osInfo.Caption + " (Build " + $osInfo.BuildNumber + ")")
Write-Info ("Zeitzone   : " + (Get-TimeZone).Id + " (vor Konfiguration)")

# --- SKU: Windows 11 Enterprise multi-session --------------------------------
$skuInfo = Test-MultiSessionSku -OsItem $osInfo
Write-Info ("SKU        : EditionID=" + $skuInfo.EditionId + ", OperatingSystemSKU=" + $skuInfo.Sku + ", ProductType=" + $skuInfo.ProductType) 4
if ($skuInfo.IsMultiSession) {
    Write-Ok "SKU-Typ    : Windows Enterprise multi-session" 4
} elseif ($skuInfo.ProductType -eq 1) {
    Write-Warn "Client-SKU (Single-Session) erkannt - Script laeuft weiter, Schritt 8 (Zeitzonen-Umleitung) ist hier ohne Wirkung" 4
} else {
    Write-Warn "Server-SKU erkannt - fuer Windows Server 2025 bitte Setup-DeOnly-WS.ps1 verwenden" 4
}

# --- Modul nur noch fuer die Verifikation (Get-InstalledLanguage) -----------
$lpmAvailable = Test-LanguagePackManagementAvailable
if ($lpmAvailable) { Write-Ok "Modul      : LanguagePackManagement vorhanden (Verifikation)" 4 }
else               { Write-Warn "Modul      : LanguagePackManagement fehlt - Verifikation nur ueber MUI-Key und dism" 4 }
$is64Bit = [System.Environment]::Is64BitProcess
if ($is64Bit) { Write-Ok "Prozess    : 64-Bit" 4 }
else { Write-Err "Prozess    : 32-Bit - Online-Servicing per DISM erfordert 64-Bit; Sprachpaket-Installation wird uebersprungen" 4 }
# CABs sind fuer die 26100er-Basis (24H2/25H2) gebaut
if ($osBuild -ge 26100) { Write-Ok ("Build      : " + $osBuild + " (26100er-Basis, passt zu den CAB-Quellen)") 4 }
else { Write-Warn ("Build      : " + $osBuild + " - CABs im Container sind fuer 26100 (24H2/25H2) gebaut") 4 }

$currentIdentity  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$currentPrincipal = New-Object System.Security.Principal.WindowsPrincipal($currentIdentity)
if (-not $currentPrincipal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Err "Keine administrativen Rechte - Abbruch."
    exit 0
}
Write-Ok "Rechte     : elevated" 4
Write-Info ("Logfile    : " + $LogFile) 4
Write-Info ("Zeitbudget : " + $TotalBudgetSeconds + "s (CSE-Limit 90 min)") 4

# Ausgangszustand der Sprachen dokumentieren
Write-Run "Ausgangszustand Sprachen..." 4
Write-Info ("MUI registriert " + $LanguageTag + " : " + (Test-MuiLanguageRegistered -Tag $LanguageTag)) 8
Write-Info ("MUI registriert en-US : " + (Test-MuiLanguageRegistered -Tag "en-US")) 8
if ($lpmAvailable) { Write-LogBlock "Get-InstalledLanguage (vorher)" (Get-InstalledLanguageText) 8 }

# Keine Windows-Update-Freischaltung mehr noetig: alle Quellen kommen aus dem
# Blob-Container, DISM laeuft mit /LimitAccess bzw. lokalen Paketen.

# =============================================================================
# [ SCHRITT 1 ] Offline-Datentraeger online schalten
# =============================================================================
Write-Section "SCHRITT 1 - DATENTRAEGER ONLINE"
try {
    $offlineDisks = @(Get-Disk | Where-Object { $_.OperationalStatus -eq "Offline" })
    if ($offlineDisks.Count -eq 0) {
        Write-Ok "Keine Offline-Datentraeger vorhanden" 4
    } else {
        foreach ($diskItem in $offlineDisks) {
            Write-Run ("Setze Disk " + $diskItem.Number + " online...") 4
            Set-Disk -Number $diskItem.Number -IsOffline $false
            Set-Disk -Number $diskItem.Number -IsReadOnly $false
            Write-Ok ("Disk " + $diskItem.Number + " ist online") 8
        }
    }
    $Script:Summary += "Schritt 1 (Disks online)       : OK"
} catch {
    Write-Err ("Fehlgeschlagen: " + $_.Exception.Message) 4
    $Script:Summary += "Schritt 1 (Disks online)       : FEHLER"
}

# =============================================================================
# [ SCHRITT 2 ] RAW-Datentraeger initialisieren
# =============================================================================
Write-Section "SCHRITT 2 - RAW-DATENTRAEGER INITIALISIEREN"
try {
    $rawDisks = @(Get-Disk | Where-Object { $_.PartitionStyle -eq "RAW" -and $_.IsSystem -eq $false })
    if ($rawDisks.Count -eq 0) {
        Write-Ok "Keine RAW-Datentraeger vorhanden" 4
    } else {
        foreach ($diskItem in $rawDisks) {
            Write-Run ("Initialisiere Disk " + $diskItem.Number + " (" + [math]::Round($diskItem.Size / 1GB, 0) + " GB)...") 4
            Initialize-Disk -Number $diskItem.Number -PartitionStyle GPT
            $partItem = New-Partition -DiskNumber $diskItem.Number -AssignDriveLetter -UseMaximumSize
            $volLabel = "DataDisk" + $diskItem.Number
            Format-Volume -DriveLetter $partItem.DriveLetter -FileSystem NTFS -NewFileSystemLabel $volLabel -Confirm:$false | Out-Null
            Write-Ok ("Disk " + $diskItem.Number + " -> " + $partItem.DriveLetter + ": (" + $volLabel + ")") 8
        }
    }
    $Script:Summary += "Schritt 2 (RAW-Disks)          : OK"
} catch {
    Write-Err ("Fehlgeschlagen: " + $_.Exception.Message) 4
    $Script:Summary += "Schritt 2 (RAW-Disks)          : FEHLER"
}

# =============================================================================
# [ SCHRITT 3 ] Deutsches Sprachpaket installieren
# =============================================================================
Write-Section "SCHRITT 3 - SPRACHPAKET $LanguageTag"

$muiOk        = $false      # MUI-Paket registriert (harte Pruefung)

# --- Schritt 3a: Cleanup-Tasks deaktivieren --------------------------------
# Windows entfernt Sprachpakete, die es als "unbenutzt" einstuft, nach einem
# Neustart wieder. Auf AVD-Images ist das der haeufigste Grund, warum de-DE
# nach dem ersten Reboot fehlt. Muss vor der Installation unterbunden werden.
Write-Run "Deaktiviere LXP-/LP-Cleanup-Tasks..." 4
Disable-ScheduledTask -TaskPath "\Microsoft\Windows\AppxDeploymentClient\"       -TaskName "Pre-staged app cleanup" -ErrorAction SilentlyContinue | Out-Null
Disable-ScheduledTask -TaskPath "\Microsoft\Windows\MUI\"                        -TaskName "LPRemove"               -ErrorAction SilentlyContinue | Out-Null
Disable-ScheduledTask -TaskPath "\Microsoft\Windows\LanguageComponentsInstaller\" -TaskName "Uninstallation"         -ErrorAction SilentlyContinue | Out-Null
try {
    $intlPolicyKey = "HKLM:\SOFTWARE\Policies\Microsoft\Control Panel\International"
    if (-not (Test-Path $intlPolicyKey)) { New-Item -Path $intlPolicyKey -Force | Out-Null }
    New-ItemProperty -Path $intlPolicyKey -Name "BlockCleanupOfUnusedPreinstalledLangPacks" -Value 1 -PropertyType DWord -Force | Out-Null
    Write-Ok "BlockCleanupOfUnusedPreinstalledLangPacks = 1" 8
} catch {
    Write-Warn ("Policy nicht setzbar: " + $_.Exception.Message) 8
}
# Installation und ReconcileLanguageResources greifen waehrend der Sprachpaket-
# Installation auf dieselben Dateien zu (Bug 45044965, ERROR_SHARING_VIOLATION).
# Microsofts AVD-Scripts schalten beide Tasks vorher aus, Schritt 3d wieder ein.
$installerTaskPath = "\Microsoft\Windows\LanguageComponentsInstaller\"
Disable-ScheduledTask -TaskPath $installerTaskPath -TaskName "Installation"               -ErrorAction SilentlyContinue | Out-Null
Disable-ScheduledTask -TaskPath $installerTaskPath -TaskName "ReconcileLanguageResources" -ErrorAction SilentlyContinue | Out-Null
Write-Ok "LanguageComponentsInstaller Installation/ReconcileLanguageResources waehrend der Installation deaktiviert" 8

# --- Schritt 3b: Quellen aus dem Blob-Container laden ----------------------
$lpAlreadyRegistered = Test-MuiLanguageRegistered -Tag $LanguageTag
$sourcesOk = $false
$lcuTarget = $null
if ($lpAlreadyRegistered) {
    Write-Ok ("MUI-Sprachpaket " + $LanguageTag + " ist bereits registriert - Download und Installation werden uebersprungen") 4
    $muiOk = $true
} elseif (-not $is64Bit) {
    Write-Err "Sprachpaket-Installation uebersprungen - keine 64-Bit-Sitzung (siehe Pre-Check)" 4
} else {
    Write-Run ("Lade Sprachquellen nach " + $LangLocalPath + "...") 4
    New-Item -ItemType Directory -Path $LangLocalPath -Force | Out-Null
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

    $sourcesOk = Get-LanguageSourceFile -FileName $LanguagePackCab
    foreach ($cabName in $LanguageFeatureCabs) {
        if (-not (Get-LanguageSourceFile -FileName $cabName)) { $sourcesOk = $false }
    }
    $msuOk = $true
    foreach ($msuName in $LcuMsuFiles) {
        if (-not (Get-LanguageSourceFile -FileName $msuName)) { $msuOk = $false }
    }
    if (-not $msuOk) {
        Write-Warn "Nicht alle LCU-MSUs geladen - LP/Features werden installiert, de-DE bliebe dann auf RTM-Stand 26100.1" 8
    }
    if ($sourcesOk) { Write-Ok "Alle CAB-Quellen vorhanden" 4 }
    else            { Write-Err "CAB-Quellen unvollstaendig - Installation wird uebersprungen (Blob-Namen und SAS pruefen)" 4 }
}

# --- Schritt 3c: DISM-Installation (LP-CAB, Capabilities, LCU-MSU) ---------
# Messung 01.09.2026: LP-CAB ca. 150s, Capability je ca. 10s.
if (-not $lpAlreadyRegistered -and $sourcesOk) {
    $lpPath = Join-Path $LangLocalPath $LanguagePackCab
    Write-Run "DISM /Add-Package Client-Language-Pack..." 4
    $lpOk = Invoke-DismQuiet -DismArguments @(
        "/Online", "/Add-Package", ("/PackagePath:" + $lpPath), "/NoRestart", "/Quiet"
    ) -TimeoutSeconds $DismTimeoutSeconds -Context "DISM Client-Language-Pack" -Indent 8

    if ($lpOk -and (Test-MuiLanguageRegistered -Tag $LanguageTag)) {
        Write-Ok "MUI-Key direkt nach /Add-Package registriert" 8
    }

    if ($lpOk) {
        # Feature-Capabilities aus lokaler Quelle, ohne Windows-Update-Kontakt
        foreach ($capName in $LanguageCapabilities) {
            $capFull = $capName + "~~~" + $LanguageTag + "~0.0.1.0"
            Invoke-DismQuiet -DismArguments @(
                "/Online", "/Add-Capability", ("/CapabilityName:" + $capFull),
                ("/Source:" + $LangLocalPath), "/LimitAccess", "/NoRestart", "/Quiet"
            ) -TimeoutSeconds $DismTimeoutSeconds -Context ("DISM " + $capFull) -Indent 8 | Out-Null
        }

        # LCU-MSU: bringt die neuen de-DE-Komponenten vom RTM-Stand auf den
        # Systemstand. Ziel-MSU ueber Pattern aufloesen (nie Wildcard an dism.exe);
        # Checkpoint-MSUs liegen im selben Ordner und werden automatisch gezogen.
        $lcuTarget = Get-ChildItem -Path $LangLocalPath -Filter "*.msu" -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match $LcuTargetPattern } | Select-Object -First 1
        if ($null -eq $lcuTarget) {
            Write-Err ("Kein MSU mit Pattern '" + $LcuTargetPattern + "' in " + $LangLocalPath + " - de-DE bleibt auf RTM-Stand 26100.1") 8
        } elseif ((Get-RemainingBudgetSeconds) -le $ServicingReserveSeconds) {
            Write-Err ("Restbudget erschoepft - LCU-MSU uebersprungen, de-DE bleibt auf RTM-Stand (nachtraeglich: DISM /Add-Package " + $lcuTarget.Name + ")") 8
        } else {
            $lcuLimit = [math]::Min($DismLcuTimeoutSeconds, (Get-RemainingBudgetSeconds) - $ServicingReserveSeconds)
            Write-Run ("DISM /Add-Package " + $lcuTarget.Name + " (Obergrenze " + $lcuLimit + "s, erwartet 20-40 min)...") 4
            $lcuOk = Invoke-DismQuiet -DismArguments @(
                "/Online", "/Add-Package", ("/PackagePath:" + $lcuTarget.FullName), "/NoRestart", "/Quiet"
            ) -TimeoutSeconds $lcuLimit -Context "DISM LCU-MSU" -Indent 8
            if (-not $lcuOk) {
                Write-Warn "LCU-Overlay nicht bestaetigt - Details in C:\Windows\Logs\DISM\dism.log und CBS.log" 8
                Write-LogBlock "CBS-Log-Auszug" (Get-ServicingLogExcerpt -Path "C:\Windows\Logs\CBS\CBS.log") 8
            }
        }
    } else {
        Write-Err "Client-Language-Pack nicht installiert - Capabilities und LCU uebersprungen" 8
        Write-LogBlock "CBS-Log-Auszug" (Get-ServicingLogExcerpt -Path "C:\Windows\Logs\CBS\CBS.log") 8
    }
}

# --- Schritt 3d: Installer-Tasks wieder aktivieren -------------------------
# Uninstallation, LPRemove und Pre-staged app cleanup bleiben aus.
Enable-ScheduledTask -TaskPath $installerTaskPath -TaskName "Installation"               -ErrorAction SilentlyContinue | Out-Null
Enable-ScheduledTask -TaskPath $installerTaskPath -TaskName "ReconcileLanguageResources" -ErrorAction SilentlyContinue | Out-Null
Write-Ok "LanguageComponentsInstaller Installation/ReconcileLanguageResources wieder aktiviert" 4

# --- Schritt 3e: Harte Verifikation ----------------------------------------
Write-Run "Verifiziere Sprachpaket..." 4
$muiOk   = Test-MuiLanguageRegistered -Tag $LanguageTag
$listOk  = Test-InstalledLanguageListed -Tag $LanguageTag

if ($muiOk)   { Write-Ok  ("MUI registriert: HKLM\SYSTEM\...\MUI\UILanguages\" + $LanguageTag) 8 }
else          { Write-Err ("MUI NICHT registriert: HKLM\SYSTEM\...\MUI\UILanguages\" + $LanguageTag) 8 }
if ($listOk)  { Write-Ok  ("Get-InstalledLanguage listet " + $LanguageTag) 8 }
else          { Write-Warn ("Get-InstalledLanguage listet " + $LanguageTag + " nicht") 8 }
$installedText = Get-InstalledLanguageText
Write-LogBlock "Get-InstalledLanguage (nachher)" $installedText 8
$featuresOk = $true
# Alle fuenf Features erwartet (Sitzungshost: Rechtschreibpruefung, OCR usw.)
$langLine = ($installedText | Where-Object { $_ -match ("^\s*" + [regex]::Escape($LanguageTag) + "\s") } | Select-Object -First 1)
$expectedFeatures = @("BasicTyping", "Handwriting", "Speech", "TextToSpeech", "OCR")
$missingFeatures = @()
foreach ($featItem in $expectedFeatures) {
    if ([string]::IsNullOrEmpty($langLine) -or $langLine -notmatch $featItem) { $missingFeatures += $featItem }
}
if ($missingFeatures.Count -eq 0) { Write-Ok "Alle Sprach-Features gelistet (BasicTyping, Handwriting, Speech, TextToSpeech, OCR)" 8 }
else { $featuresOk = $false; Write-Warn ("Features fehlen: " + [string]::Join(", ", $missingFeatures)) 8 }
# dism /get-intl: Standard-UI-Sprache des Systems, Typ (voll/teilweise lokalisiert), Fallback
$intlLines = @(& dism.exe /online /get-intl 2>&1 | ForEach-Object { [string]$_ })
if ($LASTEXITCODE -eq 0) { Write-LogBlock "dism /online /get-intl" $intlLines 8 }
else                     { Write-Warn ("dism /get-intl fehlgeschlagen (ExitCode " + $LASTEXITCODE + ")") 8 }

if ($muiOk) {
    Write-Ok ("MUI-Sprachpaket " + $LanguageTag + " verifiziert") 4
    if ($featuresOk) { $Script:Summary += "Schritt 3 (Sprachpaket)        : OK" }
    else             { $Script:Summary += "Schritt 3 (Sprachpaket)        : OK (Features unvollstaendig)" }
} else {
    Write-Err "MUI-Sprachpaket nicht verifiziert - Systemsprache wird nicht umgestellt" 4
    Write-Warn ("Nachtraeglich: DISM /Online /Add-Package /PackagePath:" + (Join-Path $LangLocalPath $LanguagePackCab) + "; Details in CBS.log") 8
    $Script:Summary += "Schritt 3 (Sprachpaket)        : FEHLER"
}

# Downloads aufraeumen (LCU-MSU ist mehrere GB); bei Fehlern behalten fuer Diagnose
if ($muiOk -and -not $KeepLanguageSources -and -not $lpAlreadyRegistered) {
    Remove-Item -Path $LangLocalPath -Recurse -Force -ErrorAction SilentlyContinue
    Write-Info ("Quellverzeichnis " + $LangLocalPath + " entfernt") 4
} elseif ((Test-Path $LangLocalPath) -and -not $lpAlreadyRegistered) {
    Write-Info ("Quellverzeichnis bleibt fuer Diagnose/Nacharbeit: " + $LangLocalPath) 4
}

# =============================================================================
# [ SCHRITT 4 ] Locale, UI-Sprache, Tastatur und Region
# =============================================================================
# Bei Multi-Session entscheidend: SystemPreferredUILanguage (Anmeldebildschirm,
# neue Benutzer) und der Default-User-Hive (Vorlage fuer jedes neue Profil,
# auch bei FSLogix). Nur damit landet jeder AVD-Benutzer in einer deutschen
# Sitzung, ohne die Sprache selbst umstellen zu muessen.
Write-Section "SCHRITT 4 - LOCALE UND REGION"
$step4Ok = $true
$sysPrefOk = $false

try {
    Set-WinSystemLocale -SystemLocale $LanguageTag
    Write-Ok ("SystemLocale = " + $LanguageTag) 4
} catch { Write-Warn ("Set-WinSystemLocale: " + $_.Exception.Message) 4; $step4Ok = $false }

if ($muiOk) {
    # Systemweite bevorzugte UI-Sprache (Anmeldebildschirm, neue Benutzer)
    if (Get-Command -Name "Set-SystemPreferredUILanguage" -ErrorAction SilentlyContinue) {
        try {
            Set-SystemPreferredUILanguage -Language $LanguageTag -ErrorAction Stop
            $prefLang = ""
            try { $prefLang = [string](Get-SystemPreferredUILanguage -ErrorAction Stop) } catch { }
            if ($prefLang -eq $LanguageTag) {
                Write-Ok ("SystemPreferredUILanguage = " + $prefLang) 4
                $sysPrefOk = $true
            } else {
                Write-Warn ("SystemPreferredUILanguage gesetzt, Rueckmeldung: '" + $prefLang + "'") 4
                $step4Ok = $false
            }
        } catch {
            Write-Err ("Set-SystemPreferredUILanguage: " + $_.Exception.Message) 4
            Write-Warn "Anmeldebildschirm und neue Benutzer bleiben damit auf der Installationssprache" 8
            $step4Ok = $false
        }
    } else {
        Write-Info "Set-SystemPreferredUILanguage nicht verfuegbar (LanguagePackManagement)" 4
    }
    try {
        Set-WinUILanguageOverride -Language $LanguageTag
        Write-Ok ("UILanguageOverride = " + $LanguageTag + " (Kontext " + $env:USERNAME + ")") 4
    } catch { Write-Warn ("Set-WinUILanguageOverride: " + $_.Exception.Message) 4 }
} else {
    Write-Warn "UI-Sprache uebersprungen (kein verifiziertes MUI-Paket)" 4
    $step4Ok = $false
}

try {
    Set-Culture -CultureInfo $LanguageTag
    Set-WinHomeLocation -GeoId $GeoId
    Write-Ok ("Culture = " + $LanguageTag + ", GeoId = " + $GeoId + " (Deutschland)") 4
} catch { Write-Warn ("Set-Culture / Set-WinHomeLocation: " + $_.Exception.Message) 4; $step4Ok = $false }

try {
    $langList = New-WinUserLanguageList $LanguageTag
    $langList[0].InputMethodTips.Clear()
    $langList[0].InputMethodTips.Add($InputLocaleAdd)
    Set-WinUserLanguageList $langList -Force
    Write-Ok ("Sprachliste = " + $LanguageTag + ", Tastatur = " + $InputLocaleAdd) 4
} catch { Write-Warn ("Set-WinUserLanguageList: " + $_.Exception.Message) 4; $step4Ok = $false }

# intl.cpl uebertraegt die Einstellungen auf das Default-User-Profil und das
# SYSTEM-Konto (LogonUI, Sperrbildschirm). XML muss UTF-8 ohne BOM sein.
# Der ExitCode von control.exe wird geloggt, gilt aber nicht als Nachweis -
# das Ergebnis wird direkt in den Hives geprueft. Server-Messung 31.08.2026:
# ExitCode 1 bei vollstaendig korrektem Default-User-Hive.
$intlXml = @"
<?xml version="1.0" encoding="UTF-8"?>
<gs:GlobalizationServices xmlns:gs="urn:longhornGlobalizationUnattend">
  <gs:UserList>
    <gs:User UserID="Current"
             CopySettingsToDefaultUserAcct="true"
             CopySettingsToSystemAcct="true"/>
  </gs:UserList>
  <gs:LocationPreferences>
    <gs:GeoID Value="$GeoId"/>
  </gs:LocationPreferences>
  <gs:MUILanguagePreferences>
    <gs:MUILanguage Value="$LanguageTag"/>
  </gs:MUILanguagePreferences>
  <gs:SystemLocale Name="$LanguageTag"/>
  <gs:InputPreferences>
    <gs:InputLanguageID Action="remove" ID="$InputLocaleRemove"/>
    <gs:InputLanguageID Action="add"    ID="$InputLocaleAdd" Default="true"/>
  </gs:InputPreferences>
  <gs:UserLocale>
    <gs:Locale Name="$LanguageTag" SetAsCurrent="true" ResetAllSettings="true"/>
  </gs:UserLocale>
</gs:GlobalizationServices>
"@
try {
    $xmlPath   = Join-Path $env:TEMP "de-DE-intl.xml"
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($xmlPath, $intlXml, $utf8NoBom)

    $intlProc = Start-Process -FilePath "control.exe" `
        -ArgumentList ("intl.cpl,,/f:`"" + $xmlPath + "`"") -Wait -PassThru
    Write-Info ("intl.cpl ExitCode " + $intlProc.ExitCode + " (nur informativ, Nachweis folgt ueber Hive-Pruefung)") 4
    Remove-Item -Path $xmlPath -Force -ErrorAction SilentlyContinue
} catch {
    Write-Warn ("intl.cpl konnte nicht gestartet werden: " + $_.Exception.Message) 4
}

# --- Ergebnis pruefen: Default-User-Hive (NTUSER.DAT) ----------------------
Write-Run "Pruefe Default-User-Profil (C:\Users\Default\NTUSER.DAT)..." 4
$defaultOk = $false
if (Mount-DefaultUserHive) {
    try {
        $defIntl = Get-IntlFromHive -HiveRoot ("HKEY_USERS\" + $DefaultUserHiveName)
        Write-IntlResult "DefaultUser (nach intl.cpl)" $defIntl 8
        $defaultOk = Test-IntlResult -IntlItem $defIntl -Tag $LanguageTag -LayoutId $KeyboardLayoutId
        if (-not $defaultOk) {
            Write-Warn "Werte weichen ab - Minimal-Fallback (LocaleName, PreferredUILanguages, Keyboard Preload) wird geschrieben" 8
            Set-IntlInHive -HiveRoot ("HKEY_USERS\" + $DefaultUserHiveName) -Tag $LanguageTag -LayoutId $KeyboardLayoutId
            $defIntl   = Get-IntlFromHive -HiveRoot ("HKEY_USERS\" + $DefaultUserHiveName)
            Write-IntlResult "DefaultUser (nach Fallback)" $defIntl 8
            $defaultOk = Test-IntlResult -IntlItem $defIntl -Tag $LanguageTag -LayoutId $KeyboardLayoutId
        }
    } catch {
        Write-Warn ("Default-User-Hive: " + $_.Exception.Message) 8
    } finally {
        if (Dismount-DefaultUserHive) { Write-Ok "Default-User-Hive entladen" 8 }
        else                          { Write-Warn ("Default-User-Hive konnte nicht entladen werden (reg unload ExitCode " + $LASTEXITCODE + ")") 8 }
    }
} else {
    Write-Warn ("reg load fehlgeschlagen (ExitCode " + $LASTEXITCODE + ")") 8
}
if ($defaultOk) { Write-Ok "Default-User-Profil = de-DE / Tastatur 00000407" 4 }
else            { Write-Err "Default-User-Profil NICHT auf de-DE" 4; $step4Ok = $false }

# --- Ergebnis pruefen: SYSTEM-Konto (HKU\.DEFAULT, LogonUI) ----------------
Write-Run "Pruefe SYSTEM-Konto (HKU\.DEFAULT)..." 4
$systemOk = $false
try {
    $sysIntl  = Get-IntlFromHive -HiveRoot "HKEY_USERS\.DEFAULT"
    Write-IntlResult "SYSTEM (nach intl.cpl)" $sysIntl 8
    $systemOk = Test-IntlResult -IntlItem $sysIntl -Tag $LanguageTag -LayoutId $KeyboardLayoutId
    if (-not $systemOk) {
        Write-Warn "Werte weichen ab - Minimal-Fallback wird geschrieben" 8
        Set-IntlInHive -HiveRoot "HKEY_USERS\.DEFAULT" -Tag $LanguageTag -LayoutId $KeyboardLayoutId
        $sysIntl  = Get-IntlFromHive -HiveRoot "HKEY_USERS\.DEFAULT"
        Write-IntlResult "SYSTEM (nach Fallback)" $sysIntl 8
        $systemOk = Test-IntlResult -IntlItem $sysIntl -Tag $LanguageTag -LayoutId $KeyboardLayoutId
    }
} catch {
    Write-Warn ("HKU\.DEFAULT: " + $_.Exception.Message) 8
}
if ($systemOk) { Write-Ok "SYSTEM-Konto = de-DE / Tastatur 00000407" 4 }
else           { Write-Err "SYSTEM-Konto NICHT auf de-DE" 4; $step4Ok = $false }

if ($step4Ok) { $Script:Summary += "Schritt 4 (Locale/Region)      : OK" }
else          { $Script:Summary += "Schritt 4 (Locale/Region)      : TEILWEISE (siehe Log)" }

# =============================================================================
# [ SCHRITT 5 ] Zeitzone des Hosts
# =============================================================================
Write-Section "SCHRITT 5 - ZEITZONE"
try {
    Set-TimeZone -Id $TimeZoneId
    $tzNow = (Get-TimeZone).Id
    if ($tzNow -eq $TimeZoneId) {
        Write-Ok ("Zeitzone = " + $tzNow + " (Lokalzeit jetzt " + (Get-Date -Format "HH:mm:ss") + ")") 4
        $Script:Summary += "Schritt 5 (Zeitzone)           : OK"
    } else {
        Write-Warn ("Zeitzone gesetzt, Rueckmeldung: " + $tzNow) 4
        $Script:Summary += "Schritt 5 (Zeitzone)           : FEHLER"
    }
} catch {
    Write-Warn ("Set-TimeZone: " + $_.Exception.Message) 4
    $Script:Summary += "Schritt 5 (Zeitzone)           : FEHLER"
}

# =============================================================================
# [ SCHRITT 6 ] WinRM aktivieren
# =============================================================================
Write-Section "SCHRITT 6 - WINRM"
if ($EnableWinRMRemoting) {
    try {
        Enable-PSRemoting -Force -SkipNetworkProfileCheck | Out-Null
        Set-Item WSMan:\localhost\MaxEnvelopeSizekb -Value 8192
        Write-Ok "PSRemoting aktiviert, MaxEnvelopeSizekb = 8192" 4
        $Script:Summary += "Schritt 6 (WinRM)              : OK"
    } catch {
        Write-Warn ("WinRM-Konfiguration fehlgeschlagen: " + $_.Exception.Message) 4
        $Script:Summary += "Schritt 6 (WinRM)              : FEHLER"
    }
} else {
    Write-Info "Uebersprungen (EnableWinRMRemoting = false)" 4
}

# =============================================================================
# [ SCHRITT 7 ] Installationsverzeichnis
# =============================================================================
Write-Section "SCHRITT 7 - INSTALLATIONSVERZEICHNIS"
try {
    if (-not (Test-Path $InstallPath)) {
        New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
        Write-Ok ("Angelegt: " + $InstallPath) 4
    } else {
        Write-Ok ("Bereits vorhanden: " + $InstallPath) 4
    }
    $Script:Summary += "Schritt 7 (Verzeichnis)        : OK"
} catch {
    Write-Warn ("Anlegen fehlgeschlagen: " + $_.Exception.Message) 4
    $Script:Summary += "Schritt 7 (Verzeichnis)        : FEHLER"
}

# =============================================================================
# [ SCHRITT 8 ] AVD-Sitzungshost: Zeitzonen-Umleitung
# =============================================================================
# Ersetzt IE ESC aus der Server-Variante (auf Client-SKUs nicht vorhanden).
# fEnableTimeZoneRedirection = 1: jede RDP-/AVD-Sitzung uebernimmt die
# Zeitzone des verbindenden Clients (GPO "Allow time zone redirection").
Write-Section "SCHRITT 8 - AVD ZEITZONEN-UMLEITUNG"
if ($EnableTimeZoneRedirection) {
    try {
        $tsPolicyKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
        if (-not (Test-Path $tsPolicyKey)) { New-Item -Path $tsPolicyKey -Force | Out-Null }
        New-ItemProperty -Path $tsPolicyKey -Name "fEnableTimeZoneRedirection" -Value 1 -PropertyType DWord -Force | Out-Null
        $tzRedirect = (Get-ItemProperty -Path $tsPolicyKey -Name "fEnableTimeZoneRedirection" -ErrorAction SilentlyContinue).fEnableTimeZoneRedirection
        if ($tzRedirect -eq 1) {
            Write-Ok "fEnableTimeZoneRedirection = 1 (Sitzungen uebernehmen Client-Zeitzone)" 4
            $Script:Summary += "Schritt 8 (TZ-Umleitung)       : OK"
        } else {
            Write-Warn ("fEnableTimeZoneRedirection gesetzt, Rueckmeldung: " + $tzRedirect) 4
            $Script:Summary += "Schritt 8 (TZ-Umleitung)       : FEHLER"
        }
    } catch {
        Write-Warn ("Zeitzonen-Umleitung nicht setzbar: " + $_.Exception.Message) 4
        $Script:Summary += "Schritt 8 (TZ-Umleitung)       : FEHLER"
    }
} else {
    Write-Info "Uebersprungen (EnableTimeZoneRedirection = false)" 4
}

# =============================================================================
# [ SCHRITT 9 ] Platzhalter fuer eigene Anwendungsinstallation
# =============================================================================
Write-Section "SCHRITT 9 - ANWENDUNGEN"
Write-Info "Platzhalter - keine Aktion" 4
# Eigene Installationslogik hier ergaenzen (z. B. FSLogix-Apps, RDAgent-Vorbereitung):
# Invoke-WebRequest -Uri "https://example.com/app.msi" -OutFile (Join-Path $InstallPath "app.msi") -UseBasicParsing
# $msiProc = Start-Process msiexec.exe -ArgumentList ("/i `"" + (Join-Path $InstallPath "app.msi") + "`" /quiet /norestart") -Wait -PassThru
# Assert-NativeSuccess -Context "MSI-Installation" -ExitCode $msiProc.ExitCode -AllowedCodes @(0, 3010) | Out-Null

# =============================================================================
# [ SCHRITT 10 ] Servicing-Abschluss vor dem Neustart
# =============================================================================
Write-Section "SCHRITT 10 - SERVICING-ABSCHLUSS"
$servicingLimit = [math]::Min($ServicingWaitSeconds, (Get-RemainingBudgetSeconds))
Write-Info ("Restbudget " + (Get-RemainingBudgetSeconds) + "s - Servicing-Wait max " + $servicingLimit + "s") 4
$servicingIdle = Wait-ServicingIdle -MaxSeconds $servicingLimit -Indent 4
$cbsRebootPending = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"
Write-Info ("CBS RebootPending: " + $cbsRebootPending) 4
if ($servicingIdle) { $Script:Summary += "Schritt 10 (Servicing)         : OK" }
else                { $Script:Summary += "Schritt 10 (Servicing)         : TiWorker noch aktiv" }

# =============================================================================
# [ ZUSAMMENFASSUNG ]
# =============================================================================
Write-Section "ZUSAMMENFASSUNG"
foreach ($summaryLine in $Script:Summary) { Write-Info $summaryLine 4 }
Write-Info ("Laufzeit: " + (Get-ElapsedText)) 4
Write-Info ("Logfile: " + $LogFile) 4
if ($muiOk -and $sysPrefOk -and $defaultOk -and $systemOk) {
    Write-Ok "Post-Deployment abgeschlossen - de-DE verifiziert (MUI, SystemPreferredUILanguage, DefaultUser, SYSTEM)" 4
} else {
    Write-Warn ("Post-Deployment mit Abweichungen - MUI=" + $muiOk + ", SystemPreferredUILanguage=" + $sysPrefOk + ", DefaultUser=" + $defaultOk + ", SYSTEM=" + $systemOk) 4
}

if ($AutoReboot) {
    Write-Run ("Neustart in " + $RebootDelaySeconds + " Sekunden zur Uebernahme der Spracheinstellungen") 4
    # shutdown.exe statt Restart-Computer: das Script kann beenden und die
    # Custom Script Extension ihren Status melden, bevor die VM neu startet.
    & shutdown.exe /r /t $RebootDelaySeconds /c "Post-Deployment: Neustart zur Uebernahme der Spracheinstellungen"
    Assert-NativeSuccess -Context "shutdown.exe" | Out-Null
} else {
    Write-Warn "Automatischer Neustart deaktiviert - bitte manuell neu starten" 4
}
Write-Sep

# Die Custom Script Extension darf das ARM-Deployment nicht zum Scheitern
# bringen. Teilfehler sind im Logfile und in der Zusammenfassung dokumentiert.
exit 0
