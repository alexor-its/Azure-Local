#Requires -Version 5.1
<#
.SYNOPSIS
    Deployt das Workbook 'ArcDiskSpace.workbook' als Azure Monitor Workbook.
.DESCRIPTION
    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung

    Legt eine Ressource vom Typ 'Microsoft.Insights/workbooks' an. Der Name
    einer Workbook-Ressource MUSS eine GUID sein; der sichtbare Name steckt in
    'displayName'. Deshalb wird der Name deterministisch aus displayName und
    Resource Group abgeleitet - ein erneuter Lauf aktualisiert das Workbook
    statt ein Duplikat zu erzeugen.

    Erstellt wird per 'az rest' (PUT). Fuer Workbooks existiert kein stabiles
    'az monitor workbook'-Kommando.

    Begriffsklaerung: Ein Azure Monitor WORKSPACE ist der Prometheus-
    Metrikspeicher. Dieses Script deployt ein WORKBOOK - das interaktive
    Dashboard im Portal.

    Das Workbook nutzt Parameter (Subscription, Workspace, Zeitraum, kritischer
    Schwellwert, Warnschwelle, Ausschlussmuster) und ist damit nicht an eine
    feste Umgebung gebunden. Der 'sourceId' bestimmt nur, unter welcher
    Ressource es im Portal erscheint.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 17.08.2026
    Version     : 2.1.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\New-ArcDiskSpaceWorkbook.ps1
#>

$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

$SubscriptionId        = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local

$WorkbookResourceGroup = "rg-arcmgmt"
$Location              = "westeurope"
$WorkbookDisplayName   = "Arc-Server Festplattenkapazitaet"
$WorkbookFile          = ".\ArcDiskSpace.workbook"

# Unter welcher Ressource erscheint das Workbook im Portal?
# Leer = 'Azure Monitor' (Monitor -> Workbooks). Alternativ die Resource-ID
# des Log Analytics Workspace, dann erscheint es unter dessen Workbooks.
$SourceId              = "Azure Monitor"

$ApiVersion            = "2023-06-01"
$WhatIfMode            = $false

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Get-DeterministicGuid {
    <#
      Leitet eine stabile GUID aus einem Text ab (MD5 der ersten 16 Bytes).
      Damit ergibt derselbe Anzeigename immer dieselbe Ressourcen-ID - ein
      zweiter Lauf aktualisiert also, statt ein Duplikat anzulegen.

      ACHTUNG: $WorkbookDisplayName darf deshalb NICHT die Version enthalten.
      Sonst entstuende bei jeder Version ein neues Workbook statt eines
      Updates. Die Version steckt im Tag und im Fusszeilen-Text.
    #>
    param([Parameter(Mandatory)][string]$Text)
    $md5   = [System.Security.Cryptography.MD5]::Create()
    $bytes = $md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Text))
    return ([guid]::new($bytes)).ToString()
}

function Get-WorkbookVersion {
    <#
      Liest die Version aus dem Fusszeilen-Text der Workbook-Datei.
      Marker: "Version x.y.z". Kein Treffer -> '0.0.0'.
    #>
    param([Parameter(Mandatory)][string]$Json)
    $m = [regex]::Match($Json, 'Version\s+(\d+\.\d+\.\d+)')
    if ($m.Success) { return $m.Groups[1].Value }
    return "0.0.0"
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - bitte 'az upgrade' ausfuehren."
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
    Write-Ok "Subscription gesetzt."
}

Write-Run "Pruefe Workbook-Datei..."
if (-not (Test-Path $WorkbookFile)) {
    Write-Fail "Datei '$WorkbookFile' nicht gefunden."
    Write-Sub "Sie muss im selben Verzeichnis wie dieses Script liegen."
    exit 1
}
$raw = Get-Content -Path $WorkbookFile -Raw -Encoding UTF8
try   { $null = $raw | ConvertFrom-Json; Write-Ok "Datei gefunden und JSON valide." }
catch { Write-Fail "Datei ist kein gueltiges JSON: $($_.Exception.Message)"; exit 1 }
Write-Sub "Groesse: $([math]::Round($raw.Length / 1024, 1)) KB"

$NeueVersion = Get-WorkbookVersion -Json $raw
if ($NeueVersion -eq "0.0.0") {
    Write-Warn2 "Keine Version in der Datei gefunden (Marker 'Version x.y.z')."
    Write-Sub "Das Deployment laeuft, aber die Versionierung bleibt leer."
}
else { Write-Ok "Version in der Datei: $NeueVersion" }

Write-Run "Pruefe Resource Group '$WorkbookResourceGroup'..."
$rg = Invoke-AzJson @("group","show","--name",$WorkbookResourceGroup,"-o","json")
if (-not $rg) {
    Write-Fail "Resource Group nicht gefunden: $script:LastAzError"
    exit 1
}
Write-Ok "Resource Group vorhanden ($($rg.location))."
Write-Line

# =============================================================================
#  DEPLOYMENT
# =============================================================================
Write-Head "WORKBOOK"

$guid = Get-DeterministicGuid -Text "$WorkbookDisplayName|$WorkbookResourceGroup"
$resourceId = "/subscriptions/$SubscriptionId/resourceGroups/$WorkbookResourceGroup" `
            + "/providers/Microsoft.Insights/workbooks/$guid"
$url = "https://management.azure.com$($resourceId)?api-version=$ApiVersion"

Write-Sub "Anzeigename : $WorkbookDisplayName"
Write-Sub "Ressourcenname (GUID): $guid"
Write-Sub "Ablage      : $WorkbookResourceGroup / $Location"
Write-Sub "sourceId    : $SourceId"

Write-Run "Pruefe, ob das Workbook bereits existiert..."
$existing = Invoke-AzJson @("rest","--method","get","--url",$url)
if ($existing) {
    $alteVersion = if ($existing.tags -and $existing.tags.WorkbookVersion) {
        $existing.tags.WorkbookVersion
    } else { "unbekannt" }

    Write-Info2 "Vorhanden - wird aktualisiert."
    Write-Sub "Deployte Version : $alteVersion"
    Write-Sub "Neue Version     : $NeueVersion"

    if ($alteVersion -eq $NeueVersion) {
        Write-Warn2 "Gleiche Version - Inhalt wird trotzdem ueberschrieben."
        Write-Sub "Falls im Portal etwas geaendert wurde, geht das jetzt verloren."
    }
    elseif ($alteVersion -ne "unbekannt") {
        try {
            if ([version]$NeueVersion -lt [version]$alteVersion) {
                Write-Warn2 "Die neue Version ist AELTER als die deployte."
                Write-Sub "Rueckschritt von $alteVersion auf $NeueVersion."
            }
        } catch { }
    }
}
else { Write-Info2 "Nicht vorhanden - wird angelegt." }

# serializedData muss der komplette Workbook-JSON als STRING sein.
# Die Version steckt zusaetzlich im Tag, damit sie ohne Portal abfragbar ist:
#   az resource show --ids <id> --query tags
$body = @{
    location   = $Location
    kind       = "shared"
    tags       = @{
        WorkbookVersion = $NeueVersion
        DeployedAt      = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        DeployedBy      = $account.user.name
        Source          = "New-ArcDiskSpaceWorkbook.ps1"
    }
    properties = @{
        displayName    = $WorkbookDisplayName
        serializedData = $raw
        version        = "Notebook/1.0"
        category       = "workbook"
        sourceId       = $SourceId
    }
}

if ($WhatIfMode) {
    Write-Line
    Write-Info2 "WhatIf-Modus - es wird nichts deployt."
    Write-Sub "Ziel-URL: $url"
    Write-Line
    exit 0
}

# Body ueber eine Temp-Datei - az.cmd zerlegt Inline-JSON unter Windows falsch.
$bodyFile = Join-Path $env:TEMP "workbook-$([guid]::NewGuid()).json"
$body | ConvertTo-Json -Depth 10 | Set-Content -Path $bodyFile -Encoding UTF8

Write-Run "Sende PUT..."
$res = Invoke-AzJson @(
    "rest","--method","put","--url",$url,
    "--headers","Content-Type=application/json",
    "--body","@$bodyFile"
)
Remove-Item $bodyFile -ErrorAction SilentlyContinue

if (-not $res) {
    Write-Fail "Deployment fehlgeschlagen."
    Write-Sub "Ursache: $script:LastAzError"
    exit 1
}
Write-Ok "Workbook deployt: $($res.properties.displayName)"
Write-Line

# =============================================================================
#  ZUSAMMENFASSUNG
# =============================================================================
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "Anzeigename : $WorkbookDisplayName"
Write-Sub "Version     : $NeueVersion"
Write-Sub "Ressource   : $guid"
Write-Sub "Resource Group: $WorkbookResourceGroup"
Write-Host ""
Write-Info2 "Aufrufen im Portal:"
Write-Sub "Azure Monitor -> Workbooks -> '$WorkbookDisplayName'"
Write-Host ""
Write-Info2 "Deployte Version abfragen (ohne Portal):"
Write-Sub "az resource show --ids $resourceId --query tags -o json"
Write-Host ""
Write-Info2 "Direktlink:"
Write-Sub "https://portal.azure.com/#@/resource$resourceId"
Write-Host ""
Write-Info2 "Alternativ manuell importieren:"
Write-Sub "Azure Monitor -> Workbooks -> Neu -> </> Advanced Editor"
Write-Sub "-> Inhalt von $WorkbookFile einfuegen -> Apply"
Write-Line
