#Requires -Version 5.1
<#
.SYNOPSIS
    Fragt die aktuellen Disk-Werte der VIRTUAL SERVER (VMs) aus dem Log
    Analytics Workspace ab. AVD-Session-Hosts und physische Server werden
    ausgeschlossen.
.DESCRIPTION
    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung

    AENDERUNG IN 3.1.0 - MATCHING UEBER _ResourceId
    -------------------------------------------------------------------------
    Der Hardware-Filter verglich bisher den Arc-Maschinennamen gegen die
    LAW-Spalte 'Computer'. Das schlaegt bei Domaenenmitgliedern fehl:

        Arc-Ressourcenname : kkr1
        LAW-Spalte Computer: kkr1.ldkads.local

    Folge waere, dass physische Server unentdeckt durchrutschen. Die Abfrage
    gibt deshalb jetzt _ResourceId mit aus und der Filter arbeitet damit.

    ZIELTABELLE
    -------------------------------------------------------------------------
    Abgefragt wird InsightsMetrics. Die DCR aus Script 1 nutzt
    \VmInsights\DetailedMetrics mit Stream Microsoft-InsightsMetrics - die
    Perf-Tabelle bleibt dabei leer, und das ist erwartetes Verhalten.

    FILTER
    -------------------------------------------------------------------------
      1. Namensmuster im KQL - '^avd' greift auch auf FQDNs, weil es ein
         Praefix-Vergleich ist
      2. Hardware-Abgleich   - ueber Resource Graph und _ResourceId
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 18.08.2026
    Version     : 3.1.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Get-ArcDiskSpace.ps1
.EXAMPLE
    # Nur kritische Laufwerke, als CSV
    $OnlyBelowThreshold = $true; $ExportCsv = $true; .\Get-ArcDiskSpace.ps1
#>

$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

$SubscriptionId         = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local

# --- Ziel-Workspace ---
$WorkspaceName          = "law-LDK-VirtualServer"
$WorkspaceResourceGroup = "rg-arcmgmt"

# --- FILTER (mit den anderen Scripts konsistent halten) ---
$ExcludeNamePatterns    = @('^avd')
$ExcludePhysical        = $true
$VirtualModelPatterns   = @('Virtual Machine', 'VMware Virtual', 'HVM domU', 'KVM', 'QEMU')
$VirtualVendorPatterns  = @('Microsoft Corporation', 'VMware', 'QEMU', 'Xen', 'Nutanix', 'Parallels')
$UnknownHardwareIsPhysical = $false

# --- Abfrageparameter ---
$LookbackHours          = 1
$WarnPercent            = 25
$CriticalPercent        = 15
$DriveFilter            = ""       # leer = alle Laufwerke; sonst z. B. 'C:'
$OnlyBelowThreshold     = $false
$ShowFqdn               = $false   # $true = FQDN anzeigen statt Kurzname
$ExportCsv              = $false
$CsvPath                = ".\ArcDiskSpace_$(Get-Date -f 'yyyyMMdd-HHmmss').csv"

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Ensure-Extension {
    param([Parameter(Mandatory)][string]$Name)
    $exts = Invoke-AzJson @("extension","list")
    if ($exts | Where-Object { $_.name -eq $Name }) { return $true }
    Write-Warn2 "Extension '$Name' fehlt - wird installiert."
    az extension add --name $Name --only-show-errors 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Installation von '$Name' fehlgeschlagen."; return $false }
    return $true
}

function Test-IsVirtual {
    param([string]$Model, [string]$Manufacturer)

    if ([string]::IsNullOrWhiteSpace($Model) -and [string]::IsNullOrWhiteSpace($Manufacturer)) {
        return (-not $UnknownHardwareIsPhysical)
    }
    foreach ($p in $VirtualModelPatterns) { if ($Model -like "*$p*") { return $true } }
    if (-not [string]::IsNullOrWhiteSpace($Model)) { return $false }
    foreach ($p in $VirtualVendorPatterns) { if ($Manufacturer -like "*$p*") { return $true } }
    return $false
}

function Get-DiskKql {
    <#
      Baut die KQL. Nur einfache Anfuehrungszeichen - doppelte ueberleben die
      Uebergabe an az.cmd unter Windows nicht.
      Gibt _ResourceId mit aus, weil der Hardware-Filter darauf arbeitet.
    #>
    $p = New-Object System.Collections.Generic.List[string]

    $p.Add("InsightsMetrics")
    $p.Add("where TimeGenerated > ago(${LookbackHours}h)")
    $p.Add("where Origin == 'vm.azm.ms'")
    $p.Add("where Namespace == 'LogicalDisk'")
    $p.Add("where Name in ('FreeSpacePercentage','FreeSpaceMB')")
    $p.Add("where _ResourceId has '/microsoft.hybridcompute/machines/'")

    # Praefix-Vergleich, greift auch bei FQDN wie avdhp1kkr-2.ldkads.local
    # ACHTUNG: KQL kennt KEIN '!matches regex' - die Negation laeuft ueber not().
    foreach ($pat in $ExcludeNamePatterns) {
        $p.Add("where not(Computer matches regex '(?i)$pat')")
    }

    $p.Add("extend Drive = tostring(todynamic(Tags)['vm.azm.ms/mountId'])")
    if ($DriveFilter) { $p.Add("where Drive == '$DriveFilter'") }

    $p.Add("summarize FreiProzent = avgif(Val, Name == 'FreeSpacePercentage'), " `
         + "FreiMB = avgif(Val, Name == 'FreeSpaceMB') " `
         + "by Computer, Drive, ResId = tolower(_ResourceId)")
    # ACHTUNG: hier NICHT auf 'FreiProzent > 0' filtern. Ein Laufwerk mit
    # exakt 0 % frei ist der kritischste Fall und wuerde sonst aus dem Report
    # fallen. Die Division wird stattdessen unten abgesichert.
    $p.Add("where isnotnull(FreiProzent) and isnotnull(FreiMB)")

    # Gesamtgroesse aus Division. Das ist genau, weil hier der UNGERUNDETE
    # Mittelwert von FreiProzent verwendet wird - gerundet wird erst im
    # project. Beispiel: 0,6 GB frei bei tatsaechlich 0,923 % ergibt korrekt
    # 65 GB, auch wenn die Anzeige '1 %' zeigt.
    # UsedSpaceMB gehoert NICHT zum Counter-Set \VmInsights\DetailedMetrics
    # und steht deshalb nicht als Alternative zur Verfuegung.
    $p.Add("extend GesamtMB = iff(FreiProzent > 0, " `
         + "FreiMB / (FreiProzent / 100.0), real(null))")
    $p.Add("project Computer, ResId, Drive, " `
         + "FreiProzent = round(FreiProzent, 1), " `
         + "FreiGB = round(FreiMB / 1024.0, 1), " `
         + "GesamtGB = round(GesamtMB / 1024.0, 1)")
    $p.Add("order by FreiProzent asc")

    return ($p -join " | ")
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - bitte 'az upgrade' ausfuehren."
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
    Write-Ok "Subscription gesetzt."
}

Write-Run "Pruefe benoetigte Extensions..."
if (-not (Ensure-Extension -Name "log-analytics")) { exit 1 }
if ($ExcludePhysical) {
    if (-not (Ensure-Extension -Name "resource-graph")) {
        Write-Warn2 "Ohne resource-graph entfaellt der Hardware-Filter."
        $ExcludePhysical = $false
    }
}
Write-Ok "Extensions verfuegbar."

Write-Run "Loese Workspace '$WorkspaceName' auf..."
$ws = Invoke-AzJson @("monitor","log-analytics","workspace","show",
                      "--resource-group",$WorkspaceResourceGroup,
                      "--name",$WorkspaceName,"-o","json")
if (-not $ws) { Write-Fail "Workspace nicht erreichbar: $script:LastAzError"; exit 1 }
Write-Ok "Workspace gefunden: $($ws.name) ($($ws.location))"
Write-Line

# =============================================================================
#  PHYSISCHE SERVER ERMITTELN
# =============================================================================
$physisch = @{}   # tolower(machineId) -> Modellbezeichnung

if ($ExcludePhysical) {
    Write-Head "HARDWARE-FILTER"
    Write-Run "Lade Hardware-Angaben aus Resource Graph..."

    $argQuery = "resources " `
      + "| where type =~ 'microsoft.hybridcompute/machines' " `
      + "| project mid = tolower(id), name, " `
      +   "model = tostring(properties.detectedProperties.model), " `
      +   "manufacturer = tostring(properties.detectedProperties.manufacturer)"

    $argRes = Invoke-AzJson @("graph","query","-q",$argQuery,"--first","1000","-o","json")
    if ($argRes -and $argRes.data) {
        foreach ($m in @($argRes.data)) {
            if (-not (Test-IsVirtual -Model $m.model -Manufacturer $m.manufacturer)) {
                $physisch[$m.mid] = if ($m.model) { $m.model } else { "unbekannt" }
            }
        }
        Write-Ok "$($physisch.Count) physische Maschine(n) erkannt - werden ausgefiltert."
    }
    else {
        Write-Warn2 "Hardware-Abfrage fehlgeschlagen - Filter inaktiv."
        Write-Sub "Ursache: $script:LastAzError"
    }
    Write-Line
}

# =============================================================================
#  ABFRAGE
# =============================================================================
Write-Head "ABFRAGE"

$kql = Get-DiskKql
Write-Run "Frage Disk-Werte ab (letzte $LookbackHours h)..."
Write-Sub "Zieltabelle: InsightsMetrics"

$rows = Invoke-AzJson @("monitor","log-analytics","query",
                        "--workspace",$ws.customerId,
                        "--analytics-query",$kql,"-o","json")

if ($null -eq $rows) {
    Write-Fail "Abfrage fehlgeschlagen."
    Write-Sub "Ursache: $script:LastAzError"
    exit 1
}

$rows      = @($rows)
$alle      = @()
$gefiltert = 0

foreach ($r in $rows) {

    if ($r.ResId -and $physisch.ContainsKey($r.ResId)) { $gefiltert++; continue }

    $anzeige = if ($ShowFqdn) { $r.Computer } else { ($r.Computer -split '\.')[0] }
    $frei    = [double]$r.FreiProzent

    $alle += [PSCustomObject]@{
        Server        = $anzeige
        Fqdn          = $r.Computer
        Laufwerk      = $r.Drive
        FreiProzent   = $frei
        FreiGB        = $r.FreiGB
        GesamtGB      = $r.GesamtGB
        Status        = if     ($frei -lt $CriticalPercent) { "KRITISCH" }
                        elseif ($frei -lt $WarnPercent)     { "WARNUNG" }
                        else                                 { "OK" }
    }
}

Write-Ok "$($rows.Count) Laufwerk(e) aus dem Workspace geladen."
if ($gefiltert -gt 0) { Write-Sub "$gefiltert davon als physisch ausgefiltert." }
Write-Line

# =============================================================================
#  AUSGABE
# =============================================================================
$anzeigeSet = if ($OnlyBelowThreshold) { @($alle | Where-Object { $_.FreiProzent -lt $WarnPercent }) } else { @($alle) }

if ($anzeigeSet.Count -eq 0) {
    Write-Head "ERGEBNIS"
    Write-Info2 "Keine Datensaetze im gewaehlten Filter."
    if ($alle.Count -eq 0) {
        Write-Sub "Moegliche Ursache: die DCR-Association ist noch zu frisch."
        Write-Sub "Erste Werte erscheinen 5 bis 15 Minuten nach der Zuordnung."
        Write-Sub "Pruefen mit: .\Test-ArcMonitoringPrereq.ps1"
    }
    Write-Line
    exit 0
}

Write-Head "VIRTUAL SERVER - LAUFWERKE"
Write-Host ""
Write-Host ("    {0,-26} {1,-6} {2,8} {3,10} {4,11}  {5}" -f `
            "Server","Disk","Frei %","Frei GB","Gesamt GB","Status") -ForegroundColor White
Write-Host ("    " + ("-" * 76)) -ForegroundColor White

foreach ($r in ($anzeigeSet | Sort-Object FreiProzent)) {
    $farbe = switch ($r.Status) {
        "KRITISCH" { "Red" }
        "WARNUNG"  { "Yellow" }
        default    { "Green" }
    }
    # $null wuerde als Leerraum rendern - dann waere nicht unterscheidbar, ob
    # der Wert fehlt oder Null ist. Deshalb explizit '-'.
    $gesamtText = if ($null -eq $r.GesamtGB) { "-" } else { "{0:N1}" -f [double]$r.GesamtGB }

    Write-Host ("    {0,-26} {1,-6} {2,8:N1} {3,10:N1} {4,11}  {5}" -f `
                $r.Server, $r.Laufwerk, $r.FreiProzent, $r.FreiGB, `
                $gesamtText, $r.Status) `
               -ForegroundColor $farbe
}

Write-Host ""
Write-Line
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "Laufwerke : $($alle.Count)"
Write-Sub "Server    : $(@($alle | Select-Object -ExpandProperty Fqdn -Unique).Count)"
Write-Host ""
foreach ($grp in ($alle | Group-Object Status | Sort-Object Name)) {
    $farbe = switch ($grp.Name) { "KRITISCH" { "Red" } "WARNUNG" { "Yellow" } default { "Green" } }
    Write-Host ("    {0,-10} {1,4}" -f $grp.Name, $grp.Count) -ForegroundColor $farbe
}

# Laufwerke mit exakt 0 % frei: dort ist die Gesamtgroesse nicht berechenbar,
# weil FreiMB / (FreiProzent/100) durch Null teilen wuerde. Sie erscheinen in
# der Tabelle mit '-' und sind der dringlichste Fall ueberhaupt.
$randvoll = @($alle | Where-Object { $null -eq $_.GesamtGB })
if ($randvoll.Count -gt 0) {
    Write-Host ""
    Write-Fail "$($randvoll.Count) Laufwerk(e) mit 0 % frei - Gesamtgroesse nicht berechenbar:"
    foreach ($g in ($randvoll | Sort-Object Server)) {
        Write-Sub ("  {0,-22} {1,-4} {2,7:N1} GB frei" -f $g.Server, $g.Laufwerk, $g.FreiGB)
    }
}

if ($ExportCsv) {
    $alle | Export-Csv -Path $CsvPath -NoTypeInformation -Encoding UTF8
    Write-Host ""
    Write-Ok "CSV geschrieben: $CsvPath"
}

Write-Host ""
Write-Info2 "Naechster Schritt: .\New-ArcDiskSpaceAlert.ps1"
Write-Line
