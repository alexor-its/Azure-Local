#Requires -Version 5.1
<#
.SYNOPSIS
    SCHRITT 1 von 6 - Legt EINE gemeinsame VM-Insights-DCR fuer den Log
    Analytics Workspace an und assoziiert alle Virtual Server damit.
.DESCRIPTION
    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung

    WAS DIESE DCR SAMMELT
    -------------------------------------------------------------------------
    Datenquelle : performanceCounters mit dem Sammel-Specifier
                  \VmInsights\DetailedMetrics
    Stream      : Microsoft-InsightsMetrics
    Ziel        : Log Analytics Workspace -> Tabelle InsightsMetrics
    Intervall   : 60 Sekunden (Standard von VM Insights)

    Der Specifier \VmInsights\DetailedMetrics ist ein vordefinierter
    Sammelbegriff fuer das komplette VM-Insights-Counter-Set (CPU, Memory,
    LogicalDisk, Network). Er laesst sich NICHT mit einzelnen Counter-
    Specifiern in derselben Datenquelle mischen - Azure lehnt das mit
    "cannot be mixed with other specifiers" ab. Zusatzcounter brauchen eine
    zweite performanceCounters-Datenquelle.

    ABGRENZUNG ZUM OTEL-PFAD
    -------------------------------------------------------------------------
    Die bestehenden OTel-DCRs (Ziel: Azure Monitor Workspace) bleiben
    unangetastet. Beide Pfade laufen parallel - im Portal unter
    Monitor Settings sind das die beiden Haken "OpenTelemetry metrics" und
    "[Classic] Log-based metrics".

    EINE DCR STATT VIELER
    -------------------------------------------------------------------------
    Das Portal legt beim Aktivieren von VM Insights je Maschine eine eigene
    DCR namens MSVMI-<region>-<maschine> an. Bei 213 Servern entstehen so
    213 DCRs. Dieses Script legt genau eine an und haengt alle Maschinen
    daran.

    DEPENDENCY AGENT / SERVICE MAP
    -------------------------------------------------------------------------
    Bewusst NICHT enthalten. Der Stream Microsoft-ServiceMap braucht eine
    zusaetzliche Extension und erzeugt deutlich mehr Datenvolumen. Fuer
    Disk-Alerts und Kapazitaetsauswertung wird er nicht benoetigt.
    Bei Bedarf ueber $IncludeServiceMap aktivierbar.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 18.08.2026
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\New-ArcVmInsightsDcr.ps1
.EXAMPLE
    # Erst ansehen, was passieren wuerde
    $WhatIfMode = $true; .\New-ArcVmInsightsDcr.ps1
#>

# Python-Warnungen aus CLI-Extensions unterdruecken (sonst stderr-Rauschen,
# das PowerShell als NativeCommandError wertet)
$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

$SubscriptionId         = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local

# --- Ziel-Workspace ---
$WorkspaceName          = "law-LDK-VirtualServer"
$WorkspaceResourceGroup = "rg-arcmgmt"

# --- DCR ---
$DcrName                = "law-LDK-VirtualServer-vminsights-dcr"
$DcrResourceGroup       = "rg-arcmgmt"
$DcrLocation            = "westeurope"     # muss zur Workspace-Region passen
$DcrDescription         = "Gemeinsame VM-Insights-DCR fuer alle Arc Virtual Server."
$SamplingSeconds        = 60               # Standard von VM Insights
$IncludeServiceMap      = $false           # Dependency Agent / Microsoft-ServiceMap

# --- Association ---
$AssociateNow           = $true            # Server direkt assoziieren
$AssociationName        = "dcra-vminsights-virtualserver"

# --- FILTER (identisch zu den anderen Scripts halten) ---
$ExcludeNames           = @()
$ExcludeNamePatterns    = @('^avd')        # AVD-Session-Hosts
$ExcludePhysical        = $true
$VirtualModelPatterns   = @('Virtual Machine', 'VMware Virtual', 'HVM domU', 'KVM', 'QEMU')
$VirtualVendorPatterns  = @('Microsoft Corporation', 'VMware', 'QEMU', 'Xen', 'Nutanix', 'Parallels')
$UnknownHardwareIsPhysical = $false
$OnlyConnected          = $true            # nur Maschinen mit status=Connected

# --- Sonstiges ---
$ApiVersion             = "2023-03-11"
$WhatIfMode             = $false

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    <#
      Ruft Azure CLI auf und liefert sauberes JSON zurueck. Trennt stdout und
      stderr, damit Python-Warnungen der CLI-Extensions das JSON nicht
      zerstoeren. Rueckgabe: PSObject bei Erfolg, $null bei Fehler.
      Fehlertext steht danach in $script:LastAzError.
    #>
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort erhalten: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Invoke-AzRestBody {
    <#
      Fuehrt einen az-rest-Aufruf mit JSON-Body aus. Der Body geht ueber eine
      Temp-Datei, weil az.cmd Inline-JSON unter Windows falsch zerlegt.
    #>
    param(
        [Parameter(Mandatory)][string]$Method,
        [Parameter(Mandatory)][string]$Url,
        [Parameter(Mandatory)]$Body
    )

    $file = Join-Path $env:TEMP "azrest-$([guid]::NewGuid()).json"
    $Body | ConvertTo-Json -Depth 20 | Set-Content -Path $file -Encoding UTF8

    try {
        return Invoke-AzJson @(
            "rest","--method",$Method,"--url",$Url,
            "--headers","Content-Type=application/json",
            "--body","@$file"
        )
    }
    finally { Remove-Item $file -ErrorAction SilentlyContinue }
}

function Ensure-Extension {
    param([Parameter(Mandatory)][string]$Name)
    $exts = Invoke-AzJson @("extension","list")
    if ($exts | Where-Object { $_.name -eq $Name }) { return $true }
    Write-Warn2 "Extension '$Name' fehlt - wird installiert."
    az extension add --name $Name --only-show-errors 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Installation von '$Name' fehlgeschlagen."; return $false }
    return $true
}

function Test-IsVirtual {
    <#
      Erst das Modell pruefen, dann den Hersteller: ein physischer Hyper-V-Host
      meldet ebenfalls 'Microsoft Corporation', aber ein echtes Servermodell.
    #>
    param([string]$Model, [string]$Manufacturer)

    if ([string]::IsNullOrWhiteSpace($Model) -and [string]::IsNullOrWhiteSpace($Manufacturer)) {
        return (-not $UnknownHardwareIsPhysical)
    }
    foreach ($p in $VirtualModelPatterns) { if ($Model -like "*$p*") { return $true } }
    if (-not [string]::IsNullOrWhiteSpace($Model)) { return $false }
    foreach ($p in $VirtualVendorPatterns) { if ($Manufacturer -like "*$p*") { return $true } }
    return $false
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - bitte 'az upgrade' ausfuehren."
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
    Write-Ok "Subscription gesetzt."
}

Write-Run "Pruefe benoetigte Extensions..."
$extOk = $true
foreach ($e in @("monitor-control-service","resource-graph")) {
    if (-not (Ensure-Extension -Name $e)) { $extOk = $false }
}
if (-not $extOk) { exit 1 }
Write-Ok "Extensions verfuegbar."

Write-Run "Loese Workspace '$WorkspaceName' auf..."
$ws = Invoke-AzJson @("monitor","log-analytics","workspace","show",
                      "--resource-group",$WorkspaceResourceGroup,
                      "--name",$WorkspaceName,"-o","json")
if (-not $ws) {
    Write-Fail "Workspace nicht erreichbar: $script:LastAzError"
    exit 1
}
Write-Ok "Workspace gefunden: $($ws.name) ($($ws.location))"
$WorkspaceResourceId = $ws.id

if ($ws.location -ne $DcrLocation) {
    Write-Warn2 "DCR-Region '$DcrLocation' weicht von der Workspace-Region '$($ws.location)' ab."
    Write-Sub "Das ist erlaubt, kann aber Cross-Region-Traffic verursachen."
}
Write-Line

# =============================================================================
#  DCR ANLEGEN ODER AKTUALISIEREN
# =============================================================================
Write-Head "DATA COLLECTION RULE"

$DcrResourceId = "/subscriptions/$SubscriptionId/resourceGroups/$DcrResourceGroup" `
               + "/providers/Microsoft.Insights/dataCollectionRules/$DcrName"
$DcrUrl = "https://management.azure.com$($DcrResourceId)?api-version=$ApiVersion"

# --- Body zusammenbauen ---
# ConvertTo-Json escaped die Backslashes in \VmInsights\DetailedMetrics
# automatisch korrekt - deshalb hier KEINE manuelle Verdopplung.
$dataSources = @{
    performanceCounters = @(
        @{
            name                       = "VMInsightsPerfCounters"
            streams                    = @("Microsoft-InsightsMetrics")
            scheduledTransferPeriod    = "PT1M"
            samplingFrequencyInSeconds = $SamplingSeconds
            counterSpecifiers          = @('\VmInsights\DetailedMetrics')
        }
    )
}

$dataFlows = @(
    @{
        streams      = @("Microsoft-InsightsMetrics")
        destinations = @("VMInsightsPerf-Logs-Dest")
    }
)

if ($IncludeServiceMap) {
    $dataSources["extensions"] = @(
        @{
            name          = "DependencyAgentDataSource"
            streams       = @("Microsoft-ServiceMap")
            extensionName = "DependencyAgent"
            extensionSettings = @{}
        }
    )
    $dataFlows += @{
        streams      = @("Microsoft-ServiceMap")
        destinations = @("VMInsightsPerf-Logs-Dest")
    }
}

$dcrBody = @{
    location   = $DcrLocation
    properties = @{
        description  = $DcrDescription
        dataSources  = $dataSources
        destinations = @{
            logAnalytics = @(
                @{
                    workspaceResourceId = $WorkspaceResourceId
                    name                = "VMInsightsPerf-Logs-Dest"
                }
            )
        }
        dataFlows = $dataFlows
    }
}

Write-Run "Pruefe, ob '$DcrName' bereits existiert..."
$existing = Invoke-AzJson @("rest","--method","get","--url",$DcrUrl)

if ($existing) { Write-Info2 "DCR vorhanden - wird aktualisiert." }
else           { Write-Info2 "DCR nicht vorhanden - wird angelegt." }

Write-Sub "Name        : $DcrName"
Write-Sub "Region      : $DcrLocation"
Write-Sub "Ziel        : $WorkspaceName"
Write-Sub "Counter     : \VmInsights\DetailedMetrics"
Write-Sub "Intervall   : $SamplingSeconds s"
Write-Sub "Service Map : $(if ($IncludeServiceMap) { 'ja' } else { 'nein' })"

if ($WhatIfMode) {
    Write-Line
    Write-Info2 "WhatIf-Modus - keine Aenderung."
    Write-Host ($dcrBody | ConvertTo-Json -Depth 20)
    Write-Line
}
else {
    Write-Run "Sende PUT..."
    $dcr = Invoke-AzRestBody -Method "put" -Url $DcrUrl -Body $dcrBody
    if (-not $dcr) {
        Write-Fail "DCR konnte nicht angelegt werden."
        Write-Sub "Ursache: $script:LastAzError"
        exit 1
    }
    Write-Ok "DCR bereit: $($dcr.name)"
    Write-Sub "immutableId: $($dcr.properties.immutableId)"
    Write-Line
}

# =============================================================================
#  ZIELMASCHINEN ERMITTELN
# =============================================================================
Write-Head "ZIELMASCHINEN"

Write-Run "Lade Arc-Maschinen aus Resource Graph..."

# Nur einfache Anfuehrungszeichen - doppelte ueberleben az.cmd unter Windows nicht.
$argQuery = "resources " `
  + "| where type =~ 'microsoft.hybridcompute/machines' " `
  + "| project id, name, resourceGroup, " `
  +   "status = tostring(properties.status), " `
  +   "osName = tostring(properties.osName), " `
  +   "model = tostring(properties.detectedProperties.model), " `
  +   "manufacturer = tostring(properties.detectedProperties.manufacturer)"

$argRes = Invoke-AzJson @("graph","query","-q",$argQuery,"--first","1000","-o","json")
if (-not $argRes -or -not $argRes.data) {
    Write-Fail "Arc-Inventar nicht abrufbar: $script:LastAzError"
    exit 1
}
$machines = @($argRes.data)
Write-Ok "$($machines.Count) Arc-Maschine(n) gefunden."

$ziele    = @()
$excluded = @()

foreach ($m in $machines) {

    $grund = $null

    if ($ExcludeNames -contains $m.name) { $grund = "Ausschlussliste" }

    if (-not $grund) {
        foreach ($p in $ExcludeNamePatterns) {
            if ($m.name -match $p) { $grund = "AVD (Namensmuster)"; break }
        }
    }

    if (-not $grund -and $ExcludePhysical) {
        if (-not (Test-IsVirtual -Model $m.model -Manufacturer $m.manufacturer)) {
            $grund = "Physisch (Hardware)"
        }
    }

    if (-not $grund -and $OnlyConnected -and $m.status -ne "Connected") {
        $grund = "Agent offline"
    }

    if ($grund) { $excluded += [PSCustomObject]@{ Server = $m.name; Grund = $grund } }
    else        { $ziele   += $m }
}

Write-Ok "Zielmaschinen: $($ziele.Count)"
Write-Warn2 "Ausgeschlossen: $($excluded.Count)"
foreach ($g in ($excluded | Group-Object Grund | Sort-Object Count -Descending)) {
    Write-Sub ("{0,-30} {1,4}" -f $g.Name, $g.Count)
}
Write-Line

# =============================================================================
#  ASSOCIATIONS ANLEGEN
# =============================================================================
if (-not $AssociateNow) {
    Write-Head "ASSOCIATIONS"
    Write-Info2 "Uebersprungen (`$AssociateNow = `$false)."
    Write-Sub "Die Zuordnung uebernimmt dann Script 3 (Policy + Remediation)."
    Write-Line
}
elseif ($WhatIfMode) {
    Write-Head "ASSOCIATIONS"
    Write-Info2 "WhatIf-Modus - $($ziele.Count) Association(s) wuerden angelegt."
    Write-Line
}
else {
    Write-Head "ASSOCIATIONS"
    Write-Run "Lege $($ziele.Count) Association(s) an..."

    $ok = 0; $skip = 0; $err = 0; $i = 0

    foreach ($m in $ziele) {
        $i++
        if ($i % 25 -eq 0) { Write-Sub "... $i / $($ziele.Count)" }

        $aUrl = "https://management.azure.com$($m.id)/providers/Microsoft.Insights" `
              + "/dataCollectionRuleAssociations/$($AssociationName)?api-version=$ApiVersion"

        # Bereits vorhanden? PUT waere idempotent, spart aber keinen Call -
        # der GET ist billiger als ein fehlgeschlagener PUT im Fehlerfall.
        $have = Invoke-AzJson @("rest","--method","get","--url",$aUrl)
        if ($have -and $have.properties.dataCollectionRuleId -eq $DcrResourceId) {
            $skip++
            continue
        }

        $aBody = @{
            properties = @{
                dataCollectionRuleId = $DcrResourceId
                description          = "VM Insights -> $WorkspaceName"
            }
        }

        $res = Invoke-AzRestBody -Method "put" -Url $aUrl -Body $aBody
        if ($res) { $ok++ }
        else {
            $err++
            if ($err -le 5) { Write-Warn2 "$($m.name): $script:LastAzError" }
            if ($err -eq 6)  { Write-Warn2 "... weitere Fehler werden nicht einzeln ausgegeben." }
        }
    }

    Write-Host ""
    Write-Ok "Neu angelegt : $ok"
    if ($skip -gt 0) { Write-Info2 "Bereits vorhanden: $skip" }
    if ($err  -gt 0) { Write-Fail "Fehlgeschlagen: $err" }
    Write-Line
}

# =============================================================================
#  ZUSAMMENFASSUNG
# =============================================================================
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "DCR          : $DcrName"
Write-Sub "Ziel         : $WorkspaceName"
Write-Sub "Counter-Set  : \VmInsights\DetailedMetrics (CPU, Memory, LogicalDisk, Network)"
Write-Sub "Intervall    : $SamplingSeconds s"
Write-Sub "Zielmaschinen: $($ziele.Count)"
Write-Host ""
Write-Info2 "Erste Daten erscheinen typischerweise nach 5 bis 15 Minuten."
Write-Sub "Pruefen mit  : .\Test-ArcMonitoringPrereq.ps1"
Write-Host ""
Write-Warn2 "Nicht vergessen:"
Write-Sub "- Script 3: Policy + Remediation, damit neue Server automatisch folgen"
Write-Sub "- Script 5: alte MSVMI-* DCRs mit demselben Ziel entfernen (doppelte Kosten)"
Write-Line
