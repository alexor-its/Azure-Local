#Requires -Version 5.1
<#
.SYNOPSIS
    DIAGNOSE - Zeigt fuer jede Data Collection Rule die tatsaechlichen
    Datenquellen, Ziele und die Anzahl zugeordneter Maschinen.
.DESCRIPTION
    Beantwortet die Frage: "Die DCR ist doch zugewiesen - warum sagt der
    Pre-Check 'DCR ohne Disk-Counter'?"

    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung

    Hintergrund: Azure kennt zwei getrennte Datenpfade fuer Guest-OS-Metriken.

      A) VM Insights / klassische Performance Counter
         dataSources.performanceCounters mit \LogicalDisk(*)\...
         -> destinations.logAnalytics
         -> Tabelle InsightsMetrics
         -> per KQL abfragbar, Grundlage fuer Log Search Alerts

      B) Detailed metrics / "Unlock performance insights" (OpenTelemetry)
         dataSources.performanceCountersOTel
         -> destinations.monitoringAccounts (Azure Monitor Workspace)
         -> Prometheus-Metriken
         -> per PromQL abfragbar, Grundlage fuer Metric Alerts

    Pfad B fuettert die Tabelle InsightsMetrics NICHT. Wer nur B konfiguriert
    hat, sieht Heartbeats (AMA laeuft, Association existiert), aber keine
    Disk-Daten in Log Analytics.

    Dieses Script liest die DCRs bewusst per 'az rest' mit einer aktuellen
    API-Version aus, weil 'az monitor data-collection rule list' eine feste
    aeltere Version verwendet und neuere Datenquellen wie
    performanceCountersOTel dort fehlen koennen.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 18.08.2026
    Version     : 1.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\Get-ArcDcrDetail.ps1
.EXAMPLE
    # Auch die einzelnen Counter-Specifier ausgeben
    $ShowCounters = $true; .\Get-ArcDcrDetail.ps1
#>

$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

$SubscriptionId  = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local
$ApiVersion      = "2023-03-11"     # kennt performanceCountersOTel
$ShowCounters    = $false           # Counter-Specifier je DCR ausgeben
$ShowAssocList   = $false           # zugeordnete Maschinen einzeln listen
$MaxAssocList    = 10               # bei $ShowAssocList: max. Anzahl je DCR

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Get-PropNames {
    <#
      Liefert die Namen aller gesetzten Eigenschaften eines Objekts.
      Wird gebraucht, um unbekannte Datenquellen-Typen sichtbar zu machen,
      statt nur auf die erwarteten zu pruefen.
    #>
    param($Obj)
    if ($null -eq $Obj) { return @() }
    return @($Obj.PSObject.Properties | Where-Object {
        $null -ne $_.Value -and @($_.Value).Count -gt 0
    } | ForEach-Object { $_.Name })
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) { Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')" }
else          { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Wechsle Subscription zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
}
Write-Ok "Subscription: $($account.name)"
Write-Line

# =============================================================================
#  DCRs LADEN (per REST, aktuelle API-Version)
# =============================================================================
Write-Head "DCR-INVENTAR"

Write-Run "Lade DCRs per REST (API $ApiVersion)..."
$url = "https://management.azure.com/subscriptions/$SubscriptionId" `
     + "/providers/Microsoft.Insights/dataCollectionRules?api-version=$ApiVersion"

$resp = Invoke-AzJson @("rest","--method","get","--url",$url)
if (-not $resp -or -not $resp.value) {
    Write-Fail "DCRs nicht abrufbar: $script:LastAzError"
    Write-Sub "Falls die API-Version abgelehnt wird, `$ApiVersion anpassen."
    exit 1
}
$dcrs = @($resp.value)
Write-Ok "$($dcrs.Count) DCR(s) gefunden."
Write-Line

# =============================================================================
#  DETAILAUSGABE JE DCR
# =============================================================================
$zusammenfassung = @()

foreach ($dcr in ($dcrs | Sort-Object name)) {

    $p = $dcr.properties

    # --- Ziele ---
    $ziele = @()
    if ($p.destinations.logAnalytics) {
        foreach ($d in $p.destinations.logAnalytics) {
            $ziele += "LAW: " + ($d.workspaceResourceId -split '/')[-1]
        }
    }
    if ($p.destinations.monitoringAccounts) {
        foreach ($d in $p.destinations.monitoringAccounts) {
            $ziele += "AMW: " + ($d.accountResourceId -split '/')[-1]
        }
    }
    if ($p.destinations.azureMonitorMetrics) { $ziele += "Azure Monitor Metrics" }
    if ($ziele.Count -eq 0) { $ziele = @("(kein Ziel)") }

    # --- Datenquellen: ALLE gesetzten Typen, auch unbekannte ---
    $quellen = Get-PropNames -Obj $p.dataSources
    if ($quellen.Count -eq 0) { $quellen = @("(keine)") }

    # --- LogicalDisk in klassischen Performance Countern? ---
    $diskCounters = @()
    if ($p.dataSources.performanceCounters) {
        foreach ($pc in $p.dataSources.performanceCounters) {
            foreach ($cs in @($pc.counterSpecifiers)) {
                if ($cs -match "LogicalDisk") { $diskCounters += $cs }
            }
        }
    }
    $hatLawDisk = ($diskCounters.Count -gt 0) -and ($p.destinations.logAnalytics)

    # --- LogicalDisk im OTel-Pfad? ---
    $hatOtel = [bool]$p.dataSources.performanceCountersOTel

    # --- Associations zaehlen ---
    $aUrl = "https://management.azure.com$($dcr.id)/associations?api-version=$ApiVersion"
    $aRes = Invoke-AzJson @("rest","--method","get","--url",$aUrl)
    $assocs = if ($aRes -and $aRes.value) { @($aRes.value) } else { @() }

    # --- Ausgabe ---
    $farbe = if ($hatLawDisk) { "Green" } elseif ($hatOtel) { "Cyan" } else { "Yellow" }
    Write-Host ""
    Write-Host "  $($dcr.name)" -ForegroundColor $farbe
    Write-Sub "Kind        : $(if ($dcr.kind) { $dcr.kind } else { '-' })"
    Write-Sub "Region      : $($dcr.location)"
    Write-Sub "Ziele       : $($ziele -join ' | ')"
    Write-Sub "Datenquellen: $($quellen -join ', ')"
    Write-Sub "Zuordnungen : $($assocs.Count)"

    if ($diskCounters.Count -gt 0) {
        Write-Host "    LogicalDisk : $($diskCounters.Count) Counter" -ForegroundColor Green
        if ($ShowCounters) { foreach ($c in $diskCounters) { Write-Host "        $c" -ForegroundColor DarkGray } }
    }
    elseif ($hatOtel) {
        Write-Host "    LogicalDisk : ueber OTel-Pfad (nicht in InsightsMetrics)" -ForegroundColor Cyan
    }
    else {
        Write-Host "    LogicalDisk : keine" -ForegroundColor Yellow
    }

    if ($ShowAssocList -and $assocs.Count -gt 0) {
        $i = 0
        foreach ($a in $assocs) {
            if ($i -ge $MaxAssocList) { Write-Host "        ... und $($assocs.Count - $MaxAssocList) weitere" -ForegroundColor DarkGray; break }
            $idx = $a.id.ToLower().IndexOf("/providers/microsoft.insights/datacollectionruleassociations/")
            $mn  = if ($idx -gt 0) { ($a.id.Substring(0,$idx) -split '/')[-1] } else { $a.name }
            Write-Host "        $mn" -ForegroundColor DarkGray
            $i++
        }
    }

    $zusammenfassung += [PSCustomObject]@{
        Name        = $dcr.name
        Ziele       = ($ziele -join '|')
        LawDisk     = $hatLawDisk
        Otel        = $hatOtel
        Zuordnungen = $assocs.Count
    }
}

Write-Host ""
Write-Line

# =============================================================================
#  BEWERTUNG
# =============================================================================
Write-Head "BEWERTUNG"

$lawDisk = @($zusammenfassung | Where-Object { $_.LawDisk })
$otel    = @($zusammenfassung | Where-Object { $_.Otel })

Write-Sub "DCRs gesamt                       : $($zusammenfassung.Count)"
Write-Host ""

if ($lawDisk.Count -gt 0) {
    Write-Ok "$($lawDisk.Count) DCR(s) liefern LogicalDisk an Log Analytics:"
    foreach ($d in $lawDisk) { Write-Sub "$($d.Name) - $($d.Zuordnungen) Zuordnung(en)" }
    $abgedeckt = ($lawDisk | Measure-Object Zuordnungen -Sum).Sum
    Write-Sub "Summe abgedeckter Maschinen: $abgedeckt"
}
else {
    Write-Fail "KEINE DCR liefert LogicalDisk an Log Analytics."
    Write-Sub "Damit bleibt die Tabelle InsightsMetrics leer - und der"
    Write-Sub "Log Search Alert kann nicht ausloesen."
}

Write-Host ""
if ($otel.Count -gt 0) {
    Write-Info2 "$($otel.Count) DCR(s) nutzen den OTel-Pfad (Detailed metrics):"
    foreach ($d in $otel) { Write-Sub "$($d.Name) - $($d.Zuordnungen) Zuordnung(en)" }
    Write-Host ""
    Write-Warn2 "Wichtig: OTel-Metriken landen im Azure Monitor Workspace,"
    Write-Sub "nicht in der Log-Analytics-Tabelle InsightsMetrics."
    Write-Sub "Sie sind per PromQL abfragbar und brauchen einen Metric Alert."
    Write-Sub "Der bestehende Log Search Alert sieht diese Daten NICHT."
}

Write-Host ""
Write-Info2 "Konsequenz fuer die Alert-Strategie:"
Write-Sub "Variante 1 - Performance Counter \LogicalDisk(*)\% Free Space in eine"
Write-Sub "             DCR mit LAW-Ziel aufnehmen. Der bestehende Alert greift dann."
Write-Sub "Variante 2 - Beim OTel-Pfad bleiben und stattdessen einen Prometheus-"
Write-Sub "             Metric-Alert auf dem Azure Monitor Workspace bauen."
Write-Line
