#Requires -Version 5.1
<#
.SYNOPSIS
    SCHRITT 5 von 6 - Erstellt EINE E-Mail-Alert-Regel fuer die VIRTUAL SERVER
    (VMs), wenn der freie Speicher eines Laufwerks unter einen Schwellwert
    sinkt. Der betroffene Servername erscheint dynamisch im Mail-Betreff.
.DESCRIPTION
    Ablauf der Script-Reihe:
      0. Set-ArcVirtualServerTag.ps1   - Tag Monitoring=VirtualServer setzen
      1. New-ArcVmInsightsDcr.ps1      - DCR anlegen + Bestand assoziieren
      2. Test-ArcMonitoringPrereq.ps1  - Abdeckung pruefen
      3. New-ArcMonitoringPolicy.ps1   - Policy + RBAC + Remediation
      4. Get-ArcDiskSpace.ps1          - Ist-Werte abfragen
      5. New-ArcDiskSpaceAlert.ps1     - E-Mail-Alert einrichten (dieses Script)
      6. New-ArcDiskSpaceWorkbook.ps1  - Dashboard deployen

    Werkzeuge ausserhalb der Reihe:
      Get-ArcDcrDetail.ps1        - Diagnose: was sammelt welche DCR wohin
      Rename-ArcVmInsightsDcr.ps1 - einmalige Migration bei DCR-Umbenennung

    KONZEPT
    -------------------------------------------------------------------------
    Es wird genau EINE Alert-Regel auf law-LDK-VirtualServer angelegt. Ueber
    Dimension-Splitting auf 'Computer' erzeugt Azure Monitor daraus je
    betroffenem Server eine eigene Alert-Instanz - ohne dass pro Server eine
    eigene Regel noetig waere.

    Der Servername kommt ueber actionProperties/Email.Subject dynamisch in
    die Betreffzeile:

        HCLArcDemoSRV01 - Arc: Laufwerk C: unter 15 % frei (Fired, 14.29 % frei)

    Die Ueberschrift IM MAIL-BODY bleibt der statische displayName der Regel -
    das ist eine Azure-Einschraenkung und mit einer einzelnen Regel nicht
    umgehbar. Der Servername steht im Body unter 'Dimensions -> Computer'.

    SCOPE
    -------------------------------------------------------------------------
    Physische Server und AVD-Hosts liegen in eigenen Workspaces
    (law-LDK-PhysicalServer, AVD-Workspace) und koennen hier nicht auftauchen.
    Trotzdem schliesst die KQL AVD-Namen explizit aus: schreibt ein Host
    versehentlich in diesen Workspace, wuerde er sonst mit alarmieren.
    Physische Server lassen sich in der KQL nicht erkennen - dafuer fehlen im
    Workspace die Hardware-Angaben. Sie muessten ueber $ExcludeNames
    namentlich eingetragen werden.

    Technischer Hinweis: 'az monitor scheduled-query create' kennt KEINEN
    Parameter fuer actionProperties. Der Betreff wird deshalb im Anschluss
    per 'az rest' PATCH (API-Version 2023-12-01) gesetzt.
.NOTES
    =========================================================================
    Author      : Alexander Ortha
    Company     : Alexander Ortha IT Solutions
    Contact     : https://ortha-itsolutions.de/
    Created     : 18.08.2026
    Version     : 3.0.0
    Copyright   : (c) 2026 Alexander Ortha IT Solutions. All rights reserved.
    -------------------------------------------------------------------------
    Code created by Alexander Ortha.
    Development supported through AI-tools.
    =========================================================================
.EXAMPLE
    .\New-ArcDiskSpaceAlert.ps1
.EXAMPLE
    # Vorschau ohne Aenderungen - zeigt Query, Condition und Betreff
    $WhatIfMode = $true; .\New-ArcDiskSpaceAlert.ps1
#>

$env:PYTHONWARNINGS = "ignore"

# =============================================================================
#  KONFIGURATION
# =============================================================================

# --- Azure-Kontext ---
$SubscriptionId         = "33207861-9482-4afb-9786-eba3a0265bef"   # Azure Local
$WorkspaceName          = "law-LDK-VirtualServer"
$WorkspaceResourceGroup = "rg-arcmgmt"
$AlertResourceGroup     = "rg-arcmgmt"
$Location               = "westeurope"

# --- Action Group / Empfaenger ---
$ActionGroupName        = "ag-arc-diskspace"
$ActionGroupShortName   = "ArcDisk"                    # max. 12 Zeichen
$EmailName              = "ITAlert"
$EmailAddress           = "statusmails@ortha-itsolutions.de"

# --- Alert-Regel ---
$RuleName               = "alert-arc-disk-c-below-15pct"
$RuleDisplayName        = "Arc: Laufwerk C: unter 15 % frei"
$Severity               = 2                            # 0=schwerwiegend ... 4=info
$ThresholdPercent       = 15
$DriveLetter            = "C:"
$EvaluationFrequency    = "PT15M"
$WindowSize             = "PT15M"
$NumberOfEvalPeriods    = 2
$MinFailingPeriods      = 2
$MuteActionsDuration    = "PT6H"
$AutoMitigate           = $true

# --- FILTER (mit Script 1 und 2 konsistent halten) ---
$ExcludeNamePatterns    = @('^avd')       # AVD-Session-Hosts
$ExcludeNames           = @()             # z. B. physische Hosts, falls noetig

# --- Betreff-Vorlage --------------------------------------------------------
# WICHTIG: einfache Anfuehrungszeichen verwenden! In doppelten wuerde
# PowerShell ${data...} als eigene Variable interpretieren und leer ersetzen.
#
# Platzhalter folgen dem Common Alert Schema:
#   ${data.alertContext.condition.allOf[0].dimensions[0].value}
#        -> Wert der ERSTEN Dimension. Die Regel definiert nur 'Computer',
#           damit ist Index 0 der Servername.
#   ${data.essentials.monitorCondition}      -> Fired | Resolved
#   ${data.alertContext.condition.allOf[0].metricValue}  -> gemessener Wert
$EmailSubjectTemplate = '${data.alertContext.condition.allOf[0].dimensions[0].value}' `
                      + ' - Arc: Laufwerk C: unter 15 % frei' `
                      + ' (${data.essentials.monitorCondition},' `
                      + ' ${data.alertContext.condition.allOf[0].metricValue} % frei)'

# --- Vorschaumodus ---
$WhatIfMode             = $false

# =============================================================================
#  HILFSFUNKTIONEN
# =============================================================================

function Write-Line  { Write-Host ("=" * 78) -ForegroundColor White }
function Write-Head  { param($T) Write-Host "[ $T ]" -ForegroundColor White }
function Write-Ok    { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') OK   $M" -ForegroundColor Green }
function Write-Fail  { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') FEHL $M" -ForegroundColor Red }
function Write-Warn2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') WARN $M" -ForegroundColor Yellow }
function Write-Info2 { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') INFO $M" -ForegroundColor Cyan }
function Write-Run   { param($M) Write-Host "$(Get-Date -f '[HH:mm:ss]') RUN  $M" -ForegroundColor Cyan }
function Write-Sub   { param($M) Write-Host "    $M" }

function Invoke-AzJson {
    param([Parameter(Mandatory)][string[]]$Arguments)

    $script:LastAzError = $null
    $prevEap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $errFile = [System.IO.Path]::GetTempFileName()

    try {
        $raw  = & az @Arguments 2>$errFile
        $exit = $LASTEXITCODE
        $err  = if (Test-Path $errFile) { (Get-Content $errFile -Raw) } else { "" }

        if ($exit -ne 0) { $script:LastAzError = ($err | Out-String).Trim(); return $null }

        $text = ($raw | Out-String).Trim()
        if ([string]::IsNullOrWhiteSpace($text)) { return $null }

        $start = $text.IndexOfAny([char[]]@('{','['))
        if ($start -lt 0) { $script:LastAzError = "Keine JSON-Antwort erhalten: $text"; return $null }
        if ($start -gt 0) { $text = $text.Substring($start) }

        try   { return ($text | ConvertFrom-Json) }
        catch { $script:LastAzError = "JSON-Parsing fehlgeschlagen: $($_.Exception.Message)"; return $null }
    }
    finally {
        $ErrorActionPreference = $prevEap
        Remove-Item $errFile -ErrorAction SilentlyContinue
    }
}

function Get-DiskQuery {
    <#
      Baut die KQL. Nur einfache Anfuehrungszeichen - doppelte ueberleben die
      Uebergabe an az.cmd unter Windows nicht.
    #>
    $p = New-Object System.Collections.Generic.List[string]

    $p.Add("InsightsMetrics")
    $p.Add("where Origin == 'vm.azm.ms'")
    $p.Add("where Namespace == 'LogicalDisk' and Name == 'FreeSpacePercentage'")
    $p.Add("where _ResourceId has '/microsoft.hybridcompute/machines/'")

    # AVD-Hosts und explizite Namen ausschliessen
    # ACHTUNG: KQL kennt KEIN '!matches regex' - die Negation laeuft ueber not().
    foreach ($pat in $ExcludeNamePatterns) {
        $p.Add("where not(Computer matches regex '(?i)$pat')")
    }
    if ($ExcludeNames.Count -gt 0) {
        $list = ($ExcludeNames | ForEach-Object { "'$_'" }) -join ", "
        $p.Add("where Computer !in~ ($list)")
    }

    $p.Add("extend Drive = tostring(todynamic(Tags)['vm.azm.ms/mountId'])")
    $p.Add("where Drive == '$DriveLetter'")
    $p.Add("summarize FreePercent = avg(Val) by Computer, Drive, _ResourceId")
    $p.Add("project Computer, Drive, FreePercent, resourceId = _ResourceId")

    return ($p -join " | ")
}

function Set-AlertEmailSubject {
    <#
      Setzt actionProperties/Email.Subject per REST-PATCH nach, weil die CLI
      dafuer keinen Parameter anbietet. Der actions-Block wird beim PATCH
      komplett ersetzt - actionGroups muss deshalb mitgeschickt werden.
      Der Body geht ueber eine Temp-Datei, weil az.cmd Inline-JSON unter
      Windows falsch zerlegt.
    #>
    param(
        [Parameter(Mandatory)][string]$ActionGroupId,
        [Parameter(Mandatory)][string]$Subject
    )

    $ruleId = "/subscriptions/$SubscriptionId/resourceGroups/$AlertResourceGroup" `
            + "/providers/Microsoft.Insights/scheduledQueryRules/$RuleName"

    $payload = @{
        properties = @{
            actions = @{
                actionGroups     = @($ActionGroupId)
                actionProperties = @{ "Email.Subject" = $Subject }
            }
        }
    }

    $bodyFile = Join-Path $env:TEMP "sqr-patch-$([guid]::NewGuid()).json"
    $payload | ConvertTo-Json -Depth 10 | Set-Content -Path $bodyFile -Encoding UTF8

    try {
        return Invoke-AzJson @(
            "rest",
            "--method", "patch",
            "--url", "https://management.azure.com$($ruleId)?api-version=2023-12-01",
            "--headers", "Content-Type=application/json",
            "--body", "@$bodyFile"
        )
    }
    finally {
        Remove-Item $bodyFile -ErrorAction SilentlyContinue
    }
}

# =============================================================================
#  PRE-CHECK
# =============================================================================
Write-Line
Write-Head "PRE-CHECK"

Write-Run "Pruefe Azure CLI..."
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    Write-Fail "Azure CLI nicht gefunden. Installation: https://aka.ms/installazurecliwindows"
    exit 1
}
$verInfo = Invoke-AzJson @("version")
if ($verInfo) {
    Write-Ok "Azure CLI gefunden: $($verInfo.'azure-cli')"
    if ([version]$verInfo.'azure-cli' -lt [version]"2.54.0") {
        Write-Warn2 "Version < 2.54.0 - 'az monitor scheduled-query' benoetigt mindestens 2.54.0."
    }
}
else { Write-Warn2 "Version nicht ermittelbar: $script:LastAzError" }

Write-Run "Pruefe Login..."
$account = Invoke-AzJson @("account","show")
if (-not $account) { Write-Fail "Nicht angemeldet. Bitte 'az login' ausfuehren."; exit 1 }
Write-Ok "Login vorhanden: $($account.user.name)"
Write-Sub "Subscription: $($account.name) ($($account.id))"

if ($account.id -ne $SubscriptionId) {
    Write-Warn2 "Aktive Subscription weicht ab - wechsle zu $SubscriptionId"
    az account set --subscription $SubscriptionId 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Subscription-Wechsel fehlgeschlagen."; exit 1 }
    Write-Ok "Subscription gesetzt."
}

Write-Run "Pruefe Extension 'scheduled-query'..."
$exts = Invoke-AzJson @("extension","list")
if (-not ($exts | Where-Object { $_.name -eq "scheduled-query" })) {
    Write-Warn2 "Extension fehlt - wird installiert."
    az extension add --name scheduled-query --only-show-errors 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Fail "Installation fehlgeschlagen."; exit 1 }
}
Write-Ok "Extension 'scheduled-query' verfuegbar."

Write-Run "Pruefe Workspace '$WorkspaceName'..."
$ws = Invoke-AzJson @("monitor","log-analytics","workspace","show",
                      "--resource-group",$WorkspaceResourceGroup,
                      "--name",$WorkspaceName,"-o","json")
if (-not $ws) {
    Write-Fail "Workspace nicht erreichbar: $script:LastAzError"
    exit 1
}
Write-Ok "Workspace gefunden: $($ws.name) ($($ws.location))"
$WorkspaceResourceId = $ws.id
Write-Line

# =============================================================================
#  ACTION GROUP
# =============================================================================
Write-Head "ACTION GROUP"

Write-Run "Pruefe Action Group '$ActionGroupName'..."
$ag = Invoke-AzJson @("monitor","action-group","show",
                      "--resource-group",$AlertResourceGroup,
                      "--name",$ActionGroupName,"-o","json")

if ($ag) {
    Write-Ok "Action Group vorhanden."
    $recipients = @($ag.emailReceivers | ForEach-Object { $_.emailAddress })
    if ($recipients -notcontains $EmailAddress) {
        Write-Warn2 "Empfaenger '$EmailAddress' nicht enthalten - wird ergaenzt."
        if (-not $WhatIfMode) {
            $ag = Invoke-AzJson @("monitor","action-group","update",
                                  "--resource-group",$AlertResourceGroup,
                                  "--name",$ActionGroupName,
                                  "--add-action","email",$EmailName,$EmailAddress,"-o","json")
        }
    }
    else { Write-Sub "Empfaenger: $($recipients -join ', ')" }
}
else {
    Write-Warn2 "Action Group nicht vorhanden - wird angelegt."
    if (-not $WhatIfMode) {
        $ag = Invoke-AzJson @("monitor","action-group","create",
                              "--resource-group",$AlertResourceGroup,
                              "--name",$ActionGroupName,
                              "--short-name",$ActionGroupShortName,
                              "--action","email",$EmailName,$EmailAddress,"-o","json")
        if (-not $ag) { Write-Fail "Anlage fehlgeschlagen: $script:LastAzError"; exit 1 }
        Write-Ok "Action Group erstellt."
    }
}
$ActionGroupId = if ($ag) { $ag.id } else { "<WhatIf>" }
Write-Sub "ID: $ActionGroupId"
Write-Line

# =============================================================================
#  ALERT-REGEL
# =============================================================================
Write-Head "ALERT-REGEL"

$query = Get-DiskQuery

# Dimension-Splitting auf 'Computer' - erzeugt je betroffenem Server eine
# eigene Alert-Instanz und liefert den Namen fuer den dynamischen Betreff.
$condition = "min 'Placeholder_1' < $ThresholdPercent " `
           + "resource id resourceId " `
           + "where Computer includes * " `
           + "at least $MinFailingPeriods violations out of $NumberOfEvalPeriods aggregated points"

$description = "Feuert, wenn auf einem Arc-enabled Virtual Server der freie " `
             + "Speicher von $DriveLetter unter $ThresholdPercent % sinkt."

Write-Info2 "Regel  : $RuleName"
Write-Sub   "Anzeige: $RuleDisplayName"
Write-Sub   "Betreff: $EmailSubjectTemplate"
Write-Sub   "Ausschluss: $($ExcludeNamePatterns -join ', ')"

if ($WhatIfMode) {
    Write-Line
    Write-Info2 "WhatIf-Modus - es wird nichts angelegt."
    Write-Sub "Query    : $query"
    Write-Sub "Condition: $condition"
    Write-Line
    exit 0
}

Write-Run "Lege Alert-Regel an..."

$rule = Invoke-AzJson @(
    "monitor","scheduled-query","create",
    "--name", $RuleName,
    "--resource-group", $AlertResourceGroup,
    "--scopes", $WorkspaceResourceId,
    "--location", $Location,
    "--description", $description,
    "--severity", "$Severity",
    "--evaluation-frequency", $EvaluationFrequency,
    "--window-size", $WindowSize,
    "--action-groups", $ActionGroupId,
    "--mute-actions-duration", $MuteActionsDuration,
    "--auto-mitigate", $(if ($AutoMitigate) { "true" } else { "false" }),
    "--condition", $condition,
    "--condition-query", "Placeholder_1=$query",
    "--target-resource-type", "Microsoft.HybridCompute/machines",
    "--custom-properties", "Laufwerk=$DriveLetter", "Schwellwert=$ThresholdPercent",
    "-o", "json"
)

if (-not $rule) {
    Write-Fail "Anlage der Alert-Regel fehlgeschlagen."
    Write-Sub "Ursache: $script:LastAzError"
    exit 1
}
Write-Ok "Alert-Regel erstellt."

# --- Anzeigename setzen (CLI uebernimmt sonst den Ressourcennamen) ---
if ($RuleDisplayName -ne $RuleName) {
    Write-Run "Setze Anzeigenamen..."
    $upd = Invoke-AzJson @("resource","update",
                           "--ids",$rule.id,
                           "--set","properties.displayName=$RuleDisplayName",
                           "--api-version","2023-12-01","-o","json")
    if ($upd) { Write-Ok "Anzeigename gesetzt." }
    else      { Write-Warn2 "Anzeigename nicht gesetzt: $script:LastAzError" }
}

# --- Dynamischen Betreff setzen ---
Write-Run "Setze dynamischen E-Mail-Betreff..."
$patched = Set-AlertEmailSubject -ActionGroupId $ActionGroupId -Subject $EmailSubjectTemplate

if ($patched) {
    Write-Ok "Betreff gesetzt."
    Write-Sub $EmailSubjectTemplate
}
else {
    Write-Warn2 "Betreff konnte nicht gesetzt werden: $script:LastAzError"
    Write-Sub "Die Regel funktioniert trotzdem - nur mit Standard-Betreff."
}
Write-Line

# =============================================================================
#  ZUSAMMENFASSUNG
# =============================================================================
Write-Head "ZUSAMMENFASSUNG"
Write-Sub "Regel        : $RuleName"
Write-Sub "Anzeigename  : $RuleDisplayName"
Write-Sub "Workspace    : $WorkspaceName"
Write-Sub "Empfaenger   : $EmailAddress"
Write-Sub "Schwellwert  : < $ThresholdPercent % frei auf $DriveLetter"
Write-Sub "Auswertung   : alle $EvaluationFrequency ueber $WindowSize"
Write-Sub "Ausloesung   : $MinFailingPeriods von $NumberOfEvalPeriods Perioden verletzt"
Write-Sub "Splitting    : je Server eine eigene Alert-Instanz (Dimension 'Computer')"
Write-Sub "Ausgeschlossen: $($ExcludeNamePatterns -join ', ')"
Write-Host ""
Write-Info2 "Beispiel-Betreff im Alarmfall:"
Write-Sub "HCLArcDemoSRV01 - Arc: Laufwerk C: unter 15 % frei (Fired, 14.2915918 % frei)"
Write-Host ""
Write-Info2 "Kontrolle:"
Write-Sub "az monitor scheduled-query show -g $AlertResourceGroup -n $RuleName --query actions"
Write-Line
